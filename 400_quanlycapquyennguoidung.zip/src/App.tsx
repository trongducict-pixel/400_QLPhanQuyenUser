import React, { useState, useEffect, useCallback } from 'react';
import {
  User,
  RequestRecord,
  PhongBan,
  ChuongTrinh,
  CanBo,
  SummaryUserMatrixRow,
  AuditLog,
  NotificationItem,
  RequestType
} from './types';
import { api } from './services/api';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { MobileHeader } from './components/MobileHeader';
import { MobileBottomNav } from './components/MobileBottomNav';
import { MobileHomeView } from './components/MobileHomeView';
import { MobileCreateRequestWizard } from './components/MobileCreateRequestWizard';
import { MobileApprovalView } from './components/MobileApprovalView';
import { AdminHubView } from './components/AdminHubView';
import { ProfileView } from './components/ProfileView';
import { MobilePageHeader } from './components/MobilePageHeader';
import { Dashboard } from './components/Dashboard';
import { RequestList } from './components/RequestList';
import { SummaryMatrixView } from './components/SummaryMatrixView';
import { LookupView } from './components/LookupView';
import { CreateRequestModal } from './components/CreateRequestModal';
import { ApprovalModal } from './components/ApprovalModal';
import { ITProcessModal } from './components/ITProcessModal';
import { PrintTicketModal } from './components/PrintTicketModal';
import { AdminUsersView } from './components/AdminUsersView';
import { AdminStaffView } from './components/AdminStaffView';
import { AdminDepartmentsView } from './components/AdminDepartmentsView';
import { AdminProgramsView } from './components/AdminProgramsView';
import { AdminAuditLogView } from './components/AdminAuditLogView';
import { AdminPermissionGuidelinesView } from './components/AdminPermissionGuidelinesView';
import { GASGuideView } from './components/GASGuideView';
import { LoginView } from './components/LoginView';
import { Loader2, AlertCircle, RefreshCw, ArrowLeft, ShieldAlert, FilePlus } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [staffList, setStaffList] = useState<CanBo[]>([]);
  const [departments, setDepartments] = useState<PhongBan[]>([]);
  const [programs, setPrograms] = useState<ChuongTrinh[]>([]);
  const [requests, setRequests] = useState<RequestRecord[]>([]);
  const [matrixRows, setMatrixRows] = useState<SummaryUserMatrixRow[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [navHistory, setNavHistory] = useState<NavTab[]>(['dashboard']);

  // Robust navigation handlers with history tracking
  const handleNavigate = useCallback((tab: NavTab) => {
    setActiveTab((current) => {
      if (current === tab) return current;
      setNavHistory((prev) => [...prev, current]);
      return tab;
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleGoBack = useCallback(() => {
    setActiveTab((current) => {
      // If inside an admin submodule, always return to Admin Hub
      if (['staff', 'users', 'programs', 'departments', 'audit', 'gas-guide'].includes(current)) {
        return 'admin-hub';
      }

      // If user came from a previous view in history
      let target: NavTab = 'dashboard';
      setNavHistory((prev) => {
        if (prev.length > 0) {
          target = prev[prev.length - 1];
          return prev.slice(0, -1);
        }
        return prev;
      });

      return target;
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedForApprove, setSelectedForApprove] = useState<RequestRecord | null>(null);
  const [selectedForIT, setSelectedForIT] = useState<RequestRecord | null>(null);
  const [selectedForPrint, setSelectedForPrint] = useState<RequestRecord | null>(null);

  // Load all initial data from backend
  const loadData = useCallback(async () => {
    try {
      setError(null);
      const [
        usersData,
        staffData,
        deptsData,
        progsData,
        reqsData,
        matrixData,
        logsData,
        notifsData
      ] = await Promise.all([
        api.getUsers(),
        api.getStaff(),
        api.getDepartments(),
        api.getPrograms(),
        api.getRequests(),
        api.getSummaryMatrix(),
        api.getAuditLogs(),
        api.getNotifications()
      ]);

      setUsers(usersData);
      setStaffList(staffData);
      setDepartments(deptsData);
      setPrograms(progsData);
      setRequests(reqsData);
      setMatrixRows(matrixData);
      setAuditLogs(logsData);
      setNotifications(notifsData);

      // Check if user session exists in localStorage
      const stored = localStorage.getItem('vietinbank_active_user');
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          const matched = usersData.find(
            (u) => u.userAD === parsed.userAD || u.id === parsed.id
          );
          if (matched) {
            setCurrentUser(matched);
            api.setCurrentUser(matched);
          }
        } catch {
          // ignore
        }
      }
    } catch (err: any) {
      console.error('Failed to load data from backend:', err);
      setError(err.message || 'Không thể tải dữ liệu từ máy chủ.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Handle Login Authentication
  const handleAttemptLogin = async (userAD: string, matKhau: string): Promise<User> => {
    const user = await api.login(userAD, matKhau);
    return user;
  };

  const handleLogin = (user: User, remember: boolean) => {
    setCurrentUser(user);
    api.setCurrentUser(user);
    if (remember) {
      localStorage.setItem('vietinbank_active_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('vietinbank_active_user');
    }
    setActiveTab('dashboard');
    loadData();
  };

  // Handle Logout
  const handleLogout = () => {
    setCurrentUser(null);
    api.setCurrentUser(null);
    localStorage.removeItem('vietinbank_active_user');
    setActiveTab('dashboard');
  };

  // When switching test user in the Header
  const handleSwitchUser = (user: User) => {
    setCurrentUser(user);
    api.setCurrentUser(user);
    localStorage.setItem('vietinbank_active_user', JSON.stringify(user));
    setActiveTab('dashboard');
    loadData();
  };

  // Actions
  const handleCreateRequest = async (payload: {
    maChuongTrinh: string;
    loaiDeNghi: RequestType;
    soQDTuyenDung_PhanCong: string;
    noiDung: string;
    targetUserAD?: string;
  }) => {
    setIsSubmitting(true);
    try {
      const created = await api.createRequest(payload);
      await loadData();
      return created;
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApproveRequest = async (id: string, lyDo?: string) => {
    setIsSubmitting(true);
    try {
      await api.approveRequest(id, lyDo);
      await loadData();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRejectRequest = async (id: string, lyDo: string) => {
    setIsSubmitting(true);
    try {
      await api.rejectRequest(id, lyDo);
      await loadData();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCompleteRequest = async (
    id: string,
    payload: {
      ketQuaXuLy?: string;
      noiDungXuLy?: string;
      nhomQuyenGoiY?: string;
      nhomQuyenThucTe?: string;
      maNhomQuyenThucTe?: string;
      canhBaoCauHinh?: string;
      canCuVanBan?: string;
      ghiChuXuLy?: string;
    }
  ) => {
    setIsSubmitting(true);
    try {
      await api.completeRequest(id, payload);
      await loadData();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddUser = async (userData: Partial<User>) => {
    await api.createUser(userData);
    await loadData();
  };

  const handleUpdateUser = async (id: string, userData: Partial<User>) => {
    await api.updateUser(id, userData);
    await loadData();
  };

  const handleAddStaff = async (staffData: Partial<CanBo>) => {
    await api.createStaff(staffData);
    await loadData();
  };

  const handleUpdateStaff = async (id: string, staffData: Partial<CanBo>) => {
    await api.updateStaff(id, staffData);
    await loadData();
  };

  const handleAddDept = async (deptData: Partial<PhongBan>) => {
    await api.createDepartment(deptData);
    await loadData();
  };

  const handleUpdateDept = async (id: string, deptData: Partial<PhongBan>) => {
    await api.updateDepartment(id, deptData);
    await loadData();
  };

  const handleAddProgram = async (progData: Partial<ChuongTrinh>) => {
    await api.createProgram(progData);
    await loadData();
  };

  const handleUpdateProgram = async (id: string, progData: Partial<ChuongTrinh>) => {
    await api.updateProgram(id, progData);
    await loadData();
  };

  // Pending counters for badges
  const pendingApprovalCount = requests.filter(
    (r) =>
      currentUser &&
      r.maPhongBan === currentUser.maPhongBan &&
      (r.trangThai === 'Chờ lãnh đạo phòng phê duyệt' || r.trangThai === 'Đề nghị mới')
  ).length;

  const pendingProcessCount = requests.filter((r) => r.trangThai === 'Chờ xử lý').length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#002855] to-[#004F9E] flex flex-col items-center justify-center p-4 text-white">
        <div className="bg-white p-4 rounded-2xl shadow-xl mb-4">
          <img
            src="https://raw.githubusercontent.com/giadinhbanker/anh-super-app-bac-phu-tho/main/Logo%20VietinBank.png"
            alt="VietinBank"
            className="h-10 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        <Loader2 className="w-8 h-8 text-blue-200 animate-spin mb-3" />
        <div className="text-base font-bold text-white tracking-wide">
          Hệ thống Quản lý Đề nghị Cấp quyền Chương trình
        </div>
        <div className="text-xs text-blue-200 mt-1 font-medium">
          VietinBank – Chi nhánh Ninh Bình • Đang khởi tạo dữ liệu...
        </div>
      </div>
    );
  }

  if (error && !currentUser && users.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white p-6 rounded-2xl border border-rose-200 shadow-lg max-w-md w-full text-center space-y-4">
          <AlertCircle className="w-12 h-12 text-rose-600 mx-auto" />
          <h2 className="text-lg font-bold text-gray-900">Không thể kết nối máy chủ</h2>
          <p className="text-xs text-gray-600 leading-relaxed">{error}</p>
          <button
            onClick={loadData}
            className="inline-flex items-center gap-2 bg-[#004F9E] text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow hover:bg-[#003B77] transition"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Thử lại</span>
          </button>
        </div>
      </div>
    );
  }

  // If not logged in, render the Login Screen
  if (!currentUser) {
    return (
      <LoginView
        users={users}
        onLogin={handleLogin}
        onAttemptLogin={handleAttemptLogin}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 font-sans antialiased flex flex-col selection:bg-blue-100 selection:text-[#004F9E]">
      {/* Mobile-First Sticky Header */}
      <MobileHeader
        currentUser={currentUser}
        users={users}
        onSwitchUser={handleSwitchUser}
        notifications={notifications}
        onRefreshData={loadData}
        onLogout={handleLogout}
        onNavigate={handleNavigate}
        activeTab={activeTab}
        onGoBack={handleGoBack}
        unreadCount={requests.filter((r) => r.trangThai === 'Chờ xử lý').length}
      />

      {/* Main Workspace Content Area */}
      <main className="flex-1 w-full max-w-2xl mx-auto px-3.5 pt-3 pb-24 sm:px-4 sm:pt-4 transition-all">
        {/* TAB: TRANG CHỦ (DASHBOARD MOBILE-FIRST) */}
        {activeTab === 'dashboard' && currentUser && (
          <MobileHomeView
            currentUser={currentUser}
            requests={requests}
            onNavigate={handleNavigate}
            onOpenCreate={() => handleNavigate('create-request')}
            onOpenPrint={(req) => setSelectedForPrint(req)}
            pendingApprovalCount={pendingApprovalCount}
            pendingProcessCount={pendingProcessCount}
          />
        )}

        {/* TAB: LẬP ĐỀ NGHỊ (6-STEP MOBILE WIZARD) */}
        {activeTab === 'create-request' && currentUser && (
          <MobileCreateRequestWizard
            currentUser={currentUser}
            activePrograms={programs.filter((p) => p.trangThai === 'Hoạt động')}
            staffList={staffList}
            onSubmit={handleCreateRequest}
            onCancel={handleGoBack}
            onViewRequests={() => handleNavigate('requests')}
            onOpenPrint={(req) => setSelectedForPrint(req)}
          />
        )}

        {/* TAB: DANH SÁCH ĐỀ NGHỊ */}
        {activeTab === 'requests' && currentUser && (
          <div className="space-y-3 pb-6">
            <MobilePageHeader
              title="Danh Sách Đề Nghị Cấp Quyền"
              subtitle="Theo dõi, tra cứu và in phiếu đề nghị cấp quyền người dùng"
              onBack={handleGoBack}
              backLabel="Trở lại Trang chủ"
              breadcrumbs={[{ label: 'Trang chủ' }, { label: 'Đề nghị' }]}
              badge={requests.length}
              rightAction={
                <button
                  type="button"
                  onClick={() => handleNavigate('create-request')}
                  className="min-h-[44px] px-3.5 py-2 bg-[#004F9E] hover:bg-[#003B77] text-white rounded-xl font-bold text-xs shadow-xs flex items-center gap-1.5 active:scale-95 transition cursor-pointer"
                >
                  <FilePlus className="w-4 h-4" />
                  <span>Lập đề nghị mới</span>
                </button>
              }
            />

            <RequestList
              requests={requests}
              currentUser={currentUser}
              departments={departments}
              programs={programs}
              onOpenCreate={() => handleNavigate('create-request')}
              onOpenApprove={(req) => setSelectedForApprove(req)}
              onOpenReject={(req) => setSelectedForApprove(req)}
              onOpenProcess={(req) => setSelectedForIT(req)}
              onOpenPrint={(req) => setSelectedForPrint(req)}
            />
          </div>
        )}

        {/* TAB: PHÊ DUYỆT CẤP QUYỀN */}
        {activeTab === 'approvals' && currentUser && (
          <MobileApprovalView
            currentUser={currentUser}
            requests={requests}
            departments={departments}
            programs={programs}
            onOpenApprove={(req) => setSelectedForApprove(req)}
            onOpenReject={(req) => setSelectedForApprove(req)}
            onOpenProcess={(req) => setSelectedForIT(req)}
            onOpenPrint={(req) => setSelectedForPrint(req)}
            onCreateNew={() => handleNavigate('create-request')}
            onBack={handleGoBack}
          />
        )}

        {/* TAB: QUẢN TRỊ (ADMIN ONLY HUB) */}
        {activeTab === 'admin-hub' && currentUser && (
          <AdminHubView
            currentUser={currentUser}
            onNavigate={handleNavigate}
          />
        )}

        {/* TAB: TÀI KHOẢN (PROFILE) */}
        {activeTab === 'profile' && currentUser && (
          <ProfileView
            currentUser={currentUser}
            users={users}
            onSwitchUser={handleSwitchUser}
            onLogout={handleLogout}
            onRefreshData={loadData}
            onNavigate={handleNavigate}
          />
        )}

        {/* TIỆN ÍCH: BẢNG TỔNG HỢP QUYỀN */}
        {activeTab === 'matrix' && (
          <div className="space-y-3 pb-6">
            <MobilePageHeader
              title="Bảng Tổng Hợp Phân Quyền"
              subtitle="Ma trận quyền ứng dụng CoreBanking, LOS, ECM theo từng vị trí cán bộ"
              onBack={handleGoBack}
              backLabel="Trở lại Trang chủ"
              breadcrumbs={[{ label: 'Trang chủ' }, { label: 'Tiện ích' }, { label: 'Tổng hợp quyền' }]}
            />
            <SummaryMatrixView
              programs={programs.filter((p) => p.trangThai === 'Hoạt động')}
              rows={matrixRows}
              departments={departments}
            />
          </div>
        )}

        {/* TIỆN ÍCH: TRA CỨU NÂNG CAO */}
        {activeTab === 'lookup' && currentUser && (
          <div className="space-y-3 pb-6">
            <MobilePageHeader
              title="Tra Cứu Đề Nghị Nâng Cao"
              subtitle="Bộ lọc đa tiêu chí theo mã phiếu, cán bộ, phòng ban và thời gian"
              onBack={handleGoBack}
              backLabel="Trở lại Trang chủ"
              breadcrumbs={[{ label: 'Trang chủ' }, { label: 'Tiện ích' }, { label: 'Tra cứu' }]}
            />
            <LookupView
              requests={requests}
              currentUser={currentUser}
              departments={departments}
              programs={programs}
              onOpenPrint={(req) => setSelectedForPrint(req)}
            />
          </div>
        )}

        {/* TIỆN ÍCH: CĂN CỨ & HƯỚNG DẪN */}
        {activeTab === 'guidelines' && currentUser && (
          <div className="space-y-3 pb-6">
            <MobilePageHeader
              title="Căn Cứ & Hướng Dẫn Phân Quyền"
              subtitle="Quy chế, quyết định ủy quyền và nguyên tắc thiết lập quyền người dùng"
              onBack={handleGoBack}
              backLabel={currentUser.chucVu === 'Admin' ? 'Quay lại Quản trị' : 'Trở lại Trang chủ'}
              homeFallback={currentUser.chucVu === 'Admin' ? () => handleNavigate('dashboard') : undefined}
              breadcrumbs={[{ label: 'Trang chủ' }, { label: 'Hướng dẫn' }]}
            />
            <AdminPermissionGuidelinesView
              programs={programs}
              departments={departments}
              currentUser={currentUser}
            />
          </div>
        )}

        {/* PHÂN HỆ QUẢN TRỊ CHI TIẾT - CHỈ DÀNH CHO ADMIN */}
        {['staff', 'users', 'programs', 'departments', 'audit', 'gas-guide'].includes(activeTab) && (
          <div className="space-y-3 pb-6">
            {currentUser?.chucVu !== 'Admin' ? (
              <AdminHubView
                currentUser={currentUser}
                onNavigate={handleNavigate}
              />
            ) : (
              <>
                <MobilePageHeader
                  title={
                    activeTab === 'staff'
                      ? 'Hồ Sơ Cán Bộ Chi Nhánh'
                      : activeTab === 'users'
                      ? 'Quản Lý Tài Khoản User AD'
                      : activeTab === 'programs'
                      ? 'Danh Mục Chương Trình Ứng Dụng'
                      : activeTab === 'departments'
                      ? 'Danh Mục Phòng Ban & Điểm Giao Dịch'
                      : activeTab === 'audit'
                      ? 'Nhật Ký Thao Tác Hệ Thống'
                      : 'Cấu Hình Tích Hợp Google Apps Script'
                  }
                  subtitle="Phân hệ Quản trị hệ thống VietinBank - CN Ninh Bình"
                  onBack={() => handleNavigate('admin-hub')}
                  backLabel="Quay lại Quản trị"
                  homeFallback={() => handleNavigate('dashboard')}
                  variant="admin"
                  breadcrumbs={[
                    { label: 'Trang chủ' },
                    { label: 'Quản trị' },
                    {
                      label:
                        activeTab === 'staff'
                          ? 'Cán bộ'
                          : activeTab === 'users'
                          ? 'User AD'
                          : activeTab === 'programs'
                          ? 'Ứng dụng'
                          : activeTab === 'departments'
                          ? 'Phòng ban'
                          : activeTab === 'audit'
                          ? 'Nhật ký'
                          : 'GAS Script'
                    }
                  ]}
                />

                {activeTab === 'staff' && (
                  <AdminStaffView
                    staffList={staffList}
                    departments={departments}
                    onAddStaff={handleAddStaff}
                    onUpdateStaff={handleUpdateStaff}
                  />
                )}

                {activeTab === 'users' && (
                  <AdminUsersView
                    users={users}
                    departments={departments}
                    onAddUser={handleAddUser}
                    onUpdateUser={handleUpdateUser}
                  />
                )}

                {activeTab === 'programs' && (
                  <AdminProgramsView
                    programs={programs}
                    onAddProgram={handleAddProgram}
                    onUpdateProgram={handleUpdateProgram}
                    onNavigateToGuidelines={() => handleNavigate('guidelines')}
                  />
                )}

                {activeTab === 'departments' && (
                  <AdminDepartmentsView
                    departments={departments}
                    onAddDepartment={handleAddDept}
                    onUpdateDepartment={handleUpdateDept}
                  />
                )}

                {activeTab === 'audit' && (
                  <AdminAuditLogView logs={auditLogs} />
                )}

                {activeTab === 'gas-guide' && (
                  <GASGuideView />
                )}
              </>
            )}
          </div>
        )}
      </main>

      {/* Mobile-First Bottom Navigation Bar */}
      <MobileBottomNav
        activeTab={activeTab}
        onSelectTab={handleNavigate}
        currentUser={currentUser}
        pendingApprovalCount={pendingApprovalCount}
        pendingProcessCount={pendingProcessCount}
      />

      {/* Global Modals */}
      {currentUser && (
        <CreateRequestModal
          currentUser={currentUser}
          activePrograms={programs.filter((p) => p.trangThai === 'Hoạt động')}
          isOpen={isCreateOpen}
          onClose={() => setIsCreateOpen(false)}
          onSubmit={handleCreateRequest}
          isSubmitting={isSubmitting}
        />
      )}

      {currentUser && (
        <ApprovalModal
          request={selectedForApprove}
          currentUser={currentUser}
          isOpen={!!selectedForApprove}
          onClose={() => setSelectedForApprove(null)}
          onApprove={handleApproveRequest}
          onReject={handleRejectRequest}
          isProcessing={isSubmitting}
        />
      )}

      {currentUser && (
        <ITProcessModal
          request={selectedForIT}
          currentUser={currentUser}
          isOpen={!!selectedForIT}
          onClose={() => setSelectedForIT(null)}
          onComplete={handleCompleteRequest}
          isProcessing={isSubmitting}
        />
      )}

      {currentUser && (
        <PrintTicketModal
          request={selectedForPrint}
          currentUser={currentUser}
          isOpen={!!selectedForPrint}
          onClose={() => setSelectedForPrint(null)}
        />
      )}
    </div>
  );
}
