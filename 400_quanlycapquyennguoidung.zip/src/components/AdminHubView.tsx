import React from 'react';
import { User } from '../types';
import { NavTab } from './Sidebar';
import {
  ShieldAlert,
  Users,
  UserCheck,
  Building,
  Layers,
  History,
  Code2,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
  Lock,
  Home
} from 'lucide-react';

interface AdminHubViewProps {
  currentUser: User;
  onNavigate: (tab: NavTab) => void;
}

export const AdminHubView: React.FC<AdminHubViewProps> = ({
  currentUser,
  onNavigate
}) => {
  // CRITICAL RBAC ENFORCEMENT: Only Admin is authorized
  if (currentUser.chucVu !== 'Admin') {
    return (
      <div
        id="admin-access-denied-view"
        className="max-w-md mx-auto my-8 bg-white rounded-3xl p-6 sm:p-8 border border-rose-200 shadow-xl text-center space-y-4 font-sans animate-fade-in"
      >
        <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
          <ShieldAlert className="w-9 h-9" />
        </div>

        <div>
          <div className="text-xs font-bold text-rose-600 uppercase tracking-wider mb-1">
            Truy cập bị từ chối
          </div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">
            Bạn không có quyền truy cập chức năng này
          </h2>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            Chức năng Quản trị hệ thống chỉ dành riêng cho Quản trị viên (Admin) được phân công của VietinBank - Chi nhánh Ninh Bình.
          </p>
        </div>

        <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-1">
          <div className="text-slate-500">Tài khoản hiện tại:</div>
          <div className="font-bold text-slate-800">
            {currentUser.hoTen} ({currentUser.userAD})
          </div>
          <div className="text-slate-500">
            Vai trò: <span className="font-bold text-rose-600">{currentUser.chucVu}</span>
          </div>
        </div>

        <button
          onClick={() => onNavigate('dashboard')}
          className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-[#004F9E] hover:bg-[#003B77] text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-98 cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>Quay về Trang chủ</span>
        </button>
      </div>
    );
  }

  // Admin Authorized Hub Content
  const adminModules = [
    {
      id: 'users',
      title: 'Quản Lý Tài Khoản User',
      desc: 'Cấp phát, khóa tài khoản và phân quyền User AD',
      icon: Users,
      color: 'bg-blue-100 text-blue-800 border-blue-200',
      badge: 'Bảo mật'
    },
    {
      id: 'staff',
      title: 'Hồ Sơ Cán Bộ',
      desc: 'Danh bạ cán bộ, chức vụ và tình trạng công tác',
      icon: UserCheck,
      color: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      badge: 'Nhân sự'
    },
    {
      id: 'programs',
      title: 'Danh Mục Chương Trình',
      desc: 'Cấu hình hệ thống CoreBanking, LOS, FastFund, ECM...',
      icon: Layers,
      color: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      badge: 'Ứng dụng'
    },
    {
      id: 'departments',
      title: 'Danh Mục Phòng Ban',
      desc: 'Cơ cấu tổ chức phòng ban và mạng lưới phòng giao dịch',
      icon: Building,
      color: 'bg-amber-100 text-amber-800 border-amber-200',
      badge: 'Cơ cấu'
    },
    {
      id: 'audit',
      title: 'Nhật Ký Audit Log',
      desc: 'Lịch sử thao tác, tạo lập, phê duyệt và xử lý',
      icon: History,
      color: 'bg-rose-100 text-rose-800 border-rose-200',
      badge: 'Kiểm toán'
    },
    {
      id: 'gas-guide',
      title: 'Google Sheets / GAS',
      desc: 'Cấu hình đồng bộ hai chiều thời gian thực với bảng tính Google',
      icon: Code2,
      color: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      badge: 'Đồng bộ'
    },
    {
      id: 'guidelines',
      title: 'Căn Cứ & Hướng Dẫn',
      desc: 'Quy chế phân quyền, ma trận Maker/Checker chi nhánh',
      icon: BookOpen,
      color: 'bg-purple-100 text-purple-800 border-purple-200',
      badge: 'Quy định'
    }
  ];

  return (
    <div className="max-w-xl mx-auto pb-24 font-sans space-y-3.5 animate-fade-in">
      {/* Prominent Back Button */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => onNavigate('dashboard')}
          className="min-h-[44px] inline-flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold text-xs bg-white hover:bg-slate-50 text-slate-800 hover:text-[#004F9E] border border-slate-200 shadow-xs transition active:scale-95 cursor-pointer"
        >
          <div className="w-6 h-6 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <ArrowLeft className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
          <span>Trở lại Trang chủ</span>
        </button>
      </div>

      {/* Top Header */}
      <div className="bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex items-start justify-between">
          <div>
            <div className="text-[10px] font-bold text-purple-200 uppercase tracking-wider">
              Khu vực quản trị hệ thống
            </div>
            <h1 className="text-lg sm:text-xl font-black tracking-tight mt-0.5">
              TRUNG TÂM QUẢN TRỊ
            </h1>
            <p className="text-xs text-purple-100 mt-1">
              VietinBank - CN Ninh Bình • Quyền hạn Admin cao nhất
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center text-xl shrink-0">
            ⚙️
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-white/15 flex items-center justify-between text-xs">
          <span className="text-purple-200 font-medium">Quản trị viên:</span>
          <span className="font-bold text-white">
            {currentUser.hoTen} ({currentUser.userAD})
          </span>
        </div>
      </div>

      {/* Modules List */}
      <div className="space-y-2.5">
        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
          Các phân hệ quản trị
        </div>

        {adminModules.map((mod) => {
          const Icon = mod.icon;
          return (
            <div
              key={mod.id}
              onClick={() => onNavigate(mod.id as NavTab)}
              className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:shadow-md hover:border-purple-300 transition cursor-pointer flex items-center justify-between group active:scale-98"
            >
              <div className="flex items-start space-x-3 min-w-0 pr-2">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${mod.color}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-black text-slate-900 group-hover:text-purple-700 transition truncate">
                      {mod.title}
                    </h3>
                    <span className="text-[9px] bg-slate-100 text-slate-600 font-bold px-1.5 py-0.2 rounded shrink-0">
                      {mod.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                    {mod.desc}
                  </p>
                </div>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-600 transition shrink-0 ml-2" />
            </div>
          );
        })}
      </div>

      {/* Return to Home */}
      <div className="pt-2">
        <button
          onClick={() => onNavigate('dashboard')}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition text-center"
        >
          ← Quay về Trang chủ
        </button>
      </div>
    </div>
  );
};
