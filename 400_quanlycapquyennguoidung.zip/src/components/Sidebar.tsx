import React from 'react';
import { User, UserRole } from '../types';
import {
  LayoutDashboard,
  FilePlus,
  FileText,
  Table,
  Search,
  Users,
  UserCheck,
  Building,
  Layers,
  History,
  Code2,
  Settings,
  LogOut,
  ChevronRight,
  BookOpen,
  CheckCircle2
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'create-request'
  | 'requests'
  | 'approvals'
  | 'admin-hub'
  | 'profile'
  | 'matrix'
  | 'lookup'
  | 'guidelines'
  | 'users'
  | 'staff'
  | 'departments'
  | 'programs'
  | 'audit'
  | 'gas-guide'
  | 'config';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  currentUser: User | null;
  pendingApprovalCount?: number;
  pendingProcessCount?: number;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  pendingApprovalCount = 0,
  pendingProcessCount = 0,
  onLogout
}) => {
  if (!currentUser) return null;

  const role = currentUser.chucVu;

  interface NavItem {
    id: NavTab;
    label: string;
    icon: React.ElementType;
    badge?: number;
    badgeColor?: string;
    roles: UserRole[];
    section?: 'main' | 'admin';
  }

  const navItems: NavItem[] = [
    {
      id: 'dashboard',
      label: 'Bảng Điều Khiển',
      icon: LayoutDashboard,
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    {
      id: 'create-request',
      label: 'Lập Đề Nghị Mới',
      icon: FilePlus,
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    {
      id: 'requests',
      label: 'Quản Lý Đề Nghị',
      icon: FileText,
      badge:
        role === 'Lãnh đạo phòng'
          ? pendingApprovalCount
          : role === 'Cán bộ điện toán'
          ? pendingProcessCount
          : undefined,
      badgeColor: 'bg-red-500',
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    {
      id: 'guidelines',
      label: 'Căn Cứ & Hướng Dẫn',
      icon: BookOpen,
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    {
      id: 'approvals',
      label: 'Phê Duyệt Cấp Quyền',
      icon: CheckCircle2,
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    {
      id: 'matrix',
      label: 'Tổng Hợp Quyền',
      icon: Table,
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    {
      id: 'lookup',
      label: 'Tra Cứu Nâng Cao',
      icon: Search,
      roles: ['Cán bộ', 'Lãnh đạo phòng', 'Cán bộ điện toán', 'Admin'],
      section: 'main'
    },
    // Quản trị (Chỉ Admin)
    {
      id: 'staff',
      label: 'Hồ Sơ Cán Bộ',
      icon: UserCheck,
      roles: ['Admin'],
      section: 'admin'
    },
    {
      id: 'users',
      label: 'Quản Lý Tài Khoản User',
      icon: Users,
      roles: ['Admin'],
      section: 'admin'
    },
    {
      id: 'programs',
      label: 'Danh Mục Chương Trình',
      icon: Layers,
      roles: ['Admin'],
      section: 'admin'
    },
    {
      id: 'departments',
      label: 'Danh Mục Phòng Ban',
      icon: Building,
      roles: ['Admin'],
      section: 'admin'
    },
    {
      id: 'audit',
      label: 'Nhật Ký Audit Log',
      icon: History,
      roles: ['Admin'],
      section: 'admin'
    },
    {
      id: 'gas-guide',
      label: 'Google Sheets / GAS',
      icon: Code2,
      roles: ['Admin'],
      section: 'admin'
    }
  ];

  const mainNav = navItems.filter((i) => i.section === 'main' && i.roles.includes(role));
  const adminNav = navItems.filter((i) => i.section === 'admin' && i.roles.includes(role));

  const renderItem = (item: NavItem) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id;
    const isCreate = item.id === 'create-request';
    const isRequests = item.id === 'requests';

    return (
      <button
        key={item.id}
        onClick={() => onSelectTab(item.id)}
        className={`w-full flex items-center justify-between px-4 py-2.5 text-xs font-medium transition-all duration-150 cursor-pointer ${
          isActive
            ? 'text-white bg-[#ffffff20] border-l-4 border-[#DE1C24] font-bold shadow-inner'
            : isCreate
            ? 'text-amber-200 bg-white/10 hover:bg-white/20 hover:text-white border-l-4 border-amber-400 font-semibold'
            : isRequests
            ? 'text-white bg-white/5 hover:bg-white/15 hover:text-white border-l-4 border-transparent font-medium'
            : 'text-white/75 hover:bg-[#ffffff10] hover:text-white border-l-4 border-transparent'
        }`}
      >
        <div className="flex items-center space-x-3 truncate">
          <Icon
            className={`w-4 h-4 flex-shrink-0 ${
              isActive
                ? 'text-white'
                : isCreate
                ? 'text-amber-300'
                : 'text-white/80'
            }`}
          />
          <span className="truncate">{item.label}</span>
        </div>
        <div className="flex items-center space-x-1.5 flex-shrink-0">
          {isCreate && !isActive && (
            <span className="text-[9px] bg-[#DE1C24] text-white font-bold px-1.5 py-0.5 rounded shadow-xs">
              + MỚI
            </span>
          )}
          {item.badge !== undefined && item.badge > 0 && (
            <span
              className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full text-white ${
                item.badgeColor || 'bg-red-500'
              }`}
            >
              {item.badge}
            </span>
          )}
        </div>
      </button>
    );
  };

  return (
    <aside className="w-64 bg-[#0054A3] flex flex-col flex-shrink-0 shadow-xl border-r border-[#004280]">
      {/* VietinBank Brand Header */}
      <div className="p-4 border-b border-white/15">
        <div className="bg-white rounded-xl p-2 shadow flex items-center justify-center">
          <img
            src="https://raw.githubusercontent.com/giadinhbanker/anh-super-app-bac-phu-tho/main/Logo%20VietinBank.png"
            alt="VietinBank"
            className="h-8 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="text-center mt-2">
          <div className="text-blue-100 text-[11px] font-bold tracking-wider uppercase">
            Chi nhánh Ninh Bình
          </div>
          <div className="text-blue-200/80 text-[10px] font-medium">
            Quản lý Cấp quyền Ứng dụng
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 py-3 text-xs overflow-y-auto space-y-1">
        <div className="px-4 py-1.5 text-white/40 uppercase text-[10px] font-bold tracking-widest">
          Nghiệp vụ chính
        </div>
        {mainNav.map(renderItem)}

        {adminNav.length > 0 && (
          <>
            <div className="mt-5 px-4 py-1.5 text-white/40 uppercase text-[10px] font-bold tracking-widest border-t border-white/10 pt-3">
              Hệ thống & Danh mục
            </div>
            {adminNav.map(renderItem)}
          </>
        )}
      </nav>

      {/* User Info Bar at bottom of sidebar (High Density style) */}
      <div className="p-3.5 bg-[#004280] border-t border-white/10 flex items-center">
        <div className="w-9 h-9 rounded-full bg-[#DE1C24] flex items-center justify-center font-bold text-white text-xs shadow-inner flex-shrink-0">
          {currentUser.hoTen.charAt(0)}
        </div>
        <div className="ml-2.5 min-w-0 flex-1">
          <div className="text-white text-xs font-semibold truncate leading-tight">
            {currentUser.hoTen}
          </div>
          <div className="text-white/60 text-[10px] uppercase truncate mt-0.5 font-medium">
            {currentUser.chucVu} • {currentUser.maPhongBan}
          </div>
        </div>
        {onLogout && (
          <button
            onClick={onLogout}
            title="Đăng xuất"
            className="text-white/70 hover:text-white p-1 rounded transition ml-1"
          >
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>
    </aside>
  );
};
