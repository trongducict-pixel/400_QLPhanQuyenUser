import React, { useState } from 'react';
import { User, NotificationItem } from '../types';
import {
  Bell,
  LogOut,
  RefreshCw,
  User as UserIcon,
  Shield,
  ChevronDown,
  Menu,
  X,
  ExternalLink,
  BookOpen,
  Table,
  Search,
  CheckCircle2,
  ArrowLeft
} from 'lucide-react';
import { NavTab } from './Sidebar';

interface MobileHeaderProps {
  currentUser: User;
  users?: User[];
  onSwitchUser?: (user: User) => void;
  notifications?: NotificationItem[];
  onRefreshData?: () => void;
  onLogout: () => void;
  onNavigate: (tab: NavTab) => void;
  unreadCount?: number;
  activeTab?: NavTab;
  onGoBack?: () => void;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  currentUser,
  users = [],
  onSwitchUser,
  notifications = [],
  onRefreshData,
  onLogout,
  onNavigate,
  unreadCount = 0,
  activeTab,
  onGoBack
}) => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    if (!onRefreshData) return;
    setIsRefreshing(true);
    try {
      await onRefreshData();
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'Admin':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Cán bộ điện toán':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Lãnh đạo phòng':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <>
      <header
        id="mobile-main-header"
        className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs px-3.5 py-2.5 transition-all"
      >
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          {/* Brand & Greeting */}
          <div className="flex items-center space-x-2 sm:space-x-2.5 min-w-0">
            {/* Quick Back Button when not on dashboard */}
            {activeTab && activeTab !== 'dashboard' && onGoBack && (
              <button
                type="button"
                id="header-back-button"
                onClick={onGoBack}
                className="h-9 px-2 sm:px-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#004F9E] border border-blue-200 shadow-xs flex items-center gap-1 font-bold text-xs active:scale-95 transition-all cursor-pointer shrink-0"
                title="Quay lại màn hình trước"
              >
                <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                <span className="text-[11px]">Trở lại</span>
              </button>
            )}

            {/* VietinBank Icon */}
            <div className="h-9 w-9 bg-white border border-slate-200 rounded-xl p-1 shadow-xs flex items-center justify-center shrink-0">
              <img
                src="https://raw.githubusercontent.com/giadinhbanker/anh-super-app-bac-phu-tho/main/Logo%20VietinBank.png"
                alt="VietinBank"
                className="h-6 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="min-w-0">
              <div className="text-[11px] font-bold text-[#004F9E] uppercase tracking-wide truncate">
                VietinBank - CN Ninh Bình
              </div>
              <div className="text-sm font-black text-slate-900 truncate leading-tight flex items-center gap-1.5">
                <span>Xin chào, {currentUser.hoTen.split(' ').slice(-2).join(' ') || currentUser.hoTen}</span>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${getRoleBadge(
                    currentUser.chucVu
                  )} shrink-0`}
                >
                  {currentUser.chucVu}
                </span>
              </div>
            </div>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center space-x-1 sm:space-x-2 shrink-0">
            {/* Sync button */}
            {onRefreshData && (
              <button
                id="header-refresh-btn"
                onClick={handleRefresh}
                title="Đồng bộ dữ liệu"
                className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 active:scale-95 transition cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#004F9E]' : ''}`} />
              </button>
            )}

            {/* Notification Bell */}
            <div className="relative">
              <button
                id="header-notification-btn"
                onClick={() => setShowNotifs(!showNotifs)}
                className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 active:scale-95 transition relative cursor-pointer"
                title="Thông báo"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-600 rounded-full ring-2 ring-white" />
                )}
              </button>

              {/* Notification Popover */}
              {showNotifs && (
                <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                    <span className="text-xs font-bold text-slate-900">Thông báo hệ thống</span>
                    <span className="text-[10px] bg-blue-50 text-[#004F9E] font-bold px-2 py-0.5 rounded-full">
                      {notifications.length} tin
                    </span>
                  </div>
                  <div className="max-h-60 overflow-y-auto space-y-2 text-xs">
                    {notifications.length === 0 ? (
                      <div className="py-4 text-center text-slate-400 text-xs">
                        Không có thông báo mới
                      </div>
                    ) : (
                      notifications.slice(0, 5).map((n) => (
                        <div
                          key={n.id}
                          className="p-2 bg-slate-50 hover:bg-blue-50/60 rounded-xl transition cursor-pointer"
                          onClick={() => {
                            setShowNotifs(false);
                            onNavigate('requests');
                          }}
                        >
                          <div className="font-semibold text-slate-900 text-[11px] leading-tight">
                            {n.tieuDe}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-2">
                            {n.noiDung}
                          </div>
                          <div className="text-[9px] text-slate-400 mt-1">{n.thoiGian}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Avatar / Menu Toggle */}
            <div className="relative">
              <button
                id="header-user-menu-btn"
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-1.5 p-1 pl-2 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 transition cursor-pointer"
              >
                <div className="w-6 h-6 rounded-lg bg-[#004F9E] text-white flex items-center justify-center text-[10px] font-black">
                  {currentUser.userAD.substring(0, 2).toUpperCase()}
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {/* User Dropdown */}
              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="pb-3 border-b border-slate-100">
                    <div className="text-xs font-bold text-slate-900">{currentUser.hoTen}</div>
                    <div className="text-[11px] text-slate-500 font-mono">User AD: {currentUser.userAD}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      {currentUser.tenPhongBan} ({currentUser.maPhongBan})
                    </div>
                  </div>

                  {/* Switch user option (useful for dev testing) */}
                  {users.length > 1 && onSwitchUser && (
                    <div className="py-2 border-b border-slate-100">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Chuyển tài khoản (Test role):
                      </label>
                      <select
                        value={currentUser.userAD}
                        onChange={(e) => {
                          const target = users.find((u) => u.userAD === e.target.value);
                          if (target) {
                            onSwitchUser(target);
                            setShowUserMenu(false);
                          }
                        }}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-slate-800 font-medium"
                      >
                        {users.map((u) => (
                          <option key={u.id} value={u.userAD}>
                            {u.hoTen} ({u.chucVu})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Links */}
                  <div className="py-1.5 space-y-1">
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onNavigate('profile' as any);
                      }}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-slate-700 hover:bg-slate-50 text-left font-medium"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                      <span>Thông tin tài khoản</span>
                    </button>
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        setShowDrawer(true);
                      }}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-slate-700 hover:bg-slate-50 text-left font-medium"
                    >
                      <Menu className="w-3.5 h-3.5 text-slate-500" />
                      <span>Tiện ích tra cứu mở rộng</span>
                    </button>
                  </div>

                  {/* Logout */}
                  <div className="pt-2 border-t border-slate-100">
                    <button
                      id="header-logout-btn"
                      onClick={() => {
                        setShowUserMenu(false);
                        onLogout();
                      }}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-rose-600 hover:bg-rose-50 text-left font-bold transition"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-600" />
                      <span>Đăng xuất</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Hamburger for extra utilities */}
            <button
              id="header-drawer-toggle"
              onClick={() => setShowDrawer(true)}
              className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 active:scale-95 transition cursor-pointer"
              title="Menu tiện ích"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Slide-over Drawer for Extra Utilities (Matrix, Lookup, Guidelines) */}
      {showDrawer && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
            onClick={() => setShowDrawer(false)}
          />

          {/* Drawer Content */}
          <div className="relative ml-auto w-full max-w-xs bg-white h-full shadow-2xl p-5 flex flex-col justify-between overflow-y-auto z-10 animate-in slide-in-from-right duration-200">
            <div>
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center space-x-2">
                  <div className="h-8 px-2 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center">
                    <img
                      src="https://raw.githubusercontent.com/giadinhbanker/anh-super-app-bac-phu-tho/main/Logo%20VietinBank.png"
                      alt="VietinBank"
                      className="h-5 w-auto object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Danh Mục Tiện Ích</div>
                    <div className="text-[10px] text-slate-500">VietinBank Ninh Bình</div>
                  </div>
                </div>
                <button
                  onClick={() => setShowDrawer(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Utility Nav Links */}
              <div className="mt-4 space-y-1.5">
                <button
                  onClick={() => {
                    setShowDrawer(false);
                    onNavigate('dashboard');
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-[#004F9E] transition"
                >
                  <span className="text-base">🏠</span>
                  <span>Trang chủ</span>
                </button>

                <button
                  onClick={() => {
                    setShowDrawer(false);
                    onNavigate('requests');
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-[#004F9E] transition"
                >
                  <span className="text-base">🔐</span>
                  <span>Đề nghị cấp quyền</span>
                </button>

                <button
                  onClick={() => {
                    setShowDrawer(false);
                    onNavigate('approvals' as any);
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-[#004F9E] transition"
                >
                  <span className="text-base">✅</span>
                  <span>Phê duyệt cấp quyền</span>
                </button>

                <div className="pt-3 pb-1">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3">
                    Tiện ích nâng cao
                  </div>
                </div>

                <button
                  onClick={() => {
                    setShowDrawer(false);
                    onNavigate('matrix');
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-[#004F9E] transition"
                >
                  <Table className="w-4 h-4 text-blue-600" />
                  <span>Bảng tổng hợp quyền</span>
                </button>

                <button
                  onClick={() => {
                    setShowDrawer(false);
                    onNavigate('lookup');
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-[#004F9E] transition"
                >
                  <Search className="w-4 h-4 text-emerald-600" />
                  <span>Tra cứu nâng cao</span>
                </button>

                <button
                  onClick={() => {
                    setShowDrawer(false);
                    onNavigate('guidelines');
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-[#004F9E] transition"
                >
                  <BookOpen className="w-4 h-4 text-amber-600" />
                  <span>Căn cứ & Hướng dẫn</span>
                </button>

                {/* Admin Only in Drawer */}
                {currentUser.chucVu === 'Admin' && (
                  <>
                    <div className="pt-3 pb-1">
                      <div className="text-[10px] font-bold text-purple-600 uppercase tracking-wider px-3">
                        Khu vực Quản trị (Admin)
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setShowDrawer(false);
                        onNavigate('admin-hub' as any);
                      }}
                      className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 transition"
                    >
                      <span className="text-base">⚙️</span>
                      <span>Trung tâm Quản trị</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="pt-4 border-t border-slate-100">
              <button
                onClick={() => {
                  setShowDrawer(false);
                  onLogout();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-rose-50 text-rose-700 font-bold text-xs hover:bg-rose-100 transition"
              >
                <LogOut className="w-4 h-4" />
                <span>Đăng xuất khỏi hệ thống</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
