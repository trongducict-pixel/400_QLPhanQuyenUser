import React, { useState } from 'react';
import { User, RequestRecord, PhongBan, ChuongTrinh } from '../types';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Printer,
  Search,
  Filter,
  AlertTriangle,
  UserCheck,
  Building,
  ArrowRight,
  ShieldCheck,
  FileText,
  ArrowLeft
} from 'lucide-react';

interface MobileApprovalViewProps {
  currentUser: User;
  requests: RequestRecord[];
  departments: PhongBan[];
  programs: ChuongTrinh[];
  onOpenApprove: (req: RequestRecord) => void;
  onOpenReject: (req: RequestRecord) => void;
  onOpenProcess?: (req: RequestRecord) => void;
  onOpenPrint: (req: RequestRecord) => void;
  onCreateNew?: () => void;
  onBack?: () => void;
}

export const MobileApprovalView: React.FC<MobileApprovalViewProps> = ({
  currentUser,
  requests,
  departments,
  programs,
  onOpenApprove,
  onOpenReject,
  onOpenProcess,
  onOpenPrint,
  onCreateNew,
  onBack
}) => {
  const isLeader = currentUser.chucVu === 'Lãnh đạo phòng';
  const isIT = currentUser.chucVu === 'Cán bộ điện toán';
  const isAdmin = currentUser.chucVu === 'Admin';

  // Sub-tabs
  const [activeSubTab, setActiveSubTab] = useState<'pending' | 'history'>('pending');
  const [searchTerm, setSearchTerm] = useState('');

  // Pending requests that require this user's action
  const pendingRequests = requests.filter((r) => {
    if (isLeader) {
      return (
        r.maPhongBan === currentUser.maPhongBan &&
        (r.trangThai === 'Chờ lãnh đạo phòng phê duyệt' || r.trangThai === 'Đề nghị mới')
      );
    }
    if (isIT) {
      return r.trangThai === 'Chờ xử lý';
    }
    if (isAdmin) {
      return (
        r.trangThai === 'Chờ lãnh đạo phòng phê duyệt' ||
        r.trangThai === 'Chờ xử lý' ||
        r.trangThai === 'Đề nghị mới'
      );
    }
    // For regular staff: show their pending requests being processed
    return r.userAD === currentUser.userAD && r.trangThai !== 'Hoàn thành' && r.trangThai !== 'Từ chối';
  });

  // History requests
  const historyRequests = requests.filter((r) => {
    if (isLeader) {
      return r.maPhongBan === currentUser.maPhongBan && (r.trangThai === 'Hoàn thành' || r.trangThai === 'Từ chối' || r.trangThai === 'Chờ xử lý');
    }
    if (isIT) {
      return r.trangThai === 'Hoàn thành' || r.trangThai === 'Từ chối';
    }
    if (isAdmin) {
      return r.trangThai === 'Hoàn thành' || r.trangThai === 'Từ chối';
    }
    return r.userAD === currentUser.userAD && (r.trangThai === 'Hoàn thành' || r.trangThai === 'Từ chối');
  });

  const displayList = activeSubTab === 'pending' ? pendingRequests : historyRequests;

  const filteredList = displayList.filter(
    (r) =>
      r.maDeNghi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.hoTen.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.userAD.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.tenChuongTrinh.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.soQDTuyenDung_PhanCong.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Hoàn thành':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Chờ xử lý':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Chờ lãnh đạo phòng phê duyệt':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Từ chối':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="max-w-xl mx-auto pb-24 font-sans space-y-3.5 animate-fade-in">
      {/* Prominent Back Button */}
      {onBack && (
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] inline-flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold text-xs bg-white hover:bg-slate-50 text-slate-800 hover:text-[#004F9E] border border-slate-200 shadow-xs transition active:scale-95 cursor-pointer"
          >
            <div className="w-6 h-6 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
              <ArrowLeft className="w-3.5 h-3.5 stroke-[2.5]" />
            </div>
            <span>Trở lại Trang chủ</span>
          </button>
        </div>
      )}

      {/* View Header */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold text-[#004F9E] uppercase tracking-wider">
              Nghiệp vụ phê duyệt
            </div>
            <h2 className="text-base font-black text-slate-900 tracking-tight">
              {isLeader
                ? 'Phê Duyệt Đề Nghị Phòng Ban'
                : isIT
                ? 'Xử Lý Cấp Quyền Điện Toán'
                : isAdmin
                ? 'Giám Sát & Phê Duyệt Hệ Thống'
                : 'Tiến Độ Phê Duyệt Đề Nghị'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isLeader
                ? `Thẩm quyền phê duyệt: ${currentUser.tenPhongBan} (${currentUser.maPhongBan})`
                : isIT
                ? 'Bộ phận Tin học & Điện toán - VietinBank Chi nhánh Ninh Bình'
                : 'Theo dõi tình trạng phê duyệt từ Lãnh đạo phòng đến Điện toán'}
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center text-xl shrink-0">
            ✅
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100">
          <button
            onClick={() => setActiveSubTab('pending')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeSubTab === 'pending'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>
              {isLeader || isAdmin || isIT ? 'Cần xử lý' : 'Đang chờ duyệt'}
            </span>
            {pendingRequests.length > 0 && (
              <span
                className={`text-[10px] font-black px-1.5 py-0.2 rounded-full ${
                  activeSubTab === 'pending' ? 'bg-white text-emerald-700' : 'bg-rose-600 text-white'
                }`}
              >
                {pendingRequests.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('history')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeSubTab === 'history'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>Lịch sử đã duyệt ({historyRequests.length})</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative mt-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã đề nghị, họ tên cán bộ, chương trình..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-600 focus:bg-white"
          />
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {filteredList.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-400 text-xs shadow-xs">
            <div className="text-3xl mb-2">🎉</div>
            <div className="font-bold text-slate-700">
              {activeSubTab === 'pending'
                ? 'Không có đề nghị nào đang chờ xử lý'
                : 'Không có dữ liệu trong lịch sử'}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Tất cả các đề nghị đã được xử lý kịp thời.
            </p>
          </div>
        ) : (
          filteredList.map((req) => (
            <div
              key={req.id}
              className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:shadow-md transition space-y-3"
            >
              {/* Card Top: Code & Badge */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200">
                      {req.maDeNghi}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(
                        req.trangThai
                      )}`}
                    >
                      {req.trangThai}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-[#004F9E] mt-1">
                    {req.tenChuongTrinh} ({req.maChuongTrinh})
                  </div>
                </div>

                <span className="text-[10px] bg-blue-50 text-[#004F9E] font-bold px-2 py-0.5 rounded border border-blue-200 shrink-0">
                  {req.loaiDeNghi}
                </span>
              </div>

              {/* Requester Info */}
              <div className="p-2.5 bg-slate-50 rounded-xl text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Cán bộ:</span>
                  <span className="font-bold text-slate-800">
                    {req.hoTen} ({req.userAD})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Phòng ban:</span>
                  <span className="text-slate-700 font-medium">
                    {req.tenPhongBan} ({req.maPhongBan})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Văn bản căn cứ:</span>
                  <span className="font-mono text-[11px] text-slate-700 font-medium">
                    {req.soQDTuyenDung_PhanCong}
                  </span>
                </div>
                <div className="pt-1 text-slate-600 leading-tight">
                  <span className="font-semibold text-slate-700">Nội dung: </span>
                  {req.noiDung}
                </div>
              </div>

              {/* Approval Info if available */}
              {req.nguoiDuyet && (
                <div className="text-[11px] text-emerald-800 bg-emerald-50/70 p-2 rounded-xl border border-emerald-100 flex items-center justify-between">
                  <span>Lãnh đạo phê duyệt: <strong>{req.nguoiDuyet}</strong></span>
                  <span className="text-[10px] text-emerald-600">{req.thoiGianDuyet}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-1 flex items-center justify-between gap-2">
                <button
                  onClick={() => onOpenPrint(req)}
                  className="flex items-center gap-1 py-1.5 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer"
                  title="In phiếu A4"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>In phiếu</span>
                </button>

                <div className="flex items-center gap-1.5">
                  {/* Action for Leader: Duyệt / Từ chối */}
                  {isLeader && req.trangThai === 'Chờ lãnh đạo phòng phê duyệt' && (
                    <>
                      <button
                        onClick={() => onOpenReject(req)}
                        className="py-1.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold transition border border-rose-200 cursor-pointer"
                      >
                        Từ chối
                      </button>
                      <button
                        onClick={() => onOpenApprove(req)}
                        className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Phê duyệt</span>
                      </button>
                    </>
                  )}

                  {/* Action for IT: Xử lý cấp quyền */}
                  {isIT && req.trangThai === 'Chờ xử lý' && onOpenProcess && (
                    <button
                      onClick={() => onOpenProcess(req)}
                      className="py-1.5 px-3 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Xử lý cấp quyền</span>
                    </button>
                  )}

                  {/* Action for Admin */}
                  {isAdmin && req.trangThai === 'Chờ lãnh đạo phòng phê duyệt' && (
                    <button
                      onClick={() => onOpenApprove(req)}
                      className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                    >
                      Duyệt thay LĐ
                    </button>
                  )}
                  {isAdmin && req.trangThai === 'Chờ xử lý' && onOpenProcess && (
                    <button
                      onClick={() => onOpenProcess(req)}
                      className="py-1.5 px-3 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white text-xs font-bold transition shadow-xs cursor-pointer"
                    >
                      Xử lý Điện toán
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
