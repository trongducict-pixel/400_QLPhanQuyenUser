import React from 'react';
import { User } from '../types';
import { NavTab } from './Sidebar';
import {
  User as UserIcon,
  Shield,
  Building,
  Mail,
  Phone,
  LogOut,
  RefreshCw,
  CheckCircle2,
  Users,
  Lock,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';

interface ProfileViewProps {
  currentUser: User;
  users?: User[];
  onSwitchUser?: (user: User) => void;
  onLogout: () => void;
  onRefreshData?: () => void;
  onNavigate: (tab: NavTab) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  users = [],
  onSwitchUser,
  onLogout,
  onRefreshData,
  onNavigate
}) => {
  return (
    <div className="max-w-xl mx-auto pb-24 font-sans space-y-4 animate-fade-in">
      {/* Prominent Back Button */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => onNavigate('dashboard')}
          className="min-h-[44px] inline-flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold text-xs bg-white hover:bg-slate-50 text-slate-800 hover:text-[#004F9E] border border-slate-200 shadow-xs transition active:scale-95 cursor-pointer"
        >
          <div className="w-6 h-6 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <ArrowLeft className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
          <span>Trở lại Trang chủ</span>
        </button>
      </div>

      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#003B77] to-[#004F9E] rounded-3xl p-6 text-white text-center shadow-md relative overflow-hidden">
        <div className="w-16 h-16 rounded-full bg-white/20 border-2 border-white/30 text-white flex items-center justify-center font-black text-2xl mx-auto mb-3 shadow-sm">
          {currentUser.userAD.substring(0, 2).toUpperCase()}
        </div>
        <h2 className="text-lg font-black">{currentUser.hoTen}</h2>
        <p className="text-xs text-blue-200 mt-0.5 font-mono">User AD: {currentUser.userAD}</p>
        <div className="mt-2 inline-flex items-center gap-1 bg-white/15 px-3 py-1 rounded-full text-xs font-bold border border-white/20">
          <Shield className="w-3.5 h-3.5 text-emerald-300" />
          <span>{currentUser.chucVu}</span>
        </div>
      </div>

      {/* Detail Info Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3 text-xs">
        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-100">
          Thông tin chi tiết
        </div>

        <div className="flex justify-between items-center py-1">
          <span className="text-slate-500 flex items-center gap-2">
            <Building className="w-4 h-4 text-slate-400" />
            <span>Phòng ban:</span>
          </span>
          <span className="font-bold text-slate-800 text-right">
            {currentUser.tenPhongBan} ({currentUser.maPhongBan})
          </span>
        </div>

        <div className="flex justify-between items-center py-1">
          <span className="text-slate-500 flex items-center gap-2">
            <Mail className="w-4 h-4 text-slate-400" />
            <span>Email liên hệ:</span>
          </span>
          <span className="font-medium text-slate-800 font-mono">
            {currentUser.email || `${currentUser.userAD}@vietinbank.vn`}
          </span>
        </div>

        <div className="flex justify-between items-center py-1">
          <span className="text-slate-500 flex items-center gap-2">
            <Phone className="w-4 h-4 text-slate-400" />
            <span>Số điện thoại:</span>
          </span>
          <span className="font-medium text-slate-800">
            {currentUser.soDienThoai || 'Nội bộ 0229.xxx.xxx'}
          </span>
        </div>

        <div className="flex justify-between items-center py-1">
          <span className="text-slate-500 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span>Trạng thái tài khoản:</span>
          </span>
          <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            {currentUser.trangThai}
          </span>
        </div>
      </div>

      {/* Switch User for Testing / Demo */}
      {users.length > 1 && onSwitchUser && (
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-[#004F9E]" />
              <span>Chuyển đổi tài khoản (Thử nghiệm Role)</span>
            </div>
          </div>
          <p className="text-[11px] text-slate-500">
            Chọn một tài khoản khác để kiểm tra giao diện phân quyền tương ứng.
          </p>
          <select
            value={currentUser.userAD}
            onChange={(e) => {
              const u = users.find((item) => item.userAD === e.target.value);
              if (u) onSwitchUser(u);
            }}
            className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-medium text-slate-900 focus:ring-2 focus:ring-[#004F9E]"
          >
            {users.map((u) => (
              <option key={u.id} value={u.userAD}>
                {u.hoTen} ({u.userAD}) - {u.chucVu}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Actions */}
      <div className="space-y-2 pt-2">
        <button
          type="button"
          onClick={() => onNavigate('dashboard')}
          className="w-full min-h-[46px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-200 shadow-xs transition active:scale-95 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-slate-600" />
          <span>Trở lại Trang chủ</span>
        </button>

        {onRefreshData && (
          <button
            onClick={onRefreshData}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Đồng bộ dữ liệu hệ thống</span>
          </button>
        )}

        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200 transition cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Đăng xuất khỏi hệ thống</span>
        </button>
      </div>
    </div>
  );
};
