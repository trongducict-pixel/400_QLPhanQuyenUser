import React from 'react';
import { ArrowLeft, Home, ChevronRight } from 'lucide-react';
import { NavTab } from './Sidebar';

interface BreadcrumbItem {
  label: string;
  tab?: NavTab;
}

interface MobilePageHeaderProps {
  title: string;
  subtitle?: string;
  onBack: () => void;
  backLabel?: string;
  homeFallback?: () => void;
  breadcrumbs?: BreadcrumbItem[];
  badge?: string | number;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'admin' | 'blue';
}

export const MobilePageHeader: React.FC<MobilePageHeaderProps> = ({
  title,
  subtitle,
  onBack,
  backLabel = 'Trở lại',
  homeFallback,
  breadcrumbs = [],
  badge,
  rightAction,
  variant = 'default'
}) => {
  const isSpecialAdmin = variant === 'admin';

  return (
    <div
      id="mobile-page-header"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-3.5 sm:p-4 mb-3.5 space-y-2.5 transition-all"
    >
      {/* Top Navigation Row: Big Back Button & Actions */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {/* Main Prominent Back Button */}
          <button
            type="button"
            onClick={onBack}
            className={`inline-flex items-center gap-2.5 min-h-[46px] px-4 py-2.5 rounded-xl font-black text-xs shadow-xs transition-all active:scale-95 cursor-pointer border-2 select-none ${
              isSpecialAdmin
                ? 'bg-purple-50 hover:bg-purple-100 text-purple-900 border-purple-300 hover:border-purple-500'
                : 'bg-white hover:bg-blue-50 text-slate-900 hover:text-[#004F9E] border-slate-300 hover:border-[#004F9E]'
            }`}
            title={backLabel}
          >
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                isSpecialAdmin ? 'bg-purple-200 text-purple-900' : 'bg-blue-100 text-[#004F9E]'
              }`}
            >
              <ArrowLeft className="w-4 h-4 stroke-[3]" />
            </div>
            <span className="truncate max-w-[180px] sm:max-w-xs">{backLabel}</span>
          </button>

          {/* Quick Home shortcut if user is deep in subviews */}
          {homeFallback && (
            <button
              type="button"
              onClick={homeFallback}
              className="min-h-[44px] w-11 flex items-center justify-center rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200 transition-all active:scale-95 cursor-pointer shrink-0"
              title="Về Trang chủ"
            >
              <Home className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Right side custom action or badge */}
        {rightAction && <div className="shrink-0">{rightAction}</div>}
      </div>

      {/* Breadcrumb Path (if provided) */}
      {breadcrumbs.length > 0 && (
        <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium overflow-x-auto scrollbar-none py-0.5">
          {breadcrumbs.map((crumb, idx) => (
            <React.Fragment key={idx}>
              {idx > 0 && <ChevronRight className="w-3 h-3 text-slate-300 shrink-0" />}
              <span
                className={`truncate ${
                  idx === breadcrumbs.length - 1
                    ? 'text-slate-700 font-semibold'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {crumb.label}
              </span>
            </React.Fragment>
          ))}
        </div>
      )}

      {/* Title & Subtitle */}
      <div className="pt-0.5 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight truncate">
              {title}
            </h1>
            {badge !== undefined && (
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                  isSpecialAdmin
                    ? 'bg-purple-100 text-purple-800 border-purple-200'
                    : 'bg-blue-50 text-[#004F9E] border-blue-200'
                }`}
              >
                {badge}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-0.5 line-clamp-2 leading-relaxed">
              {subtitle}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
