import React from 'react';
import { User, RequestRecord } from '../types';
import { NavTab } from './Sidebar';
import {
  Lock,
  CheckCircle2,
  Settings,
  PlusCircle,
  FileText,
  Clock,
  ArrowRight,
  ShieldCheck,
  Building,
  UserCheck,
  AlertCircle,
  Printer,
  ChevronRight,
  Table,
  Search,
  BookOpen
} from 'lucide-react';

interface MobileHomeViewProps {
  currentUser: User;
  requests: RequestRecord[];
  onNavigate: (tab: NavTab) => void;
  onOpenCreate: () => void;
  onOpenPrint?: (req: RequestRecord) => void;
  pendingApprovalCount: number;
  pendingProcessCount: number;
}

export const MobileHomeView: React.FC<MobileHomeViewProps> = ({
  currentUser,
  requests,
  onNavigate,
  onOpenCreate,
  onOpenPrint,
  pendingApprovalCount,
  pendingProcessCount
}) => {
  const isAdmin = currentUser.chucVu === 'Admin';
  const isLeader = currentUser.chucVu === 'Lãnh đạo phòng';
  const isIT = currentUser.chucVu === 'Cán bộ điện toán';

  // Requests created by this user
  const myRequests = requests.filter((r) => r.userAD === currentUser.userAD);
  const myPendingRequests = myRequests.filter(
    (r) => r.trangThai !== 'Hoàn thành' && r.trangThai !== 'Từ chối'
  );
  const myCompletedRequests = myRequests.filter((r) => r.trangThai === 'Hoàn thành');

  // Approval count based on role
  const pendingCount = isLeader ? pendingApprovalCount : isIT ? pendingProcessCount : 0;

  // Pipeline counts
  const countStep1 = requests.filter((r) => r.trangThai === 'Chờ lãnh đạo phòng phê duyệt').length;
  const countStep2 = requests.filter((r) => r.trangThai === 'Chờ xử lý').length;
  const countStep3 = requests.filter((r) => r.trangThai === 'Hoàn thành').length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Hoàn thành':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Chờ xử lý':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Chờ lãnh đạo phòng phê duyệt':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Từ chối':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-20 font-sans">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-[#003B77] via-[#004F9E] to-[#0060BA] rounded-2xl p-4 sm:p-5 text-white shadow-md">
        <div className="absolute -right-8 -bottom-8 w-36 h-36 bg-white/10 rounded-full blur-xl pointer-events-none" />
        <div className="relative z-10 flex items-start justify-between">
          <div>
            <div className="text-[11px] font-bold text-blue-200 uppercase tracking-wider">
              VietinBank - CN Ninh Bình
            </div>
            <h1 className="text-lg sm:text-xl font-black tracking-tight mt-0.5">
              Xin chào, {currentUser.hoTen}
            </h1>
            <p className="text-xs text-blue-100 mt-1 flex items-center gap-1.5 font-medium">
              <span>{currentUser.tenPhongBan}</span>
              <span>•</span>
              <span className="font-bold underline">{currentUser.chucVu}</span>
            </p>
          </div>
          <div className="h-10 w-10 bg-white/15 rounded-xl flex items-center justify-center text-lg font-black shrink-0 border border-white/20">
            {currentUser.userAD.substring(0, 2).toUpperCase()}
          </div>
        </div>

        {/* Quick self stats banner */}
        <div className="mt-4 pt-3 border-t border-white/15 grid grid-cols-2 gap-2 text-center text-xs">
          <div className="bg-white/10 rounded-xl p-2">
            <div className="text-[10px] text-blue-200">Đề nghị của tôi</div>
            <div className="text-base font-black text-white">{myRequests.length}</div>
          </div>
          <div className="bg-white/10 rounded-xl p-2">
            <div className="text-[10px] text-blue-200">Đang tiến hành</div>
            <div className="text-base font-black text-amber-300">{myPendingRequests.length}</div>
          </div>
        </div>
      </div>

      {/* Trục nghiệp vụ chính của hệ thống: ĐỀ NGHỊ -> PHÊ DUYỆT -> ĐIỆN TOÁN XỬ LÝ -> HOÀN TẤT */}
      <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs">
        <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2.5 flex items-center justify-between">
          <span>Quy trình cấp quyền</span>
          <span className="text-[10px] text-blue-600 font-medium">4 giai đoạn chuẩn</span>
        </div>
        <div className="grid grid-cols-4 gap-1 sm:gap-2 text-center">
          {/* Step 1 */}
          <div className="p-2 rounded-xl bg-blue-50/70 border border-blue-100 flex flex-col items-center justify-between">
            <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold mb-1">
              1
            </div>
            <div className="text-[10px] font-bold text-slate-800 leading-tight">Đề nghị</div>
            <div className="text-[9px] text-slate-500 mt-0.5">Tạo mới</div>
          </div>

          {/* Step 2 */}
          <div className="p-2 rounded-xl bg-amber-50/70 border border-amber-100 flex flex-col items-center justify-between">
            <div className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-[10px] font-bold mb-1">
              2
            </div>
            <div className="text-[10px] font-bold text-slate-800 leading-tight">Phê duyệt</div>
            <div className="text-[9px] text-amber-700 font-semibold mt-0.5">
              {countStep1} đang chờ
            </div>
          </div>

          {/* Step 3 */}
          <div className="p-2 rounded-xl bg-indigo-50/70 border border-indigo-100 flex flex-col items-center justify-between">
            <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px] font-bold mb-1">
              3
            </div>
            <div className="text-[10px] font-bold text-slate-800 leading-tight">Điện toán</div>
            <div className="text-[9px] text-indigo-700 font-semibold mt-0.5">
              {countStep2} đang xử lý
            </div>
          </div>

          {/* Step 4 */}
          <div className="p-2 rounded-xl bg-emerald-50/70 border border-emerald-100 flex flex-col items-center justify-between">
            <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold mb-1">
              4
            </div>
            <div className="text-[10px] font-bold text-slate-800 leading-tight">Hoàn tất</div>
            <div className="text-[9px] text-emerald-700 font-semibold mt-0.5">
              {countStep3} thành công
            </div>
          </div>
        </div>
      </div>

      {/* 3 CARDS CHÍNH THEO ĐẶC TẢ YÊU CẦU */}
      <div className="space-y-3">
        {/* CARD 1: 🔐 ĐỀ NGHỊ CẤP QUYỀN */}
        <div
          id="home-card-create-request"
          className="bg-white rounded-2xl border-2 border-blue-100 p-4 sm:p-5 shadow-xs hover:shadow-md transition relative overflow-hidden"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-[#004F9E] flex items-center justify-center text-2xl shrink-0">
                🔐
              </div>
              <div>
                <h2 className="text-base font-black text-slate-900 tracking-tight">
                  ĐỀ NGHỊ CẤP QUYỀN
                </h2>
                <p className="text-xs text-slate-600 mt-0.5">
                  Tạo mới và theo dõi đề nghị cấp quyền
                </p>
              </div>
            </div>
            {myPendingRequests.length > 0 && (
              <span className="text-[10px] bg-blue-50 text-[#004F9E] font-bold px-2 py-0.5 rounded-full border border-blue-200 shrink-0">
                {myPendingRequests.length} đang chờ
              </span>
            )}
          </div>

          {/* Action buttons inside Card 1 */}
          <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
            <button
              id="home-btn-create-now"
              onClick={onOpenCreate}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#004F9E] to-[#003B77] text-white font-bold text-xs shadow-sm hover:from-[#003B77] hover:to-[#002855] active:scale-95 transition cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Tạo đề nghị mới</span>
            </button>
            <button
              id="home-btn-view-requests"
              onClick={() => onNavigate('requests')}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-100 text-slate-800 font-bold text-xs hover:bg-slate-200 active:scale-95 transition cursor-pointer"
            >
              <FileText className="w-4 h-4 text-slate-600" />
              <span>Xem danh sách</span>
            </button>
          </div>
        </div>

        {/* CARD 2: ✅ PHÊ DUYỆT CẤP QUYỀN */}
        <div
          id="home-card-approvals"
          className="bg-white rounded-2xl border-2 border-emerald-100 p-4 sm:p-5 shadow-xs hover:shadow-md transition relative overflow-hidden"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center text-2xl shrink-0">
                ✅
              </div>
              <div>
                <h2 className="text-base font-black text-slate-900 tracking-tight">
                  PHÊ DUYỆT CẤP QUYỀN
                </h2>
                <p className="text-xs text-slate-600 mt-0.5">
                  Xem và phê duyệt các đề nghị thuộc thẩm quyền
                </p>
              </div>
            </div>
            {pendingCount > 0 ? (
              <span className="text-[10px] bg-rose-600 text-white font-black px-2 py-0.5 rounded-full animate-pulse shrink-0">
                {pendingCount} cần duyệt
              </span>
            ) : (
              <span className="text-[10px] bg-slate-100 text-slate-600 font-medium px-2 py-0.5 rounded-full shrink-0">
                Không có tồn
              </span>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              id="home-btn-open-approvals"
              onClick={() => onNavigate('approvals' as any)}
              className="w-full flex items-center justify-between py-2.5 px-3.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-200 active:scale-98 transition cursor-pointer"
            >
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                {isLeader
                  ? `Phê duyệt cho ${currentUser.tenPhongBan} (${pendingCount} chờ)`
                  : isIT
                  ? `Xử lý cấp quyền trên hệ thống (${pendingProcessCount} chờ)`
                  : 'Xem tiến độ phê duyệt đề nghị của bạn'}
              </span>
              <ArrowRight className="w-4 h-4 text-emerald-600" />
            </button>
          </div>
        </div>

        {/* CARD 3: ⚙️ QUẢN TRỊ - CHỈ HIỂN THỊ KHI USER LÀ ADMIN */}
        {isAdmin && (
          <div
            id="home-card-admin"
            className="bg-white rounded-2xl border-2 border-purple-200 p-4 sm:p-5 shadow-xs hover:shadow-md transition relative overflow-hidden bg-gradient-to-br from-white to-purple-50/40"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-purple-100 border border-purple-300 text-purple-800 flex items-center justify-center text-2xl shrink-0">
                  ⚙️
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h2 className="text-base font-black text-slate-900 tracking-tight">
                      QUẢN TRỊ
                    </h2>
                    <span className="text-[9px] bg-purple-600 text-white font-black px-1.5 py-0.2 rounded uppercase">
                      Admin
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Quản lý người dùng, danh mục và hệ thống
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-purple-100">
              <button
                id="home-btn-open-admin-hub"
                onClick={() => onNavigate('admin-hub' as any)}
                className="w-full flex items-center justify-between py-2.5 px-3.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs active:scale-98 transition cursor-pointer"
              >
                <span>Vào trung tâm Quản trị hệ thống</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ĐỀ NGHỊ GẦN ĐÂY CỦA TÔI */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-[#004F9E]" />
            <span>Đề nghị của tôi gần đây</span>
          </div>
          <button
            onClick={() => onNavigate('requests')}
            className="text-[11px] font-bold text-[#004F9E] hover:underline"
          >
            Xem tất cả ({myRequests.length})
          </button>
        </div>

        {myRequests.length === 0 ? (
          <div className="text-center py-6 text-slate-400 text-xs">
            Bạn chưa có đề nghị cấp quyền nào.{' '}
            <button onClick={onOpenCreate} className="text-[#004F9E] font-bold underline ml-1">
              Tạo đề nghị ngay
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {myRequests.slice(0, 3).map((req) => (
              <div
                key={req.id}
                className="p-2.5 bg-slate-50 hover:bg-blue-50/50 rounded-xl border border-slate-100 flex items-center justify-between transition cursor-pointer"
                onClick={() => onNavigate('requests')}
              >
                <div className="min-w-0 pr-2">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-[11px] font-bold text-slate-900">
                      {req.maDeNghi}
                    </span>
                    <span className="text-[10px] bg-slate-200 text-slate-800 font-semibold px-1.5 py-0.2 rounded">
                      {req.loaiDeNghi}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-[#004F9E] truncate mt-0.5">
                    {req.tenChuongTrinh}
                  </div>
                  <div className="text-[10px] text-slate-500">{req.ngayTao}</div>
                </div>

                <div className="shrink-0 flex items-center gap-1.5">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(
                      req.trangThai
                    )}`}
                  >
                    {req.trangThai}
                  </span>
                  {onOpenPrint && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenPrint(req);
                      }}
                      title="In phiếu đề nghị A4"
                      className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* TIỆN ÍCH MỞ RỘNG (QUICK ACCESS) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">
          Tiện ích tra cứu
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <button
            onClick={() => onNavigate('matrix')}
            className="p-2.5 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-100 hover:border-blue-200 transition text-slate-800 flex flex-col items-center justify-center cursor-pointer"
          >
            <Table className="w-5 h-5 text-blue-600 mb-1" />
            <span className="text-[11px] font-bold leading-tight">Tổng hợp quyền</span>
          </button>

          <button
            onClick={() => onNavigate('lookup')}
            className="p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 border border-slate-100 hover:border-emerald-200 transition text-slate-800 flex flex-col items-center justify-center cursor-pointer"
          >
            <Search className="w-5 h-5 text-emerald-600 mb-1" />
            <span className="text-[11px] font-bold leading-tight">Tra cứu</span>
          </button>

          <button
            onClick={() => onNavigate('guidelines')}
            className="p-2.5 rounded-xl bg-slate-50 hover:bg-amber-50 border border-slate-100 hover:border-amber-200 transition text-slate-800 flex flex-col items-center justify-center cursor-pointer"
          >
            <BookOpen className="w-5 h-5 text-amber-600 mb-1" />
            <span className="text-[11px] font-bold leading-tight">Căn cứ & HD</span>
          </button>
        </div>
      </div>
    </div>
  );
};
