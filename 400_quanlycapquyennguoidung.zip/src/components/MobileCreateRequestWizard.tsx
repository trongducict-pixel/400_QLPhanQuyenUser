import React, { useState, useMemo } from 'react';
import { User, ChuongTrinh, RequestType, CanBo, RequestRecord } from '../types';
import {
  UserCheck,
  Layers,
  FileText,
  Send,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Search,
  Building,
  Printer,
  Home,
  List,
  Sparkles,
  HelpCircle,
  Users
} from 'lucide-react';

interface MobileCreateRequestWizardProps {
  currentUser: User;
  activePrograms: ChuongTrinh[];
  staffList?: CanBo[];
  onSubmit: (data: {
    maChuongTrinh: string;
    loaiDeNghi: RequestType;
    soQDTuyenDung_PhanCong: string;
    noiDung: string;
    targetUserAD?: string;
  }) => Promise<any>;
  onCancel: () => void;
  onViewRequests: () => void;
  onOpenPrint?: (req: RequestRecord) => void;
}

export const MobileCreateRequestWizard: React.FC<MobileCreateRequestWizardProps> = ({
  currentUser,
  activePrograms,
  staffList = [],
  onSubmit,
  onCancel,
  onViewRequests,
  onOpenPrint
}) => {
  // Wizard current step: 1 to 6
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Step 1: Beneficiary Mode & Selected Staff
  const [beneficiaryMode, setBeneficiaryMode] = useState<'SELF' | 'COLLEAGUE'>('SELF');
  const [selectedStaffUserAD, setSelectedStaffUserAD] = useState<string>(currentUser.userAD);
  const [colleagueSearch, setColleagueSearch] = useState<string>('');

  // Step 2: Selected Program
  const [selectedProgramCode, setSelectedProgramCode] = useState<string>(
    activePrograms.length > 0 ? activePrograms[0].maChuongTrinh : ''
  );
  const [programSearch, setProgramSearch] = useState<string>('');

  // Step 3: Request Type
  const [loaiDeNghi, setLoaiDeNghi] = useState<RequestType>('Cấp mới');

  // Step 4: Decision & Justification
  const [soQDTuyenDung, setSoQDTuyenDung] = useState<string>('QĐ 128/QĐ-NHCT-NB');
  const [noiDung, setNoiDung] = useState<string>('');

  // Execution state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [createdRequest, setCreatedRequest] = useState<RequestRecord | null>(null);

  // Department-based isolation logic for staff selection:
  // Non-admin/non-IT can ONLY create for themselves or staff in their own department
  const isManagerOrAdmin =
    currentUser.chucVu === 'Admin' ||
    currentUser.chucVu === 'Cán bộ điện toán' ||
    currentUser.maPhongBan === 'BGD';

  const eligibleDepartmentStaff = useMemo(() => {
    return staffList.filter((s) => {
      if (isManagerOrAdmin) return true;
      return (
        s.maPhongBan === currentUser.maPhongBan ||
        s.tenPhongBan === currentUser.tenPhongBan
      );
    });
  }, [staffList, currentUser, isManagerOrAdmin]);

  const filteredDepartmentColleagues = useMemo(() => {
    return eligibleDepartmentStaff.filter((s) => {
      if (s.userAD === currentUser.userAD) return false;
      const q = colleagueSearch.toLowerCase().trim();
      if (!q) return true;
      return (
        s.hoTen.toLowerCase().includes(q) ||
        (s.userAD && s.userAD.toLowerCase().includes(q)) ||
        (s.chucVu && s.chucVu.toLowerCase().includes(q))
      );
    });
  }, [eligibleDepartmentStaff, currentUser.userAD, colleagueSearch]);

  // Identify selected staff details
  const targetStaff = useMemo(() => {
    if (beneficiaryMode === 'SELF') {
      return {
        hoTen: currentUser.hoTen,
        userAD: currentUser.userAD,
        maCanBo: 'CB-' + currentUser.userAD,
        tenPhongBan: currentUser.tenPhongBan,
        maPhongBan: currentUser.maPhongBan,
        chucVu: currentUser.chucVu
      };
    }
    const found = staffList.find((s) => s.userAD === selectedStaffUserAD);
    if (found) {
      return {
        hoTen: found.hoTen,
        userAD: found.userAD,
        maCanBo: found.maCanBo || 'CB-' + found.userAD,
        tenPhongBan: found.tenPhongBan || currentUser.tenPhongBan,
        maPhongBan: found.maPhongBan || currentUser.maPhongBan,
        chucVu: found.chucVu || found.vaiTro || 'Cán bộ'
      };
    }
    return {
      hoTen: currentUser.hoTen,
      userAD: currentUser.userAD,
      maCanBo: 'CB-' + currentUser.userAD,
      tenPhongBan: currentUser.tenPhongBan,
      maPhongBan: currentUser.maPhongBan,
      chucVu: currentUser.chucVu
    };
  }, [beneficiaryMode, selectedStaffUserAD, staffList, currentUser]);

  const selectedProgram = activePrograms.find((p) => p.maChuongTrinh === selectedProgramCode);

  const filteredPrograms = activePrograms.filter(
    (p) =>
      p.maChuongTrinh.toLowerCase().includes(programSearch.toLowerCase()) ||
      p.tenChuongTrinh.toLowerCase().includes(programSearch.toLowerCase()) ||
      (p.moTa && p.moTa.toLowerCase().includes(programSearch.toLowerCase()))
  );

  // Validation before going to confirmation
  const validateStep4 = () => {
    if (!soQDTuyenDung.trim()) {
      setErrorMessage('Vui lòng nhập Số Quyết định hoặc Văn bản phân công nhiệm vụ.');
      return false;
    }
    if (!noiDung.trim()) {
      setErrorMessage('Vui lòng nhập Nội dung hoặc lý do đề nghị cấp quyền.');
      return false;
    }
    setErrorMessage('');
    return true;
  };

  // Submit action at Step 5
  const handleConfirmSubmit = async () => {
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await onSubmit({
        maChuongTrinh: selectedProgramCode,
        loaiDeNghi,
        soQDTuyenDung_PhanCong: soQDTuyenDung.trim(),
        noiDung: noiDung.trim(),
        targetUserAD: targetStaff.userAD
      });

      // Check return
      if (res && res.maDeNghi) {
        setCreatedRequest(res);
      } else {
        // Mock snapshot if void
        setCreatedRequest({
          id: `req-${Date.now()}`,
          maDeNghi: `CN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
          ngayTao: new Date().toLocaleDateString('vi-VN'),
          maUserAD: currentUser.maUserAD,
          maCanBo: 'CB-' + currentUser.userAD,
          hoTen: targetStaff.hoTen,
          userAD: targetStaff.userAD,
          maPhongBan: targetStaff.maPhongBan || currentUser.maPhongBan,
          tenPhongBan: targetStaff.tenPhongBan || currentUser.tenPhongBan,
          maChuongTrinh: selectedProgramCode,
          tenChuongTrinh: selectedProgram?.tenChuongTrinh || selectedProgramCode,
          loaiDeNghi,
          soQDTuyenDung_PhanCong: soQDTuyenDung.trim(),
          noiDung: noiDung.trim(),
          trangThai: 'Chờ lãnh đạo phòng phê duyệt',
          nguoiLap: currentUser.hoTen,
          targetUserAD: targetStaff.userAD
        });
      }

      setCurrentStep(6);
    } catch (err: any) {
      setErrorMessage(err.message || 'Có lỗi xảy ra khi gửi đề nghị cấp quyền.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quick fill samples for Step 4
  const fillTemplate = (sampleText: string) => {
    setNoiDung(sampleText);
  };

  return (
    <div className="max-w-xl mx-auto pb-24 font-sans animate-fade-in">
      {/* Top Header Bar for Wizard */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-3 shadow-xs mb-3.5 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={currentStep === 1 || currentStep === 6 ? onCancel : () => setCurrentStep(currentStep - 1)}
          className="min-h-[46px] inline-flex items-center gap-2.5 px-4 py-2 rounded-xl font-extrabold text-xs bg-white hover:bg-slate-100 text-slate-900 border-2 border-slate-300 hover:border-[#004F9E] shadow-xs transition active:scale-95 cursor-pointer"
        >
          <div className="w-6 h-6 rounded-lg bg-blue-100 text-[#004F9E] flex items-center justify-center shrink-0 font-bold">
            <ArrowLeft className="w-3.5 h-3.5 stroke-[3]" />
          </div>
          <span className="font-black">{currentStep === 1 || currentStep === 6 ? 'Trở lại Trang chủ' : 'Quay lại bước trước'}</span>
        </button>

        <div className="text-right">
          <div className="text-[10px] font-bold text-[#004F9E] uppercase tracking-wider">
            {currentStep < 6 ? `Bước ${currentStep} / 5` : 'Hoàn tất'}
          </div>
          <div className="text-xs font-black text-slate-800 truncate max-w-[150px]">
            {currentStep === 1 && '1. Chọn cán bộ'}
            {currentStep === 2 && '2. Chọn ứng dụng'}
            {currentStep === 3 && '3. Loại đề nghị'}
            {currentStep === 4 && '4. Căn cứ & Quyền'}
            {currentStep === 5 && '5. Xác nhận gửi'}
            {currentStep === 6 && 'Biên nhận đề nghị'}
          </div>
        </div>
      </div>

      {/* Progress Stepper Bar (for Steps 1-5) */}
      {currentStep < 6 && (
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs mb-4">
          <div className="flex items-center justify-between text-[11px] font-bold mb-2">
            <span
              className={
                currentStep === 1 ? 'text-[#004F9E]' : currentStep > 1 ? 'text-emerald-600' : 'text-slate-400'
              }
            >
              1. Cán bộ
            </span>
            <span
              className={
                currentStep === 2 ? 'text-[#004F9E]' : currentStep > 2 ? 'text-emerald-600' : 'text-slate-400'
              }
            >
              2. Ứng dụng
            </span>
            <span
              className={
                currentStep === 3 ? 'text-[#004F9E]' : currentStep > 3 ? 'text-emerald-600' : 'text-slate-400'
              }
            >
              3. Loại
            </span>
            <span
              className={
                currentStep === 4 ? 'text-[#004F9E]' : currentStep > 4 ? 'text-emerald-600' : 'text-slate-400'
              }
            >
              4. Căn cứ
            </span>
            <span className={currentStep === 5 ? 'text-[#004F9E]' : 'text-slate-400'}>5. Xác nhận</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-[#004F9E] h-full transition-all duration-300 rounded-full"
              style={{ width: `${(currentStep / 5) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Error notification if any */}
      {errorMessage && (
        <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-start gap-2 animate-fade-in">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
          <span className="font-medium">{errorMessage}</span>
        </div>
      )}

      {/* ============================================================ */}
      {/* BƯỚC 1: CHỌN NGƯỜI ĐƯỢC CẤP QUYỀN */}
      {/* ============================================================ */}
      {currentStep === 1 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-4">
          <div>
            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-[#004F9E] text-xs font-black flex items-center justify-center">
                1
              </span>
              <span>Người được cấp quyền</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Bạn chỉ có thể lập đề nghị cấp quyền cho chính mình hoặc cán bộ thuộc phòng <span className="font-bold text-[#004F9E]">{currentUser.tenPhongBan}</span>.
            </p>
          </div>

          {/* Mode Tabs: Cho chính tôi vs Cho đồng nghiệp */}
          <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setBeneficiaryMode('SELF');
                setSelectedStaffUserAD(currentUser.userAD);
              }}
              className={`min-h-[44px] px-3 py-2 rounded-lg font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                beneficiaryMode === 'SELF'
                  ? 'bg-white text-[#004F9E] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCheck className="w-4 h-4 shrink-0" />
              <span>Cho chính tôi</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setBeneficiaryMode('COLLEAGUE');
                if (filteredDepartmentColleagues.length > 0 && selectedStaffUserAD === currentUser.userAD) {
                  setSelectedStaffUserAD(filteredDepartmentColleagues[0].userAD);
                }
              }}
              className={`min-h-[44px] px-3 py-2 rounded-lg font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                beneficiaryMode === 'COLLEAGUE'
                  ? 'bg-white text-[#004F9E] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span>Cán bộ trong phòng</span>
            </button>
          </div>

          {/* Beneficiary Card Details */}
          {beneficiaryMode === 'SELF' ? (
            <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50/70 rounded-2xl border-2 border-blue-200">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-xl bg-[#004F9E] text-white flex items-center justify-center font-black text-base shrink-0 shadow-xs">
                  {currentUser.userAD ? currentUser.userAD.substring(0, 2).toUpperCase() : 'CB'}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-900">{currentUser.hoTen}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                      Tài khoản của bạn
                    </span>
                  </div>
                  <div className="text-xs text-slate-600 font-mono mt-0.5">User AD: <span className="font-bold text-[#004F9E]">{currentUser.userAD}</span></div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {currentUser.tenPhongBan} ({currentUser.maPhongBan}) • {currentUser.chucVu}
                  </div>
                </div>
              </div>
              <div className="mt-3 pt-2.5 border-t border-blue-200/80 flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Vai trò người thực hiện:</span>
                <span className="font-bold text-[#004F9E] bg-white px-2 py-0.5 rounded border border-blue-200">
                  {currentUser.chucVu}
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {/* Department restriction note */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-start gap-2 text-xs text-amber-900">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <div>
                  <span className="font-bold">Quy định phân quyền: </span>
                  Hệ thống chỉ hiển thị cán bộ thuộc cùng phòng ban <span className="font-black text-amber-950">({currentUser.tenPhongBan})</span> để đảm bảo bảo mật dữ liệu nghiệp vụ.
                </div>
              </div>

              {/* Colleague Search Input */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={colleagueSearch}
                  onChange={(e) => setColleagueSearch(e.target.value)}
                  placeholder="Tìm tên đồng nghiệp hoặc User AD..."
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#004F9E] focus:bg-white"
                />
              </div>

              {/* List of Colleagues */}
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {filteredDepartmentColleagues.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400 bg-slate-50 rounded-xl border border-slate-200">
                    Không tìm thấy cán bộ nào trong phòng phù hợp.
                  </div>
                ) : (
                  filteredDepartmentColleagues.map((colleague) => {
                    const isSelected = selectedStaffUserAD === colleague.userAD;
                    return (
                      <div
                        key={colleague.id}
                        onClick={() => setSelectedStaffUserAD(colleague.userAD)}
                        className={`p-3 rounded-xl border-2 transition cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-blue-50/90 border-[#004F9E] shadow-xs'
                            : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900 truncate">
                              {colleague.hoTen}
                            </span>
                            <span className="text-[10px] font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-700">
                              {colleague.userAD}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-1">
                            {colleague.chucVu || colleague.vaiTro || 'Cán bộ'} • {colleague.tenPhongBan}
                          </div>
                        </div>

                        <div className="shrink-0">
                          <div
                            className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                              isSelected
                                ? 'bg-[#004F9E] border-[#004F9E] text-white'
                                : 'border-slate-300 bg-white'
                            }`}
                          >
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Selected Colleague Preview */}
              {targetStaff.userAD !== currentUser.userAD && (
                <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 text-xs">
                  <div className="font-bold text-[#004F9E] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Đang chọn người được cấp: {targetStaff.hoTen} ({targetStaff.userAD})</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Next & Back Buttons for Step 1 */}
          <div className="pt-3 flex gap-2.5">
            <button
              type="button"
              onClick={onCancel}
              className="w-2/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs border-2 border-slate-300 hover:border-slate-400 shadow-xs transition active:scale-95 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-slate-700 stroke-[2.5]" />
              <span>Trở lại Trang chủ</span>
            </button>
            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              className="w-3/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
            >
              <span>Tiếp tục (Bước 2: Ứng dụng)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* BƯỚC 2: CHỌN CHƯƠNG TRÌNH / HỆ THỐNG */}
      {/* ============================================================ */}
      {currentStep === 2 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-4">
          <div>
            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-[#004F9E] text-xs font-black flex items-center justify-center">
                2
              </span>
              <span>Chọn chương trình / hệ thống</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Chọn hệ thống ứng dụng ngân hàng cần đăng ký hoặc thay đổi quyền.
            </p>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={programSearch}
              onChange={(e) => setProgramSearch(e.target.value)}
              placeholder="Tìm kiếm theo mã hoặc tên chương trình (Core, LOS...)"
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#004F9E] focus:bg-white"
            />
          </div>

          {/* Program list cards */}
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {filteredPrograms.map((prog) => {
              const isSelected = prog.maChuongTrinh === selectedProgramCode;
              return (
                <div
                  key={prog.id}
                  onClick={() => setSelectedProgramCode(prog.maChuongTrinh)}
                  className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-50/80 border-[#004F9E] shadow-xs'
                      : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-[11px] font-bold text-[#004F9E] bg-white px-2 py-0.5 rounded border border-blue-200">
                        {prog.maChuongTrinh}
                      </span>
                      <span className="text-xs font-bold text-slate-900 truncate">
                        {prog.tenChuongTrinh}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                      {prog.moTa || prog.moTaNghiepVu || 'Chương trình ứng dụng nghiệp vụ nội bộ'}
                    </div>
                  </div>

                  <div className="shrink-0">
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                        isSelected
                          ? 'bg-[#004F9E] border-[#004F9E] text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Next & Back Buttons for Step 2 */}
          <div className="pt-3 flex gap-2.5">
            <button
              type="button"
              onClick={() => setCurrentStep(1)}
              className="w-2/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs border-2 border-slate-300 hover:border-slate-400 shadow-xs transition active:scale-95 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-slate-700 stroke-[2.5]" />
              <span>← Về Bước 1</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (!selectedProgramCode) {
                  setErrorMessage('Vui lòng chọn 1 chương trình ứng dụng.');
                  return;
                }
                setErrorMessage('');
                setCurrentStep(3);
              }}
              className="w-3/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
            >
              <span>Tiếp tục (Bước 3: Loại ĐN)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* BƯỚC 3: CHỌN LOẠI ĐỀ NGHỊ */}
      {/* ============================================================ */}
      {currentStep === 3 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-4">
          <div>
            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-[#004F9E] text-xs font-black flex items-center justify-center">
                3
              </span>
              <span>Chọn loại đề nghị</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Đang áp dụng cho chương trình: <span className="font-bold text-[#004F9E]">{selectedProgram?.tenChuongTrinh}</span>
            </p>
          </div>

          {/* 3 Request Types Big Touch Cards */}
          <div className="space-y-2.5">
            {/* 1. Cấp mới */}
            <div
              onClick={() => setLoaiDeNghi('Cấp mới')}
              className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-start gap-3 ${
                loaiDeNghi === 'Cấp mới'
                  ? 'bg-blue-50/90 border-[#004F9E] shadow-sm'
                  : 'bg-slate-50 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full border mt-0.5 shrink-0 flex items-center justify-center ${
                  loaiDeNghi === 'Cấp mới'
                    ? 'bg-[#004F9E] border-[#004F9E] text-white'
                    : 'border-slate-300 bg-white'
                }`}
              >
                {loaiDeNghi === 'Cấp mới' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
              <div>
                <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                  <span>CẤP MỚI</span>
                  <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.2 rounded">
                    Phổ biến
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                  Cấp mới tài khoản truy cập hoặc phân quyền lần đầu cho cán bộ mới tuyển dụng hoặc điều động nhận nhiệm vụ mới.
                </div>
              </div>
            </div>

            {/* 2. Thay đổi */}
            <div
              onClick={() => setLoaiDeNghi('Thay đổi')}
              className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-start gap-3 ${
                loaiDeNghi === 'Thay đổi'
                  ? 'bg-amber-50/90 border-amber-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full border mt-0.5 shrink-0 flex items-center justify-center ${
                  loaiDeNghi === 'Thay đổi'
                    ? 'bg-amber-600 border-amber-600 text-white'
                    : 'border-slate-300 bg-white'
                }`}
              >
                {loaiDeNghi === 'Thay đổi' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
              <div>
                <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                  <span>THAY ĐỔI</span>
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">
                    Điều chỉnh / Reset
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                  Thay đổi nhóm quyền, mở rộng phân hệ, bổ sung hạn mức phê duyệt, thay đổi vai trò Maker/Checker hoặc reset mật khẩu.
                </div>
              </div>
            </div>

            {/* 3. Hủy người dùng */}
            <div
              onClick={() => setLoaiDeNghi('Hủy người dùng')}
              className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-start gap-3 ${
                loaiDeNghi === 'Hủy người dùng'
                  ? 'bg-rose-50/90 border-rose-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full border mt-0.5 shrink-0 flex items-center justify-center ${
                  loaiDeNghi === 'Hủy người dùng'
                    ? 'bg-rose-600 border-rose-600 text-white'
                    : 'border-slate-300 bg-white'
                }`}
              >
                {loaiDeNghi === 'Hủy người dùng' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
              <div>
                <div className="text-xs font-black text-slate-900 flex items-center gap-2">
                  <span>HỦY NGƯỜI DÙNG</span>
                  <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-1.5 py-0.2 rounded">
                    Thu hồi quyền
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                  Thu hồi quyền truy cập, vô hiệu hóa hoặc hủy tài khoản người dùng khi cán bộ chuyển đổi vị trí, luân chuyển công tác hoặc nghỉ việc.
                </div>
              </div>
            </div>
          </div>

          {/* Next & Back Buttons for Step 3 */}
          <div className="pt-3 flex gap-2.5">
            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              className="w-2/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs border-2 border-slate-300 hover:border-slate-400 shadow-xs transition active:scale-95 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-slate-700 stroke-[2.5]" />
              <span>← Về Bước 2</span>
            </button>
            <button
              type="button"
              onClick={() => setCurrentStep(4)}
              className="w-3/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
            >
              <span>Tiếp tục (Bước 4: Căn cứ)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* BƯỚC 4: NHẬP CĂN CỨ VÀ NỘI DUNG ĐỀ NGHỊ */}
      {/* ============================================================ */}
      {currentStep === 4 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-4">
          <div>
            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-[#004F9E] text-xs font-black flex items-center justify-center">
                4
              </span>
              <span>Nhập thông tin & căn cứ pháp lý</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Điền số văn bản phân công và nội dung chi tiết theo mẫu quy định VietinBank.
            </p>
          </div>

          {/* Field: Số QĐ tuyển dụng / phân công */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Số Quyết định tuyển dụng / Phân công nhiệm vụ: <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={soQDTuyenDung}
              onChange={(e) => setSoQDTuyenDung(e.target.value)}
              placeholder="VD: QĐ 128/QĐ-NHCT-NB ngày 15/01/2026"
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl p-3 font-medium focus:ring-2 focus:ring-[#004F9E] focus:bg-white"
            />
            {/* Quick Suggestions */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              <span className="text-[10px] text-slate-400 self-center">Gợi ý mẫu:</span>
              <button
                type="button"
                onClick={() => setSoQDTuyenDung('QĐ 128/QĐ-NHCT-NB')}
                className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-mono px-2 py-0.5 rounded-lg transition"
              >
                QĐ 128/QĐ-NHCT-NB
              </button>
              <button
                type="button"
                onClick={() => setSoQDTuyenDung('TB 042/TB-P.KHDN')}
                className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-mono px-2 py-0.5 rounded-lg transition"
              >
                TB 042/TB-P.KHDN
              </button>
              <button
                type="button"
                onClick={() => setSoQDTuyenDung('QĐ phân công NV năm 2026')}
                className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-0.5 rounded-lg transition"
              >
                Phân công NV năm 2026
              </button>
            </div>
          </div>

          {/* Field: Nội dung đề nghị */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Nội dung đề nghị chi tiết: <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              value={noiDung}
              onChange={(e) => setNoiDung(e.target.value)}
              placeholder="Mô tả phạm vi quyền, phân hệ hoặc lý do cụ thể..."
              className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl p-3 font-medium focus:ring-2 focus:ring-[#004F9E] focus:bg-white"
            />
            {/* Quick template phrases */}
            <div className="space-y-1 mt-1.5">
              <span className="text-[10px] text-slate-400">Mẫu gợi ý nhanh:</span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => fillTemplate('Đề nghị cấp quyền Maker xử lý hồ sơ tín dụng khách hàng doanh nghiệp theo phân công')}
                  className="text-[10px] bg-blue-50 hover:bg-blue-100 text-[#004F9E] px-2 py-1 rounded-lg text-left transition"
                >
                  + Quyền Maker tín dụng
                </button>
                <button
                  type="button"
                  onClick={() => fillTemplate('Đề nghị phân quyền Giao dịch viên tiền gửi và thanh toán chuyển tiền')}
                  className="text-[10px] bg-blue-50 hover:bg-blue-100 text-[#004F9E] px-2 py-1 rounded-lg text-left transition"
                >
                  + Giao dịch viên tiền gửi
                </button>
                <button
                  type="button"
                  onClick={() => fillTemplate('Đề nghị thu hồi toàn bộ quyền truy cập do cán bộ luân chuyển công tác')}
                  className="text-[10px] bg-rose-50 hover:bg-rose-100 text-rose-700 px-2 py-1 rounded-lg text-left transition"
                >
                  + Thu hồi do luân chuyển
                </button>
              </div>
            </div>
          </div>

          {/* Next & Back Buttons for Step 4 */}
          <div className="pt-3 flex gap-2.5">
            <button
              type="button"
              onClick={() => setCurrentStep(3)}
              className="w-2/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs border-2 border-slate-300 hover:border-slate-400 shadow-xs transition active:scale-95 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-slate-700 stroke-[2.5]" />
              <span>← Về Bước 3</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (validateStep4()) {
                  setCurrentStep(5);
                }
              }}
              className="w-3/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
            >
              <span>Tiếp tục (Bước 5: Xác nhận)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* BƯỚC 5: KIỂM TRA THÔNG TIN & XÁC NHẬN GỬI */}
      {/* ============================================================ */}
      {currentStep === 5 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-4">
          <div>
            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-[#004F9E] text-xs font-black flex items-center justify-center">
                5
              </span>
              <span>Kiểm tra & Xác nhận thông tin</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Vui lòng kiểm tra lại toàn bộ thông tin đề nghị trước khi chính thức gửi phê duyệt.
            </p>
          </div>

          {/* Summary Card */}
          <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 space-y-3 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium">Đơn vị:</span>
              <span className="font-bold text-slate-900 text-right">
                {currentUser.tenPhongBan} ({currentUser.maPhongBan})
              </span>
            </div>

            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium">Người được cấp quyền:</span>
              <span className="font-bold text-[#004F9E] text-right">
                {targetStaff.hoTen} ({targetStaff.userAD})
              </span>
            </div>

            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium">Chương trình ứng dụng:</span>
              <span className="font-bold text-slate-900 text-right">
                {selectedProgram?.tenChuongTrinh} ({selectedProgramCode})
              </span>
            </div>

            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium">Loại đề nghị:</span>
              <span
                className={`font-black px-2 py-0.5 rounded text-[11px] ${
                  loaiDeNghi === 'Cấp mới'
                    ? 'bg-blue-100 text-blue-800'
                    : loaiDeNghi === 'Thay đổi'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {loaiDeNghi}
              </span>
            </div>

            <div className="flex justify-between items-start pb-2 border-b border-slate-200">
              <span className="text-slate-500 font-medium shrink-0">Căn cứ pháp lý:</span>
              <span className="font-semibold text-slate-800 text-right ml-2 font-mono">
                {soQDTuyenDung}
              </span>
            </div>

            <div>
              <span className="text-slate-500 font-medium block mb-1">Nội dung đề nghị:</span>
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-slate-800 font-medium leading-relaxed">
                {noiDung}
              </div>
            </div>

            <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>
                Sau khi gửi, đề nghị sẽ tự động chuyển đến Lãnh đạo phòng xem xét phê duyệt.
              </span>
            </div>
          </div>

          {/* Confirm & Submit Action */}
          <div className="pt-2 flex gap-2.5">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setCurrentStep(4)}
              className="w-2/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs border-2 border-slate-300 hover:border-slate-400 shadow-xs transition active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <ArrowLeft className="w-4 h-4 text-slate-700 stroke-[2.5]" />
              <span>← Về Bước 4 sửa</span>
            </button>
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleConfirmSubmit}
              className="w-3/5 min-h-[48px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#004F9E] to-[#003B77] hover:from-[#003B77] hover:to-[#002855] text-white font-black text-xs shadow-md transition active:scale-95 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>Đang gửi đề nghị...</span>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Xác nhận & Gửi đề nghị</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* BƯỚC 6: GỬI THÀNH CÔNG (KẾT QUẢ RÕ RÀNG) */}
      {/* ============================================================ */}
      {currentStep === 6 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 text-center space-y-4 animate-fade-in">
          {/* Success Icon */}
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div>
            <h3 className="text-lg font-black text-slate-900 tracking-tight">
              Gửi đề nghị cấp quyền thành công!
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Đề nghị đã được ghi nhận trên hệ thống và chuyển đến Lãnh đạo phòng xem xét.
            </p>
          </div>

          {/* Request Code & Status Highlight */}
          <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-200 text-left space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-600 font-medium">Mã đề nghị:</span>
              <span className="font-mono text-sm font-black text-[#004F9E] bg-white px-2.5 py-0.5 rounded-lg border border-blue-200 shadow-xs">
                {createdRequest?.maDeNghi || 'CN-2026-XXXX'}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600 font-medium">Trạng thái hiện tại:</span>
              <span className="font-bold text-[11px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-200">
                Chờ lãnh đạo phòng phê duyệt
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600 font-medium">Chương trình:</span>
              <span className="font-bold text-slate-900">
                {selectedProgram?.tenChuongTrinh}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-600 font-medium">Người được cấp:</span>
              <span className="font-bold text-slate-900">{targetStaff.hoTen}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 space-y-2.5">
            <button
              type="button"
              onClick={onCancel}
              className="w-full min-h-[48px] flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-black text-xs border-2 border-slate-300 hover:border-[#004F9E] shadow-xs transition active:scale-95 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-slate-700 stroke-[2.5]" />
              <span>Trở lại Trang chủ</span>
            </button>

            {onOpenPrint && createdRequest && (
              <button
                type="button"
                onClick={() => onOpenPrint(createdRequest)}
                className="w-full min-h-[46px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs shadow-xs transition active:scale-98 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>In phiếu đề nghị A4 ngay</span>
              </button>
            )}

            <button
              type="button"
              onClick={onViewRequests}
              className="w-full min-h-[46px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#004F9E] hover:bg-[#003B77] text-white font-bold text-xs shadow-xs transition active:scale-98 cursor-pointer"
            >
              <List className="w-4 h-4" />
              <span>Xem danh sách & Tiến độ phê duyệt</span>
            </button>

            <button
              type="button"
              onClick={() => {
                // Reset form to create another
                setCurrentStep(1);
                setNoiDung('');
                setCreatedRequest(null);
                setBeneficiaryMode('SELF');
                setSelectedStaffUserAD(currentUser.userAD);
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs border border-slate-200 transition cursor-pointer"
            >
              + Tạo thêm đề nghị khác
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
