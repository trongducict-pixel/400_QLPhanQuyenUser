import React from 'react';
import { User } from '../types';
import { NavTab } from './Sidebar';
import {
  Home,
  FilePlus,
  FileCheck,
  Settings,
  User as UserIcon,
  Layers
} from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  currentUser: User | null;
  pendingApprovalCount?: number;
  pendingProcessCount?: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  pendingApprovalCount = 0,
  pendingProcessCount = 0
}) => {
  if (!currentUser) return null;

  const isAdmin = currentUser.chucVu === 'Admin';
  const isLeader = currentUser.chucVu === 'Lãnh đạo phòng';
  const isIT = currentUser.chucVu === 'Cán bộ điện toán';

  const approvalBadge = isLeader ? pendingApprovalCount : isIT ? pendingProcessCount : 0;

  return (
    <nav
      id="mobile-bottom-navbar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg px-2 py-1.5 safe-area-bottom"
    >
      <div className="max-w-lg mx-auto flex items-center justify-around">
        {/* Trang chủ */}
        <button
          id="nav-home-btn"
          onClick={() => onSelectTab('dashboard')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
            activeTab === 'dashboard'
              ? 'text-[#004F9E] font-bold'
              : 'text-slate-500 hover:text-slate-800 font-medium'
          }`}
        >
          <div className="relative">
            <Home
              className={`w-5 h-5 ${
                activeTab === 'dashboard' ? 'stroke-[2.5px] scale-110 text-[#004F9E]' : ''
              }`}
            />
          </div>
          <span className="text-[10px] mt-0.5">Trang chủ</span>
        </button>

        {/* Đề nghị */}
        <button
          id="nav-requests-btn"
          onClick={() => onSelectTab('requests')}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
            activeTab === 'requests' || activeTab === 'create-request'
              ? 'text-[#004F9E] font-bold'
              : 'text-slate-500 hover:text-slate-800 font-medium'
          }`}
        >
          <div className="relative">
            <FilePlus
              className={`w-5 h-5 ${
                activeTab === 'requests' || activeTab === 'create-request'
                  ? 'stroke-[2.5px] scale-110 text-[#004F9E]'
                  : ''
              }`}
            />
          </div>
          <span className="text-[10px] mt-0.5">Đề nghị</span>
        </button>

        {/* Phê duyệt */}
        <button
          id="nav-approvals-btn"
          onClick={() => onSelectTab('approvals' as any)}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all relative cursor-pointer ${
            (activeTab as string) === 'approvals'
              ? 'text-[#004F9E] font-bold'
              : 'text-slate-500 hover:text-slate-800 font-medium'
          }`}
        >
          <div className="relative">
            <FileCheck
              className={`w-5 h-5 ${
                (activeTab as string) === 'approvals'
                  ? 'stroke-[2.5px] scale-110 text-[#004F9E]'
                  : ''
              }`}
            />
            {approvalBadge > 0 && (
              <span className="absolute -top-1.5 -right-2 min-w-4 h-4 bg-rose-600 text-white text-[9px] font-black rounded-full flex items-center justify-center px-1 animate-pulse">
                {approvalBadge}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5">
            {isIT ? 'Xử lý' : 'Phê duyệt'}
          </span>
        </button>

        {/* Quản trị - CHỈ HIỂN THỊ NẾU LÀ ADMIN */}
        {isAdmin && (
          <button
            id="nav-admin-btn"
            onClick={() => onSelectTab('admin-hub' as any)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
              (activeTab as string) === 'admin-hub' ||
              ['users', 'staff', 'departments', 'programs', 'audit', 'gas-guide'].includes(
                activeTab
              )
                ? 'text-purple-700 font-bold'
                : 'text-slate-500 hover:text-slate-800 font-medium'
            }`}
          >
            <div className="relative">
              <Settings
                className={`w-5 h-5 ${
                  (activeTab as string) === 'admin-hub' ||
                  ['users', 'staff', 'departments', 'programs', 'audit', 'gas-guide'].includes(
                    activeTab
                  )
                    ? 'stroke-[2.5px] scale-110 text-purple-700'
                    : ''
                }`}
              />
            </div>
            <span className="text-[10px] mt-0.5">Quản trị</span>
          </button>
        )}

        {/* Tài khoản cá nhân */}
        <button
          id="nav-profile-btn"
          onClick={() => onSelectTab('profile' as any)}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
            (activeTab as string) === 'profile'
              ? 'text-[#004F9E] font-bold'
              : 'text-slate-500 hover:text-slate-800 font-medium'
          }`}
        >
          <div className="relative">
            <UserIcon
              className={`w-5 h-5 ${
                (activeTab as string) === 'profile'
                  ? 'stroke-[2.5px] scale-110 text-[#004F9E]'
                  : ''
              }`}
            />
          </div>
          <span className="text-[10px] mt-0.5">Tài khoản</span>
        </button>
      </div>
    </nav>
  );
};
