import {
  User,
  CanBo,
  PhongBan,
  ChuongTrinh,
  RequestRecord,
  ApprovalHistory,
  ProcessingHistory,
  AuditLog,
  EmailNotification,
  SystemConfig,
  AppPermissionRule,
  AppPermissionGroup,
  AppRegulation,
  AppNote,
  UserRole
} from '../types';

export const initialConfig: SystemConfig = {
  itEmail: 'ducnt4@vietinbank.vn',
  tenChiNhanh: 'VIETINBANK – CHI NHÁNH NINH BÌNH',
  maChiNhanh: 'CN Ninh Bình (042)',
  diaChi: 'Số 10 Tràng An, Phường Tân Thành, TP. Ninh Bình, Tỉnh Ninh Bình',
  appVersion: 'V1.2',
  gasApiUrl: 'https://script.google.com/macros/s/AKfycbwv5QSwAwKQKAsqwDKlY9B0YQ_z574Zo6iJTaN6ksBbb4D3l3f8J6V4Z3JQc_7qdlm5/exec'
};

export const initialDepartments: PhongBan[] = [
  {
    id: 'dept-bgd',
    maPhongBan: 'BGD',
    tenPhongBan: 'Ban giám đốc',
    trangThai: 'Hoạt động',
    moTa: 'Ban Giám đốc Chi nhánh Ninh Bình'
  },
  {
    id: 'dept-khdn',
    maPhongBan: 'P_KHDN',
    tenPhongBan: 'Phòng KHDN',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Khách hàng Doanh nghiệp'
  },
  {
    id: 'dept-bl',
    maPhongBan: 'P_BL',
    tenPhongBan: 'Phòng Bán lẻ',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Bán lẻ & Khách hàng Cá nhân'
  },
  {
    id: 'dept-dvkh',
    maPhongBan: 'P_DVKH',
    tenPhongBan: 'Phòng Dịch vụ khách hàng',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Kế toán & Dịch vụ Khách hàng'
  },
  {
    id: 'dept-httd',
    maPhongBan: 'P_HTTD',
    tenPhongBan: 'Phòng Hỗ trợ tín dụng',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Hỗ trợ tín dụng & Quản lý nợ'
  },
  {
    id: 'dept-tcth',
    maPhongBan: 'P_TCTH',
    tenPhongBan: 'Phòng Tổ chức Tổng hợp',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Tổ chức Cán bộ & Hành chính Tổng hợp'
  },
  {
    id: 'dept-it',
    maPhongBan: 'P_IT',
    tenPhongBan: 'Điện toán & Công nghệ thông tin',
    trangThai: 'Hoạt động',
    moTa: 'Vận hành hệ thống mạng, hạ tầng, phân quyền ứng dụng'
  },
  {
    id: 'dept-pgd-gv',
    maPhongBan: 'PGD_GV',
    tenPhongBan: 'PGD Gia Viễn',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Giao dịch Gia Viễn'
  },
  {
    id: 'dept-pgd-ks',
    maPhongBan: 'PGD_KS',
    tenPhongBan: 'PGD Kim Sơn',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Giao dịch Kim Sơn'
  },
  {
    id: 'dept-pgd-nt',
    maPhongBan: 'PGD_NT',
    tenPhongBan: 'PGD Ninh Thành',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Giao dịch Ninh Thành'
  },
  {
    id: 'dept-pgd-yk',
    maPhongBan: 'PGD_YK',
    tenPhongBan: 'PGD Yên Khánh',
    trangThai: 'Hoạt động',
    moTa: 'Phòng Giao dịch Yên Khánh'
  }
];

export const initialPrograms: ChuongTrinh[] = [
  {
    id: 'prog-tptl-tpss',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    moTa: 'TouchPoint Sale and Service: Chương trình ứng dụng quản lý và xử lý giao dịch phi tiền mặt, quản lý hồ sơ thông tin khách hàng, chữ ký mẫu dấu, tiền gửi, tiền vay, chuyển tiền trên hệ thống SUNSHINE. Touch Point Teller: Chương trình ứng dụng quản lý và xử lý giao dịch tài chính với khách hàng, quản lý tiền mặt, quản lý kho ấn chỉ quan trọng, quản trị thông tin người dùng, cung cấp một số thông tin chi tiết về tài khoản và khách hàng trên hệ thống SUNSHINE, xử lý các giao dịch khác với khách hàng như in sổ/thẻ, sec, hóa đơn…',
    moTaNghiepVu: 'TouchPoint Sale and Service: Chương trình ứng dụng quản lý và xử lý giao dịch phi tiền mặt, quản lý hồ sơ thông tin khách hàng, chữ ký mẫu dấu, tiền gửi, tiền vay, chuyển tiền trên hệ thống SUNSHINE.\nTouch Point Teller: Chương trình ứng dụng quản lý và xử lý giao dịch tài chính với khách hàng, quản lý tiền mặt, quản lý kho ấn chỉ quan trọng, quản trị thông tin người dùng, cung cấp một số thông tin chi tiết về tài khoản và khách hàng trên hệ thống SUNSHINE, xử lý các giao dịch khác với khách hàng như in sổ/thẻ, sec, hóa đơn…',
    phamVi: 'Toàn chi nhánh (Phòng KHDN, Phòng Bán lẻ, Phòng Kế toán & DVKH)',
    nhomQuyenMacDinh: 'TPSS_GDV, TPSS_KSV, TPTL_MAKER, TPTL_CHECKER, TRA_CUU',
    ghiChuChung: 'Hệ thống ngân hàng lõi Core SUNSHINE xử lý giao dịch tài chính và phi tiền mặt',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-ib',
    maChuongTrinh: 'IB',
    tenChuongTrinh: 'IB (Internet Banking)',
    moTa: 'Bộ các chương trình ứng dụng kênh, hỗ trợ việc quản trị, quản lý và xử lý các giao dịch ngân hàng điện tử, bao gồm các ứng dụng: Registeradmin, Bankadmin, BankFast Retail, BankFast Retail Mobile application, VietinBank eFAST, VietinBank eFAST Mobile application.',
    moTaNghiepVu: 'Internet Banking: Bộ các chương trình ứng dụng kênh, hỗ trợ việc quản trị, quản lý và xử lý các giao dịch ngân hàng điện tử, bao gồm các ứng dụng: Registeradmin, Bankadmin, BankFast Retail, BankFast Retail Mobile application, VietinBank eFAST, VietinBank eFAST Mobile application.',
    phamVi: 'Phòng KHDN, Phòng Bán lẻ, Phòng Kế toán & DVKH, Phòng Tổng hợp',
    nhomQuyenMacDinh: 'Registeradmin, Bankadmin, BankFast_Retail, eFAST_Admin, eFAST_Support',
    ghiChuChung: 'Quản trị và hỗ trợ dịch vụ ngân hàng điện tử KHDN và KHCN',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-tf',
    maChuongTrinh: 'TF',
    tenChuongTrinh: 'TF (Trade Finance)',
    moTa: 'Bộ các chương trình ứng dụng kênh, hỗ trợ cho ngân hàng và khách hàng trong việc quản trị, quản lý và xử lý các giao dịch tài trợ thương mại, bao gồm ứng dụng dành cho người dùng của Ngân hàng (EE) và ứng dụng dành cho người dùng là khách hàng (CE).',
    moTaNghiepVu: 'Trade Finance: Bộ các chương trình ứng dụng kênh, hỗ trợ cho ngân hàng và khách hàng trong việc quản trị, quản lý và xử lý các giao dịch tài trợ thương mại, bao gồm ứng dụng dành cho người dùng của Ngân hàng (EE) và ứng dụng dành cho người dùng là khách hàng (CE).',
    phamVi: 'Phòng KHDN, Phòng Kế toán & DVKH',
    nhomQuyenMacDinh: 'TF_EE_MAKER, TF_EE_CHECKER, TF_CE_SUPPORT',
    ghiChuChung: 'Nghiệp vụ tài trợ thương mại, phát hành L/C, bảo lãnh ngân hàng',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-ogl',
    maChuongTrinh: 'OGL',
    tenChuongTrinh: 'OGL (Oracle General Ledger)',
    moTa: 'Là chương trình phần mềm ứng dụng để quản lý và tác nghiệp nghiệp vụ quản lý kế toán tài chính của NHCT.',
    moTaNghiepVu: 'Oracle General Ledger: Là chương trình phần mềm ứng dụng để quản lý và tác nghiệp nghiệp vụ quản lý kế toán tài chính của NHCT.',
    phamVi: 'Phòng Kế toán & DVKH, Phòng Tổ chức Tổng hợp',
    nhomQuyenMacDinh: 'OGL_ENTRY, OGL_REVIEWER, OGL_REPORT, OGL_ADMIN',
    ghiChuChung: 'Phần mềm quản lý và tác nghiệp kế toán tài chính tổng hợp NHCT',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-vfx',
    maChuongTrinh: 'VFX',
    tenChuongTrinh: 'VFX (Vision Foreign Exchange)',
    moTa: 'Là hệ thống mua bán ngoại tệ, cho phép thực hiện nhập, phê duyệt và quản lý các giao dịch Mua bán ngoại tệ (giao ngay, kỳ hạn và hoán đổi) giữa CN với khách hàng và các giao dịch nội bộ.',
    moTaNghiepVu: 'Vision Foreign Exchange: Là hệ thống mua bán ngoại tệ, cho phép thực hiện nhập, phê duyệt và quản lý các giao dịch Mua bán ngoại tệ (giao ngay, kỳ hạn và hoán đổi) giữa CN với khách hàng và các giao dịch nội bộ.',
    phamVi: 'Phòng KHDN, Phòng Bán lẻ, Phòng Kế toán & DVKH',
    nhomQuyenMacDinh: 'VFX_MAKER, VFX_CHECKER, VFX_VIEWER',
    ghiChuChung: 'Hệ thống mua bán ngoại tệ giao ngay, kỳ hạn và hoán đổi',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-crlos',
    maChuongTrinh: 'CRLOS',
    tenChuongTrinh: 'CRLOS (Corporate Retail Loan Origination System)',
    moTa: 'Là cấu phần của hệ thống LOS hỗ trợ khai báo thông tin quản lý việc khởi tạo và phê duyệt tín dụng.',
    moTaNghiepVu: 'CRLOS (Corporate Retail Loan Origination System): Là cấu phần của hệ thống LOS hỗ trợ khai báo thông tin quản lý việc khởi tạo và phê duyệt tín dụng.',
    phamVi: 'Phòng KHDN, Phòng Bán lẻ, Phòng Quản lý nợ & KSNB, Ban Giám đốc',
    nhomQuyenMacDinh: 'CRLOS_MAKER, CRLOS_CHECKER, CRLOS_APPROVER, CRLOS_VIEWER',
    ghiChuChung: 'Cấu phần khởi tạo và luân chuyển phê duyệt tờ trình tín dụng LOS',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-clims',
    maChuongTrinh: 'CLIMS',
    tenChuongTrinh: 'CLIMS (Collateral & Limits Management System)',
    moTa: 'Là cấu phần của hệ thống LOS hỗ trợ kiểm soát thông tin giới hạn tín dụng/giới hạn giao dịch/ Khoản tín dụng/Tài sản bảo đảm trước khi chuyển sang hệ thống Core SUNSHINE và quản lý hồ sơ tài sản bảo đảm.',
    moTaNghiepVu: 'CLIMS (Collateral & Limits Management System): Là cấu phần của hệ thống LOS hỗ trợ kiểm soát thông tin giới hạn tín dụng/giới hạn giao dịch/ Khoản tín dụng/Tài sản bảo đảm trước khi chuyển sang hệ thống Core SUNSHINE và quản lý hồ sơ tài sản bảo đảm.',
    phamVi: 'Phòng KHDN, Phòng Bán lẻ, Phòng Quản lý nợ & KSNB, Ban Giám đốc',
    nhomQuyenMacDinh: 'CLIMS_INPUT, CLIMS_CHECK, CLIMS_TSBD_ADMIN, CLIMS_VIEWER',
    ghiChuChung: 'Kiểm soát hạn mức tín dụng và quản lý hồ sơ tài sản bảo đảm',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-aml',
    maChuongTrinh: 'AML',
    tenChuongTrinh: 'AML (Hệ thống Phòng chống rửa tiền, tài trợ khủng bố (PCRT&TTKB))',
    moTa: 'Rà soát đối tượng Khách hàng đen/cấm vận/cảnh báo, chấm điểm rủi ro khách hàng, rà soát các giao dịch có yếu tố cấm vận, xây dựng các kịch bản giám sát các khách hàng, giao dịch đáng ngờ, đảm bảo hoạt động của NHCT tuân thủ các quy định của pháp luật liên quan tới PCRT&TTKB, đồng thời đảm bảo kiểm soát rủi ro.',
    moTaNghiepVu: 'Hệ thống Phòng chống rửa tiền, tài trợ khủng bố (PCRT&TTKB): rà soát đối tượng Khách hàng đen/cấm vận/cảnh báo, chấm điểm rủi ro khách hàng, rà soát các giao dịch có yếu tố cấm vận, xây dựng các kịch bản giám sát các khách hàng, giao dịch đáng ngờ, đảm bảo hoạt động của NHCT tuân thủ các quy định của pháp luật liên quan tới PCRT&TTKB, đồng thời đảm bảo kiểm soát rủi ro',
    phamVi: 'Toàn chi nhánh (Phòng Quản lý nợ & KSNB, Phòng Kế toán & DVKH, Phòng KHDN, Phòng Bán lẻ)',
    nhomQuyenMacDinh: 'AML_OFFICER, AML_SUPERVISOR, AML_COMPLIANCE, AML_VIEWER',
    ghiChuChung: 'Tuân thủ quy định PCRT&TTKB, rà soát danh sách cấm vận và giao dịch đáng ngờ',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-so-dien-tu',
    maChuongTrinh: 'SO_DIEN_TU',
    tenChuongTrinh: 'Sổ điện tử',
    moTa: 'Hệ thống sổ điện tử tại bộ phận quỹ',
    moTaNghiepVu: 'Hệ thống sổ điện tử tại bộ phận quỹ',
    phamVi: 'Phòng Kế toán & Dịch vụ Khách hàng (Bộ phận Quỹ)',
    nhomQuyenMacDinh: 'THU_QUY, KIEM_SOAT_QUY, GIAM_SAT_QUY, TRA_CUU_QUY',
    ghiChuChung: 'Sổ quỹ điện tử theo dõi thu chi tiền mặt và đối soát tồn quỹ kho tiền',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-sdb',
    maChuongTrinh: 'SDB',
    tenChuongTrinh: 'SDB (Smart digital branch)',
    moTa: 'Hệ thống nhận diện, phân luồng KH, quản lý danh sách KH chờ giao dịch, gọi KH vào quầy; thu thập, xử lý thông tin sinh trắc học; tự thực hiện giao dịch, nhập trước thông tin. Bao gồm phần cứng Kiosk, LCD, loa, tablet và giao diện Kiosk, LCD, tablet, web Lãnh đạo/cán bộ.',
    moTaNghiepVu: '- Hệ thống SDB là hệ thống nhận diện, phân luồng KH, quản lý danh sách KH chờ giao dịch, gọi KH vào giao dịch tại quầy; thu thập, xử lý thông tin sinh trắc học của KH; cho phép KH thao tác để tự thực hiện giao dịch, nhập trước thông tin giao dịch đối với một số loại giao dịch do NHCT cung cấp\n- Hệ thống SDB bao gồm các thiết bị phần cứng: Kiosk, màn hình LCD, hệ thống loa, máy tính bảng; và các giao diện phần mềm: giao diện Kiosk; giao diện LCD, máy tính bảng; giao diện web cho Lãnh đạo/cán bộ ngân hàng.',
    phamVi: 'Phòng Kế toán & DVKH, Phòng Bán lẻ, Phòng Tổ chức Tổng hợp, Ban Giám đốc',
    nhomQuyenMacDinh: 'SDB_GDV, SDB_DIEU_PHOI, SDB_ADMIN_CN, SDB_GIAM_SAT',
    ghiChuChung: 'Hệ thống Chi nhánh số thông minh Smart Digital Branch',
    trangThai: 'Hoạt động'
  },
  {
    id: 'prog-atm-ton-quy',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    tenChuongTrinh: 'Chương trình giám sát tồn quỹ ATM',
    moTa: 'Chương trình giám sát tồn quỹ ATM (chỉ áp dụng có TT QLTM)',
    moTaNghiepVu: 'Chương trình giám sát tồn quỹ ATM (chỉ áp dụng có TT QLTM)',
    phamVi: 'Phòng Kế toán & DVKH (Bộ phận Quỹ & Tiếp quỹ ATM), TT QLTM',
    nhomQuyenMacDinh: 'TIEP_QUY_ATM, GIAM_SAT_ATM, QUAN_TRI_ATM',
    ghiChuChung: 'Giám sát tồn quỹ máy ATM/CDM tại chi nhánh và phòng giao dịch',
    trangThai: 'Hoạt động'
  }
];

interface RawStaffItem {
  stt: number;
  hoTen: string;
  maCanBo: string;
  userAD: string;
  tenPhongBan: string;
  viTriCongViec: string;
  soDienThoai: string;
  email: string;
}

const rawStaffList: RawStaffItem[] = [
  { stt: 1, hoTen: 'Đinh Xuân Thắng', maCanBo: '00005568', userAD: 'thangdx', tenPhongBan: 'Ban giám đốc', viTriCongViec: 'Giám đốc CN', soDienThoai: '0979792099', email: 'thangdx@vietinbank.vn' },
  { stt: 2, hoTen: 'Bùi Thị Thu Dung', maCanBo: '00006961', userAD: 'dung.bt', tenPhongBan: 'Ban giám đốc', viTriCongViec: 'Phó Giám đốc CN (KHDN)', soDienThoai: '0945040477', email: 'dung.bt@vietinbank.vn' },
  { stt: 3, hoTen: 'Đoàn Mạnh Dương', maCanBo: '00006962', userAD: 'duongdm', tenPhongBan: 'Ban giám đốc', viTriCongViec: 'Phó Giám đốc Đầu mối Bán lẻ', soDienThoai: '0915518668', email: 'duongdm@vietinbank.vn' },
  { stt: 4, hoTen: 'Lý Hoàng Hà', maCanBo: '00006983', userAD: 'lyhoang.ha', tenPhongBan: 'Ban giám đốc', viTriCongViec: 'Phó Giám đốc CN (KHDN)', soDienThoai: '0912773043', email: 'lyhoang.ha@vietinbank.vn' },
  { stt: 5, hoTen: 'Nguyễn Thị Thu Hường', maCanBo: '00006949', userAD: 'huongntt400', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Hậu kiểm', soDienThoai: '0916502028', email: 'huongntt400@vietinbank.vn' },
  { stt: 6, hoTen: 'Đinh Thanh Hà', maCanBo: '00006965', userAD: 'ha.dinhthanh', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Trưởng phòng TCTH', soDienThoai: '0903261126', email: 'ha.dinhthanh@vietinbank.vn' },
  { stt: 7, hoTen: 'Nguyễn Hữu Giáp', maCanBo: '00006966', userAD: 'giapnh', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Nhân viên thu nợ', soDienThoai: '0906685123', email: 'giapnh@vietinbank.vn' },
  { stt: 8, hoTen: 'Tạ Quang Thức', maCanBo: '00006970', userAD: 'thuctq', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Phó phòng TCTH', soDienThoai: '0977879119', email: 'thuctq@vietinbank.vn' },
  { stt: 9, hoTen: 'Nguyễn Hoàng Quỳnh', maCanBo: '00006975', userAD: 'quynhnh', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Phó phòng TCTH', soDienThoai: '0912852378', email: 'quynhnh@vietinbank.vn' },
  { stt: 10, hoTen: 'Nguyễn Thị Thu Trà', maCanBo: '00006989', userAD: 'tra.ntt', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Nhân viên nhân sự tiền lương', soDienThoai: '0917352681', email: 'tra.ntt@vietinbank.vn' },
  { stt: 11, hoTen: 'Phạm Văn Minh', maCanBo: '00021947', userAD: 'pvminh', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Lái xe', soDienThoai: '0945959262', email: 'pvminh@vietinbank.vn' },
  { stt: 12, hoTen: 'Vũ Thị Lan Phương', maCanBo: '00021948', userAD: 'phuongvtl', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Nhân viên văn thư', soDienThoai: '0988266628', email: 'phuongvtl@vietinbank.vn' },
  { stt: 13, hoTen: 'Trịnh Tuấn Dũng', maCanBo: '00028447', userAD: 'dungtt6', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Lái xe', soDienThoai: '0975813868', email: 'dungtt6@vietinbank.vn' },
  { stt: 14, hoTen: 'Đỗ Thị Thêm', maCanBo: '00043022', userAD: 'themdt', tenPhongBan: 'Phòng Tổ chức Tổng hợp', viTriCongViec: 'Hậu kiểm', soDienThoai: '0966017286', email: 'themdt@vietinbank.vn' },
  { stt: 15, hoTen: 'Đinh Quang Dân', maCanBo: '00006935', userAD: 'dandq', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Phó phòng Dịch vụ KH (TTKQ)', soDienThoai: '0947676868', email: 'dandq@vietinbank.vn' },
  { stt: 16, hoTen: 'Phạm Thị Hà', maCanBo: '00006948', userAD: 'pthiha', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Trưởng phòng Dịch vụ KH', soDienThoai: '0915209091', email: 'pthiha@vietinbank.vn' },
  { stt: 17, hoTen: 'Đỗ Thị Huế', maCanBo: '00006950', userAD: 'dt.hue', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Phó phòng Dịch vụ KH (Kế toán)', soDienThoai: '0945268885', email: 'dt.hue@vietinbank.vn' },
  { stt: 18, hoTen: 'Nguyễn Minh Vũ', maCanBo: '00006959', userAD: 'vunm', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Thủ quỹ', soDienThoai: '0838608888', email: 'vunm@vietinbank.vn' },
  { stt: 19, hoTen: 'Lương Thị Kim Liên', maCanBo: '00006978', userAD: 'lien.ltk', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Thủ quỹ', soDienThoai: '0973122679', email: 'lien.ltk@vietinbank.vn' },
  { stt: 20, hoTen: 'Phạm Thị Yến Thuận', maCanBo: '00006980', userAD: 'thuanpty', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Thủ quỹ', soDienThoai: '0917900250', email: 'thuanpty@vietinbank.vn' },
  { stt: 21, hoTen: 'Nguyễn Thị Thủy', maCanBo: '00006994', userAD: 'thuynt400', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Thủ quỹ', soDienThoai: '0948422368', email: 'thuynt400@vietinbank.vn' },
  { stt: 22, hoTen: 'Tạ Hà Thu', maCanBo: '00015042', userAD: 'thuth', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0949128737', email: 'thuth@vietinbank.vn' },
  { stt: 23, hoTen: 'Vũ Thị Hải Yến', maCanBo: '00015048', userAD: 'yenvth', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0915378184', email: 'yenvth@vietinbank.vn' },
  { stt: 24, hoTen: 'Đoàn Thị Hải Phượng', maCanBo: '00015062', userAD: 'dthphuong', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0979051287', email: 'dthphuong@vietinbank.vn' },
  { stt: 25, hoTen: 'Trần Hoàng Oanh', maCanBo: '00015065', userAD: 'oanh.th', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Nhân viên kế toán tài chính', soDienThoai: '0912872173', email: 'oanh.th@vietinbank.vn' },
  { stt: 26, hoTen: 'Đinh Thị Lệ Tuyết', maCanBo: '00015068', userAD: 'tuyetdtl', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Thủ kho', soDienThoai: '0344790810', email: 'tuyetdtl@vietinbank.vn' },
  { stt: 27, hoTen: 'Trương Thanh Quý', maCanBo: '00021989', userAD: 'ttquy', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Phó phòng Dịch vụ KH (Kế toán)', soDienThoai: '0916884849', email: 'ttquy@vietinbank.vn' },
  { stt: 28, hoTen: 'Cù Thế Anh', maCanBo: '00030000', userAD: 'anhct', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Thủ quỹ', soDienThoai: '0977935552', email: 'anhct@vietinbank.vn' },
  { stt: 29, hoTen: 'Lê Thị Ngọc Anh', maCanBo: '00030628', userAD: 'anhltn1', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0948326676', email: 'anhltn1@vietinbank.vn' },
  { stt: 30, hoTen: 'Nguyễn Thị Huế', maCanBo: '00038210', userAD: 'huent14', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0966877969', email: 'huent14@vietinbank.vn' },
  { stt: 31, hoTen: 'Lê Thị Mỹ Lộc', maCanBo: '00041358', userAD: 'locltm', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0946894152', email: 'locltm@vietinbank.vn' },
  { stt: 32, hoTen: 'Thái Thị Thủy', maCanBo: '00041361', userAD: 'thuytt18', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0973710152', email: 'thuytt18@vietinbank.vn' },
  { stt: 33, hoTen: 'Phạm Hương Ly', maCanBo: '00051875', userAD: 'phly', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0367123462', email: 'phly@vietinbank.vn' },
  { stt: 34, hoTen: 'Nguyễn Trọng Đức', maCanBo: '00053550', userAD: 'ducnt4', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'Kỹ sư Điện toán', soDienThoai: '0943882109', email: 'ducnt4@vietinbank.vn' },
  { stt: 35, hoTen: 'Hoàng Linh Chi', maCanBo: '00055890', userAD: 'chihl', tenPhongBan: 'Phòng Dịch vụ khách hàng', viTriCongViec: 'GDV độc lập', soDienThoai: '0915889000', email: 'chihl@vietinbank.vn' },
  { stt: 36, hoTen: 'Nguyễn Đình Quang', maCanBo: '00006988', userAD: 'ndquang', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Phó phòng KHDN', soDienThoai: '0916889869', email: 'ndquang@vietinbank.vn' },
  { stt: 37, hoTen: 'Nguyễn Thị Thu Thủy', maCanBo: '00015046', userAD: 'thuyntt400', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0917905596', email: 'thuyntt400@vietinbank.vn' },
  { stt: 38, hoTen: 'Phan Văn Anh', maCanBo: '00030623', userAD: 'pv.anh', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Phó phòng KHDN', soDienThoai: '0963804422', email: 'pv.anh@vietinbank.vn' },
  { stt: 39, hoTen: 'Ngô Thị Thúy Vân', maCanBo: '00038213', userAD: 'vanntt9', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0387811182', email: 'vanntt9@vietinbank.vn' },
  { stt: 40, hoTen: 'Trần Thanh Phong', maCanBo: '00038221', userAD: 'phongtt1', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0985123691', email: 'phongtt1@vietinbank.vn' },
  { stt: 41, hoTen: 'Trần Thị Lĩnh', maCanBo: '00041326', userAD: 'linhtt10', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KH Doanh nghiệp Lớn', soDienThoai: '0907750968', email: 'linhtt10@vietinbank.vn' },
  { stt: 42, hoTen: 'Phạm Nguyễn Phương Anh', maCanBo: '00044380', userAD: 'anhpnp', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0388653231', email: 'anhpnp@vietinbank.vn' },
  { stt: 43, hoTen: 'Mai Hoàng Nguyên', maCanBo: '00046626', userAD: 'nguyenmh', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KH Doanh nghiệp Lớn', soDienThoai: '0917996737', email: 'nguyenmh@vietinbank.vn' },
  { stt: 44, hoTen: 'Trịnh Thị Phương Thúy', maCanBo: '00049281', userAD: 'thuy.ttp', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0833653427', email: 'thuy.ttp@vietinbank.vn' },
  { stt: 45, hoTen: 'Nguyễn Thanh Hoa', maCanBo: '00049301', userAD: 'hoant28', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0352892688', email: 'hoant28@vietinbank.vn' },
  { stt: 46, hoTen: 'Đường Hoàng Giang', maCanBo: '00050013', userAD: 'giangdh3', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0985421738', email: 'giangdh3@vietinbank.vn' },
  { stt: 47, hoTen: 'Nguyễn Thị Ngọc', maCanBo: '00055888', userAD: 'ngocnt11', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0356507212', email: 'ngocnt11@vietinbank.vn' },
  { stt: 48, hoTen: 'Phạm Thu Hà', maCanBo: '00057240', userAD: 'hapt20', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0946861912', email: 'hapt20@vietinbank.vn' },
  { stt: 49, hoTen: 'Trần Lan Anh', maCanBo: '00059438', userAD: 'tlanh', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0886320500', email: 'tlanh@vietinbank.vn' },
  { stt: 50, hoTen: 'Đỗ Trường Thọ', maCanBo: '00006945', userAD: 'thodt', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'Phó phòng Bán lẻ', soDienThoai: '0947778686', email: 'thodt@vietinbank.vn' },
  { stt: 51, hoTen: 'Hoàng Minh Sơn', maCanBo: '00015071', userAD: 'sonhm', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'Phó phòng Bán lẻ', soDienThoai: '0917683258', email: 'sonhm@vietinbank.vn' },
  { stt: 52, hoTen: 'Mai Như Thế', maCanBo: '00017400', userAD: 'themn', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0946331183', email: 'themn@vietinbank.vn' },
  { stt: 53, hoTen: 'Hoàng Thị Thơ', maCanBo: '00026273', userAD: 'thoht', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'Phó phòng Bán lẻ', soDienThoai: '0389971051', email: 'thoht@vietinbank.vn' },
  { stt: 54, hoTen: 'Dương Vân Lan Anh', maCanBo: '00030624', userAD: 'anhdvl', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0838189555', email: 'anhdvl@vietinbank.vn' },
  { stt: 55, hoTen: 'Nguyễn Quang Tùng', maCanBo: '00041584', userAD: 'tungnq1', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0962603969', email: 'tungnq1@vietinbank.vn' },
  { stt: 56, hoTen: 'Vũ Thị Lan Hương', maCanBo: '00043031', userAD: 'huongvtl2', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0916868292', email: 'huongvtl2@vietinbank.vn' },
  { stt: 57, hoTen: 'Nguyễn Thị Thu Thủy', maCanBo: '00044407', userAD: 'thuyntt39', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0979675819', email: 'thuyntt39@vietinbank.vn' },
  { stt: 58, hoTen: 'Hà Đăng Tuấn Linh', maCanBo: '00046627', userAD: 'linhhdt', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0945027445', email: 'linhhdt@vietinbank.vn' },
  { stt: 59, hoTen: 'Phạm Thị Mai', maCanBo: '00046796', userAD: 'maipt1', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0946148548', email: 'maipt1@vietinbank.vn' },
  { stt: 60, hoTen: 'Đinh Lê Hoài Thu', maCanBo: '00049307', userAD: 'thudlh', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0858891998', email: 'thudlh@vietinbank.vn' },
  { stt: 61, hoTen: 'Nguyễn Vũ Diệu Linh', maCanBo: '00055886', userAD: 'linhnvd', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0343639846', email: 'linhnvd@vietinbank.vn' },
  { stt: 62, hoTen: 'Hoàng Hương Ly', maCanBo: '00057244', userAD: 'hh.ly', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0942255119', email: 'hh.ly@vietinbank.vn' },
  { stt: 63, hoTen: 'Đỗ Văn Tấn Dũng', maCanBo: '00059439', userAD: 'dungdvt', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0886681768', email: 'dungdvt@vietinbank.vn' },
  { stt: 64, hoTen: 'Trương Mai Hoa', maCanBo: '00059748', userAD: 'hoatm', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0329896592', email: 'hoatm@vietinbank.vn' },
  { stt: 65, hoTen: 'Nguyễn Kháng Chiến', maCanBo: '00006928', userAD: 'chien.nk', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Phó phòng Hỗ trợ tín dụng', soDienThoai: '0983648217', email: 'chien.nk@vietinbank.vn' },
  { stt: 66, hoTen: 'Bùi Quý Dương', maCanBo: '00006985', userAD: 'duong.bq', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Hỗ trợ tín dụng 1', soDienThoai: '0902250555', email: 'duong.bq@vietinbank.vn' },
  { stt: 67, hoTen: 'Nguyễn Tiến Cương', maCanBo: '00006997', userAD: 'cuong.nguyentien', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Trưởng phòng Hỗ trợ tín dụng', soDienThoai: '0913012267', email: 'cuong.nguyentien@vietinbank.vn' },
  { stt: 68, hoTen: 'Vũ Hữu Chuyên', maCanBo: '00017401', userAD: 'chuyenvh', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Hỗ trợ tín dụng 1', soDienThoai: '0977939079', email: 'chuyenvh@vietinbank.vn' },
  { stt: 69, hoTen: 'Lê Thị Thanh Phương', maCanBo: '00024260', userAD: 'phuong.lethithanh', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Hỗ trợ tín dụng 1', soDienThoai: '0916569198', email: 'phuong.lethithanh@vietinbank.vn' },
  { stt: 70, hoTen: 'Dương Phú Đô', maCanBo: '00033371', userAD: 'dodp', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Hỗ trợ tín dụng 1', soDienThoai: '0989704402', email: 'dodp@vietinbank.vn' },
  { stt: 71, hoTen: 'Phạm Đoàn Hương Giang', maCanBo: '00053396', userAD: 'giangpdh', tenPhongBan: 'Phòng Hỗ trợ tín dụng', viTriCongViec: 'Hỗ trợ tín dụng 1', soDienThoai: '0857992000', email: 'giangpdh@vietinbank.vn' },
  { stt: 72, hoTen: 'Phạm Thị Thu Phi Lan', maCanBo: '00006946', userAD: 'lan.pttp', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'Trưởng PGD Hỗn hợp', soDienThoai: '0868180980', email: 'lan.pttp@vietinbank.vn' },
  { stt: 73, hoTen: 'Vũ Thị Thu Hà', maCanBo: '00006964', userAD: 'vttha', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0915316350', email: 'vttha@vietinbank.vn' },
  { stt: 74, hoTen: 'Đinh Thị Phương', maCanBo: '00026248', userAD: 'phuong.dt', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0916530111', email: 'phuong.dt@vietinbank.vn' },
  { stt: 75, hoTen: 'Bùi Thị Ánh Nguyệt', maCanBo: '00026813', userAD: 'nguyetbta', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'GDV độc lập', soDienThoai: '0917059822', email: 'nguyetbta@vietinbank.vn' },
  { stt: 76, hoTen: 'Trần Thị Thu Phương', maCanBo: '00033307', userAD: 'phuongttt6', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'GDV độc lập', soDienThoai: '0975699489', email: 'phuongttt6@vietinbank.vn' },
  { stt: 77, hoTen: 'Phan Văn Long', maCanBo: '00038216', userAD: 'pv.long', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0964326993', email: 'pv.long@vietinbank.vn' },
  { stt: 78, hoTen: 'Trần Minh Thu Huyền', maCanBo: '00041357', userAD: 'huyentmt', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0945800008', email: 'huyentmt@vietinbank.vn' },
  { stt: 79, hoTen: 'Lã Thu Huyền', maCanBo: '00044378', userAD: 'huyenlt5', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0979503598', email: 'huyenlt5@vietinbank.vn' },
  { stt: 80, hoTen: 'Văn Thị Hồng Nhung', maCanBo: '00046628', userAD: 'nhungvth3', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0912852997', email: 'nhungvth3@vietinbank.vn' },
  { stt: 81, hoTen: 'Nguyễn Thị Hồng Hạnh', maCanBo: '00055885', userAD: 'hanhnth14', tenPhongBan: 'PGD Ninh Thành', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0382267393', email: 'hanhnth14@vietinbank.vn' },
  { stt: 82, hoTen: 'Nghiêm Thị Hiền', maCanBo: '00006937', userAD: 'hien.nghiemthi', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0912829018', email: 'hien.nghiemthi@vietinbank.vn' },
  { stt: 83, hoTen: 'Đỗ Thị Mai Hương', maCanBo: '00006954', userAD: 'dtmhuong', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0912299962', email: 'dtmhuong@vietinbank.vn' },
  { stt: 84, hoTen: 'Trương Thị Hồng Hạnh', maCanBo: '00006956', userAD: 'tthhanh', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0949872383', email: 'tthhanh@vietinbank.vn' },
  { stt: 85, hoTen: 'Nguyễn Thị Ngọc Bích', maCanBo: '00021646', userAD: 'ntngocbich', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'GDV độc lập', soDienThoai: '0914357689', email: 'ntngocbich@vietinbank.vn' },
  { stt: 86, hoTen: 'Đinh Xuân Hòa', maCanBo: '00021994', userAD: 'dx.hoa', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0914260111', email: 'dx.hoa@vietinbank.vn' },
  { stt: 87, hoTen: 'Phạm Thanh Đức', maCanBo: '00029596', userAD: 'ducpt', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0917295799', email: 'ducpt@vietinbank.vn' },
  { stt: 88, hoTen: 'Đinh Mạnh Cường', maCanBo: '00030627', userAD: 'dmcuong', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0703936888', email: 'dmcuong@vietinbank.vn' },
  { stt: 89, hoTen: 'Nguyễn Thị Vân Anh', maCanBo: '00044404', userAD: 'anhntv10', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'GDV độc lập', soDienThoai: '0981795099', email: 'anhntv10@vietinbank.vn' },
  { stt: 90, hoTen: 'Nguyễn Thị Linh', maCanBo: '00049286', userAD: 'linhnt51', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0932566555', email: 'linhnt51@vietinbank.vn' },
  { stt: 91, hoTen: 'Đinh Ngọc Phong', maCanBo: '00049306', userAD: 'phongdn', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0912455777', email: 'phongdn@vietinbank.vn' },
  { stt: 92, hoTen: 'Phạm Thanh Hằng', maCanBo: '00055891', userAD: 'hangpt14', tenPhongBan: 'PGD Gia Viễn', viTriCongViec: 'GDV độc lập', soDienThoai: '0357681312', email: 'hangpt14@vietinbank.vn' },
  { stt: 93, hoTen: 'Đinh Thị Hồng Thúy', maCanBo: '00006951', userAD: 'dththuy', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'GDV độc lập', soDienThoai: '0914768222', email: 'dththuy@vietinbank.vn' },
  { stt: 94, hoTen: 'Vũ Thị Thu Trang', maCanBo: '00006967', userAD: 'vtttrang', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'Trưởng PGD Hỗn hợp', soDienThoai: '0905868298', email: 'vtttrang@vietinbank.vn' },
  { stt: 95, hoTen: 'Đinh Thành Trung', maCanBo: '00015039', userAD: 'dt.trung', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0916123289', email: 'dt.trung@vietinbank.vn' },
  { stt: 96, hoTen: 'Nguyễn Thị Hạnh', maCanBo: '00026276', userAD: 'hanhnt1', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0973497421', email: 'hanhnt1@vietinbank.vn' },
  { stt: 97, hoTen: 'Nguyễn Hoài Đức', maCanBo: '00026281', userAD: 'ducnh', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0911191162', email: 'ducnh@vietinbank.vn' },
  { stt: 98, hoTen: 'Giang Ngọc Hiệp', maCanBo: '00041354', userAD: 'hiepgn', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0982168799', email: 'hiepgn@vietinbank.vn' },
  { stt: 99, hoTen: 'Phạm Hương Giang', maCanBo: '00041356', userAD: 'giangph1', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0977071195', email: 'giangph1@vietinbank.vn' },
  { stt: 100, hoTen: 'Nguyễn Thị Thắm', maCanBo: '00042178', userAD: 'thamnt10', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0941929411', email: 'thamnt10@vietinbank.vn' },
  { stt: 101, hoTen: 'Đào Thu Hương', maCanBo: '00046638', userAD: 'huongdt21', tenPhongBan: 'PGD Yên Khánh', viTriCongViec: 'GDV độc lập', soDienThoai: '0989451194', email: 'huongdt21@vietinbank.vn' },
  { stt: 102, hoTen: 'Đào Quang Hải', maCanBo: '00006998', userAD: 'haidq', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0915331339', email: 'haidq@vietinbank.vn' },
  { stt: 103, hoTen: 'Vũ Hồng Hưng', maCanBo: '00015051', userAD: 'hungvh', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0942526289', email: 'hungvh@vietinbank.vn' },
  { stt: 104, hoTen: 'Nguyễn Thị Thương Huyền', maCanBo: '00015063', userAD: 'huyenntt400', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'Phó phòng PGD Hỗn hợp', soDienThoai: '0944125269', email: 'huyenntt400@vietinbank.vn' },
  { stt: 105, hoTen: 'Lê Đức Anh', maCanBo: '00026294', userAD: 'ld.anh', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0946622934', email: 'ld.anh@vietinbank.vn' },
  { stt: 106, hoTen: 'Đào Mạnh Cường', maCanBo: '00041353', userAD: 'cuongdm4', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0943673697', email: 'cuongdm4@vietinbank.vn' },
  { stt: 107, hoTen: 'Đinh Công Tuấn', maCanBo: '00044408', userAD: 'tuandc', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0977839355', email: 'tuandc@vietinbank.vn' },
  { stt: 108, hoTen: 'Nguyễn Thị Mai', maCanBo: '00050587', userAD: 'maint11', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'GDV độc lập', soDienThoai: '0983996615', email: 'maint11@vietinbank.vn' },
  { stt: 109, hoTen: 'Phạm Thị Mến', maCanBo: '00054558', userAD: 'men.pt', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'GDV độc lập', soDienThoai: '0964973674', email: 'men.pt@vietinbank.vn' },
  { stt: 110, hoTen: 'Nguyễn Thị Hồng Ánh', maCanBo: '00059380', userAD: 'anhnth5', tenPhongBan: 'PGD Kim Sơn', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0865103662', email: 'anhnth5@vietinbank.vn' },
  { stt: 111, hoTen: 'Vũ Huyền Linh', maCanBo: '00060488', userAD: 'linhvh3', tenPhongBan: 'Phòng Bán lẻ', viTriCongViec: 'CB QHKH bán lẻ', soDienThoai: '0865103663', email: 'linhvh3@vietinbank.vn' },
  { stt: 112, hoTen: 'Nguyễn Thị Thu Hiền', maCanBo: '00060487', userAD: 'hienntt36', tenPhongBan: 'Phòng KHDN', viTriCongViec: 'Quan hệ KHDN Vừa & Nhỏ', soDienThoai: '0865103664', email: 'hienntt36@vietinbank.vn' }
];

export const isLeadershipPosition = (viTri: string): boolean => {
  const lower = (viTri || '').toLowerCase();
  return (
    lower.includes('giám đốc') ||
    lower.includes('trưởng phòng') ||
    lower.includes('phó phòng') ||
    lower.includes('trưởng pgd') ||
    lower.includes('phó pgd')
  );
};

const mapDepartmentCode = (tenPB: string): string => {
  switch (tenPB) {
    case 'Ban giám đốc': return 'BGD';
    case 'Phòng TCTH':
    case 'Phòng Tổ chức Tổng hợp': return 'P_TCTH';
    case 'Phòng DVKH':
    case 'Phòng Dịch vụ khách hàng': return 'P_DVKH';
    case 'Phòng KHDN': return 'P_KHDN';
    case 'Phòng Bán lẻ': return 'P_BL';
    case 'Phòng HTTD':
    case 'Phòng Hỗ trợ tín dụng': return 'P_HTTD';
    case 'PGD Ninh Thành': return 'PGD_NT';
    case 'PGD Gia Viễn': return 'PGD_GV';
    case 'PGD Yên Khánh': return 'PGD_YK';
    case 'PGD Kim Sơn': return 'PGD_KS';
    case 'Điện toán & Công nghệ thông tin':
    case 'Tổ Điện toán & Công nghệ thông tin':
    case 'Điện toán': return 'P_IT';
    default: return 'P_NB';
  }
};

const mapDepartmentFullName = (tenPB: string): string => {
  switch (tenPB) {
    case 'Ban giám đốc': return 'Ban giám đốc';
    case 'Phòng TCTH':
    case 'Phòng Tổ chức Tổng hợp': return 'Phòng Tổ chức Tổng hợp';
    case 'Phòng DVKH':
    case 'Phòng Dịch vụ khách hàng': return 'Phòng Dịch vụ khách hàng';
    case 'Phòng KHDN': return 'Phòng KHDN';
    case 'Phòng Bán lẻ': return 'Phòng Bán lẻ';
    case 'Phòng HTTD':
    case 'Phòng Hỗ trợ tín dụng': return 'Phòng Hỗ trợ tín dụng';
    case 'PGD Ninh Thành': return 'PGD Ninh Thành';
    case 'PGD Gia Viễn': return 'PGD Gia Viễn';
    case 'PGD Yên Khánh': return 'PGD Yên Khánh';
    case 'PGD Kim Sơn': return 'PGD Kim Sơn';
    case 'Điện toán & Công nghệ thông tin': return 'Điện toán & Công nghệ thông tin';
    default: return tenPB;
  }
};

export const initialCanBo: CanBo[] = [
  ...rawStaffList.map((item, index) => {
    const isIT = item.userAD.toLowerCase() === 'ducnt4' || item.viTriCongViec.toLowerCase().includes('điện toán');
    const isLeader = isLeadershipPosition(item.viTriCongViec);
    const eightDigitCode = item.maCanBo.padStart(8, '0');
    
    let vaiTro: UserRole = 'Cán bộ';
    if (isIT) {
      vaiTro = 'Cán bộ điện toán';
    } else if (isLeader) {
      vaiTro = 'Lãnh đạo phòng';
    }

    return {
      id: `cb-${index + 1}`,
      stt: item.stt,
      maCanBo: eightDigitCode,
      hoTen: item.hoTen,
      maUserAD: eightDigitCode,
      userAD: item.userAD,
      matKhau: '123456',
      email: item.email,
      soDienThoai: item.soDienThoai,
      vaiTro,
      maPhongBan: mapDepartmentCode(item.tenPhongBan),
      tenPhongBan: mapDepartmentFullName(item.tenPhongBan),
      chucVu: item.viTriCongViec, // Vị trí công việc thực tế từ bảng nhân sự
      trangThai: 'Đang làm việc' as const,
      hasAccount: true,
      ngayCapTaiKhoan: '17/08/2026'
    };
  }),
  {
    id: 'cb-admin',
    stt: 0,
    maCanBo: '00000001',
    hoTen: 'Quản trị viên Hệ thống (Admin)',
    maUserAD: '00000001',
    userAD: 'admin_nb',
    matKhau: '123456',
    email: 'admin.nb@vietinbank.vn',
    soDienThoai: '0901234567',
    vaiTro: 'Admin',
    maPhongBan: 'P_IT',
    tenPhongBan: 'Điện toán & Công nghệ thông tin',
    chucVu: 'Quản trị viên Hệ thống',
    trangThai: 'Đang làm việc',
    hasAccount: true,
    ngayCapTaiKhoan: '01/08/2026'
  }
];

export const initialUsers: User[] = initialCanBo.map((cb, idx) => ({
  id: `user-${idx + 1}`,
  maUserAD: cb.maUserAD || cb.maCanBo.padStart(8, '0'),
  hoTen: cb.hoTen,
  userAD: cb.userAD,
  maPhongBan: cb.maPhongBan,
  tenPhongBan: cb.tenPhongBan,
  chucVu: (cb.vaiTro || 'Cán bộ') as UserRole,
  trangThai: 'Hoạt động',
  matKhau: '123456',
  email: cb.email,
  soDienThoai: cb.soDienThoai,
  viTriCongViec: cb.chucVu
}));

export const initialRequests: RequestRecord[] = [
  {
    id: 'req-1',
    maDeNghi: 'CN-2026-0001',
    ngayTao: '10/08/2026 08:30',
    maUserAD: '00044380',
    maCanBo: '00044380',
    hoTen: 'Phạm Nguyễn Phương Anh',
    userAD: 'ANHPNP',
    maPhongBan: 'P_KHDN',
    tenPhongBan: 'Phòng KHDN',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    loaiDeNghi: 'Cấp mới',
    soQDTuyenDung_PhanCong: '142/QĐ-NHCT.NB ngày 01/08/2026',
    noiDung: 'Đề nghị cấp quyền tra cứu số dư tài khoản và hạch toán giải ngân KHDN trên hệ thống Core Sunshine',
    trangThai: 'Hoàn thành',
    nguoiDuyet: 'Đinh Mạnh Cường (DMCUONG)',
    thoiGianDuyet: '10/08/2026 10:15',
    nguoiXuLy: 'Nguyễn Trọng Đức (DUCNT4)',
    thoiGianNhan: '10/08/2026 14:00',
    thoiGianHoanThanh: '11/08/2026 09:30',
    ngayCapQuyen: '11/08/2026',
    ketQuaXuLy: 'Đã tạo User trên Core Sunshine và phân quyền nhóm KHDN_USER thành công',
    noiDungXuLy: 'Cấp quyền theo nhóm quyền Role-KHDN-L1, mật khẩu ban đầu đã gửi qua email nội bộ'
  },
  {
    id: 'req-2',
    maDeNghi: 'CN-2026-0002',
    ngayTao: '12/08/2026 09:00',
    maUserAD: '00044380',
    maCanBo: '00044380',
    hoTen: 'Phạm Nguyễn Phương Anh',
    userAD: 'ANHPNP',
    maPhongBan: 'P_KHDN',
    tenPhongBan: 'Phòng KHDN',
    maChuongTrinh: 'CRLOS',
    tenChuongTrinh: 'CRLOS (Corporate Retail Loan Origination System)',
    loaiDeNghi: 'Cấp mới',
    soQDTuyenDung_PhanCong: '142/QĐ-NHCT.NB ngày 01/08/2026',
    noiDung: 'Cấp user khởi tạo và quản lý hồ sơ tín dụng doanh nghiệp trên cấu phần CRLOS',
    trangThai: 'Hoàn thành',
    nguoiDuyet: 'Đinh Mạnh Cường (DMCUONG)',
    thoiGianDuyet: '12/08/2026 10:45',
    nguoiXuLy: 'Nguyễn Trọng Đức (DUCNT4)',
    thoiGianNhan: '12/08/2026 14:30',
    thoiGianHoanThanh: '13/08/2026 10:00',
    ngayCapQuyen: '13/08/2026',
    ketQuaXuLy: 'Đã phân quyền CRLOS_MAKER trên hệ thống CRLOS',
    noiDungXuLy: 'User CRLOS mapping userAD ANHPNP'
  },
  {
    id: 'req-3',
    maDeNghi: 'CN-2026-0003',
    ngayTao: '14/08/2026 14:15',
    maUserAD: '00030624',
    hoTen: 'Dương Văn Lan Anh',
    userAD: 'ANHDVL',
    maPhongBan: 'P_BL',
    tenPhongBan: 'Phòng Bán lẻ',
    maChuongTrinh: 'CLIMS',
    tenChuongTrinh: 'CLIMS (Collateral & Limits Management System)',
    loaiDeNghi: 'Cấp mới',
    soQDTuyenDung_PhanCong: '155/QĐ-NHCT.NB ngày 10/08/2026',
    noiDung: 'Cấp quyền kiểm soát hạn mức và quản lý hồ sơ tài sản bảo đảm bán lẻ trên CLIMS',
    trangThai: 'Chờ xử lý',
    nguoiDuyet: 'Hoàng Minh Sơn (SonHM)',
    thoiGianDuyet: '15/08/2026 08:30',
    nguoiXuLy: 'Nguyễn Trọng Đức (DUCNT4)',
    thoiGianNhan: '15/08/2026 09:10'
  },
  {
    id: 'req-4',
    maDeNghi: 'CN-2026-0004',
    ngayTao: '16/08/2026 10:00',
    maUserAD: '00044380',
    hoTen: 'Phạm Nguyễn Phương Anh',
    userAD: 'ANHPNP',
    maPhongBan: 'P_KHDN',
    tenPhongBan: 'Phòng KHDN',
    maChuongTrinh: 'TF',
    tenChuongTrinh: 'TF (Trade Finance)',
    loaiDeNghi: 'Cấp mới',
    soQDTuyenDung_PhanCong: '160/QĐ-NHCT.NB ngày 15/08/2026',
    noiDung: 'Cấp quyền quản lý và xử lý giao dịch tài trợ thương mại L/C trên kênh TF (EE)',
    trangThai: 'Chờ lãnh đạo phòng phê duyệt'
  },
  {
    id: 'req-5',
    maDeNghi: 'CN-2026-0005',
    ngayTao: '16/08/2026 15:20',
    maUserAD: '00006950',
    hoTen: 'Đỗ Thị Huệ',
    userAD: 'DT.Hue',
    maPhongBan: 'P_DVKH',
    tenPhongBan: 'Phòng Dịch vụ khách hàng',
    maChuongTrinh: 'IB',
    tenChuongTrinh: 'IB (Internet Banking)',
    loaiDeNghi: 'Thay đổi',
    soQDTuyenDung_PhanCong: '88/TB-KTDV ngày 01/06/2026',
    noiDung: 'Điều chỉnh quyền Bankadmin và VietinBank eFAST theo quyết định phân công mới',
    trangThai: 'Chờ lãnh đạo phòng phê duyệt'
  },
  {
    id: 'req-6',
    maDeNghi: 'CN-2026-0006',
    ngayTao: '15/08/2026 16:00',
    maUserAD: '00030624',
    hoTen: 'Dương Văn Lan Anh',
    userAD: 'ANHDVL',
    maPhongBan: 'P_BL',
    tenPhongBan: 'Phòng Bán lẻ',
    maChuongTrinh: 'OGL',
    tenChuongTrinh: 'OGL (Oracle General Ledger)',
    loaiDeNghi: 'Cấp mới',
    soQDTuyenDung_PhanCong: '155/QĐ-NHCT.NB ngày 10/08/2026',
    noiDung: 'Đề nghị cấp quyền tra cứu báo cáo tài chính trên OGL',
    trangThai: 'Từ chối',
    nguoiDuyet: 'Hoàng Minh Sơn (SonHM)',
    thoiGianDuyet: '16/08/2026 08:20',
    lyDoTuChoi: 'Quyền OGL chỉ cấp cho cán bộ Phòng Kế toán & DVKH hoặc theo chỉ đạo đặc thù'
  }
];

export const initialApprovals: ApprovalHistory[] = [
  {
    id: 'app-1',
    maDeNghi: 'CN-2026-0001',
    nguoiDuyet: 'Đinh Mạnh Cường',
    userAD: 'DMCUONG',
    maPhongBan: 'P_KHDN',
    ketQua: 'Phê duyệt',
    lyDo: 'Đồng ý cấp quyền theo phân công nghiệp vụ KHDN',
    thoiGian: '10/08/2026 10:15'
  },
  {
    id: 'app-2',
    maDeNghi: 'CN-2026-0002',
    nguoiDuyet: 'Đinh Mạnh Cường',
    userAD: 'DMCUONG',
    maPhongBan: 'P_KHDN',
    ketQua: 'Phê duyệt',
    lyDo: 'Nhất trí đề xuất',
    thoiGian: '12/08/2026 10:45'
  },
  {
    id: 'app-3',
    maDeNghi: 'CN-2026-0003',
    nguoiDuyet: 'Hoàng Minh Sơn',
    userAD: 'SonHM',
    maPhongBan: 'P_BL',
    ketQua: 'Phê duyệt',
    lyDo: 'Đã kiểm tra đúng quyết định phân công',
    thoiGian: '15/08/2026 08:30'
  },
  {
    id: 'app-4',
    maDeNghi: 'CN-2026-0006',
    nguoiDuyet: 'Hoàng Minh Sơn',
    userAD: 'SonHM',
    maPhongBan: 'P_BL',
    ketQua: 'Từ chối',
    lyDo: 'Quyền duyệt ERP chỉ cấp cho Cán bộ Quản lý/Thủ kho của Phòng Hành chính',
    thoiGian: '16/08/2026 08:20'
  }
];

export const initialProcessing: ProcessingHistory[] = [
  {
    id: 'proc-1',
    maDeNghi: 'CN-2026-0001',
    nguoiXuLy: 'Nguyễn Trọng Đức',
    userAD: 'DUCNT4',
    thoiGianNhan: '10/08/2026 14:00',
    thoiGianXuLy: '11/08/2026 09:30',
    ketQua: 'Hoàn thành cấp quyền',
    noiDungXuLy: 'Đã tạo User trên CoreBanking và phân quyền nhóm KHDN_USER thành công'
  },
  {
    id: 'proc-2',
    maDeNghi: 'CN-2026-0002',
    nguoiXuLy: 'Nguyễn Trọng Đức',
    userAD: 'DUCNT4',
    thoiGianNhan: '12/08/2026 14:30',
    thoiGianXuLy: '13/08/2026 10:00',
    ketQua: 'Hoàn thành cấp quyền',
    noiDungXuLy: 'Đã phân quyền LOS_KHDN_INITIATOR trên hệ thống LOS'
  }
];

export const initialAuditLogs: AuditLog[] = [
  {
    id: 'log-1',
    thoiGian: '10/08/2026 08:30:15',
    user: 'annv12',
    vaiTro: 'Cán bộ',
    hanhDong: 'TẠO_ĐỀ_NGHỊ',
    maDeNghi: 'CN-2026-0001',
    noiDung: 'Lập đề nghị cấp quyền mới chương trình CoreBanking',
    ip: '10.42.1.25',
    ketQua: 'Thành công'
  },
  {
    id: 'log-2',
    thoiGian: '10/08/2026 10:15:22',
    user: 'dungpd',
    vaiTro: 'Lãnh đạo phòng',
    hanhDong: 'PHÊ_DUYỆT_ĐỀ_NGHỊ',
    maDeNghi: 'CN-2026-0001',
    noiDung: 'Phê duyệt đề nghị CN-2026-0001 của cán bộ Nguyễn Văn An',
    ip: '10.42.1.10',
    ketQua: 'Thành công'
  },
  {
    id: 'log-3',
    thoiGian: '11/08/2026 09:30:44',
    user: 'ducnt4',
    vaiTro: 'Cán bộ điện toán',
    hanhDong: 'HOÀN_THÀNH_XỬ_LÝ',
    maDeNghi: 'CN-2026-0001',
    noiDung: 'Hoàn tất phân quyền trên chương trình nội bộ, cập nhật ngày cấp quyền 11/08/2026',
    ip: '10.42.5.2',
    ketQua: 'Thành công'
  },
  {
    id: 'log-4',
    thoiGian: '16/08/2026 08:20:10',
    user: 'tuanhm',
    vaiTro: 'Lãnh đạo phòng',
    hanhDong: 'TỪ_CHỐI_ĐỀ_NGHỊ',
    maDeNghi: 'CN-2026-0006',
    noiDung: 'Từ chối đề nghị CN-2026-0006 do sai phạm vi phân quyền',
    ip: '10.42.2.10',
    ketQua: 'Thành công'
  }
];

export const initialEmails: EmailNotification[] = [
  {
    id: 'mail-1',
    to: 'ducnt4@vietinbank.vn',
    subject: '[ĐỀ NGHỊ CẤP QUYỀN] CN-2026-0001 - Đã được phê duyệt',
    body: `Kính gửi Cán bộ Điện toán,\n\nĐề nghị cấp quyền CN-2026-0001 đã được Lãnh đạo phòng phê duyệt và chuyển đến Điện toán để xử lý.\n\nThông tin chi tiết:\n- Mã đề nghị: CN-2026-0001\n- Họ tên cán bộ: Nguyễn Văn An\n- User AD: annv12 (Mã: AD_042_012)\n- Phòng ban: P001 - Phòng Khách hàng Doanh nghiệp\n- Chương trình: CoreBanking (Hệ thống Ngân hàng lõi)\n- Loại đề nghị: Cấp mới\n- Số QĐ/Phân công NV: 142/QĐ-NHCT.NB ngày 01/08/2026\n- Người phê duyệt: Phạm Đức Dũng (dungpd)\n- Thời gian phê duyệt: 10/08/2026 10:15\n\nTrân trọng thông báo.`,
    thoiGian: '10/08/2026 10:15',
    maDeNghi: 'CN-2026-0001',
    loai: 'Phê duyệt',
    read: true
  },
  {
    id: 'mail-2',
    to: 'ducnt4@vietinbank.vn',
    subject: '[ĐỀ NGHỊ CẤP QUYỀN] CN-2026-0003 - Đã được phê duyệt',
    body: `Kính gửi Cán bộ Điện toán,\n\nĐề nghị cấp quyền CN-2026-0003 đã được Lãnh đạo phòng phê duyệt và chuyển đến Điện toán để xử lý.\n\nThông tin chi tiết:\n- Mã đề nghị: CN-2026-0003\n- Họ tên cán bộ: Trần Thị Bích\n- User AD: bichtt (Mã: AD_042_018)\n- Phòng ban: P002 - Phòng Bán lẻ & Khách hàng Cá nhân\n- Chương trình: LOS (Khởi tạo và phê duyệt khoản vay)\n- Loại đề nghị: Cấp mới\n- Số QĐ/Phân công NV: 155/QĐ-NHCT.NB ngày 10/08/2026\n- Người phê duyệt: Hoàng Minh Tuấn (tuanhm)\n- Thời gian phê duyệt: 15/08/2026 08:30\n\nTrân trọng thông báo.`,
    thoiGian: '15/08/2026 08:30',
    maDeNghi: 'CN-2026-0003',
    loai: 'Phê duyệt',
    read: false
  }
];

// ==========================================
// V1.2 MODULE: CĂN CỨ & HƯỚNG DẪN CẤP QUYỀN
// ==========================================

// 1. Sheet: APP_PERMISSION_RULES
export const initialPermissionRules: AppPermissionRule[] = [
  // 1. TPTL/TPSS
  {
    id: 'rule-tptl-tpss-1',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'TPSS_GDV',
    tenNhomQuyen: 'TPSS_GDV (Giao dịch viên quầy Core Sunshine)',
    dieuKien: 'Có phân công trực tiếp giao dịch phục vụ khách hàng tại quầy',
    luuY: 'Cấp mã Teller ID định danh cá nhân, không được chia sẻ mật khẩu.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-tptl-tpss-2',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'TPSS_KSV',
    tenNhomQuyen: 'TPSS_KSV (Kiểm soát viên Core Sunshine)',
    dieuKien: 'Có quyết định bổ nhiệm KSV hoặc Lãnh đạo phòng kế toán',
    luuY: 'Kiểm soát hạn mức duyệt giao dịch tài chính theo phân quyền ủy quyền.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-tptl-tpss-3',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'TPSS_GDV',
    tenNhomQuyen: 'TPSS_GDV (Giao dịch phi tiền mặt KHDN)',
    dieuKien: 'Có phân công nghiệp vụ hỗ trợ tín dụng và giải ngân KHDN',
    luuY: 'Chỉ thao tác trên hồ sơ và tài khoản khách hàng doanh nghiệp được phân công.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-tptl-tpss-4',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'TPTL_MAKER',
    tenNhomQuyen: 'TPTL_MAKER (Cài đặt & chạy lịch thu phí TPTL)',
    dieuKien: 'Được phân công theo dõi doanh thu phí dịch vụ và trích nợ tự động',
    luuY: 'Thực hiện theo đúng biểu phí hiện hành của VietinBank.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 2. IB (Internet Banking)
  {
    id: 'rule-ib-1',
    maChuongTrinh: 'IB',
    tenChuongTrinh: 'IB (Internet Banking)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'eFAST_Admin',
    tenNhomQuyen: 'eFAST_Admin (Quản trị & hỗ trợ eFAST KHDN)',
    dieuKien: 'Cán bộ quản lý khách hàng doanh nghiệp sử dụng eFAST',
    luuY: 'Hỗ trợ khách hàng cài đặt, phân quyền và cấp mã kích hoạt lại theo quy trình.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-ib-2',
    maChuongTrinh: 'IB',
    tenChuongTrinh: 'IB (Internet Banking)',
    maPhongBan: 'P002',
    tenPhongBan: 'Phòng Bán lẻ & Khách hàng Cá nhân',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'BankFast_Retail',
    tenNhomQuyen: 'BankFast_Retail (Hỗ trợ eBanking KHCN)',
    dieuKien: 'Cán bộ bán lẻ hỗ trợ đăng ký và mở khóa dịch vụ ngân hàng số',
    luuY: 'Xác thực định danh khách hàng chính chủ trước khi xử lý.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-ib-3',
    maChuongTrinh: 'IB',
    tenChuongTrinh: 'IB (Internet Banking)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'Registeradmin',
    tenNhomQuyen: 'Registeradmin (Đăng ký người dùng IB)',
    dieuKien: 'Giao dịch viên quầy tiếp nhận hồ sơ đăng ký eBanking',
    luuY: 'Kiểm tra khớp đúng chữ ký mẫu và giấy tờ tùy thân của khách hàng.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 3. TF (Trade Finance)
  {
    id: 'rule-tf-1',
    maChuongTrinh: 'TF',
    tenChuongTrinh: 'TF (Trade Finance)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'TF_EE_MAKER',
    tenNhomQuyen: 'TF_EE_MAKER (Nhập liệu tài trợ thương mại EE)',
    dieuKien: 'Cán bộ chuyên trách tài trợ thương mại hoặc thanh toán quốc tế',
    luuY: 'Kiểm tra đầy đủ bộ chứng từ L/C hoặc thư bảo lãnh theo quy chế.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-tf-2',
    maChuongTrinh: 'TF',
    tenChuongTrinh: 'TF (Trade Finance)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'TF_EE_CHECKER',
    tenNhomQuyen: 'TF_EE_CHECKER (Kiểm soát tài trợ thương mại EE)',
    dieuKien: 'Lãnh đạo phụ trách mảng KHDN có ủy quyền phê duyệt hồ sơ TF',
    luuY: 'Kiểm tra tính pháp lý của hợp đồng thương mại và điều kiện thanh toán.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 4. OGL (Oracle General Ledger)
  {
    id: 'rule-ogl-1',
    maChuongTrinh: 'OGL',
    tenChuongTrinh: 'OGL (Oracle General Ledger)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'OGL_ENTRY',
    tenNhomQuyen: 'OGL_ENTRY (Nhập bút toán sổ cái OGL)',
    dieuKien: 'Cán bộ kế toán tổng hợp, kế toán nội bộ chi nhánh',
    luuY: 'Chỉ nhập bút toán điều chỉnh kế toán đã có phiếu duyệt kế toán trưởng.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-ogl-2',
    maChuongTrinh: 'OGL',
    tenChuongTrinh: 'OGL (Oracle General Ledger)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'OGL_REVIEWER',
    tenNhomQuyen: 'OGL_REVIEWER (Kiểm soát và duyệt sổ cái OGL)',
    dieuKien: 'Trưởng/Phó phòng Kế toán & DVKH',
    luuY: 'Kiểm soát cân đối số dư tài khoản và duyệt chốt sổ kế toán kỳ.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 5. VFX (Vision Foreign Exchange)
  {
    id: 'rule-vfx-1',
    maChuongTrinh: 'VFX',
    tenChuongTrinh: 'VFX (Vision Foreign Exchange)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'VFX_MAKER',
    tenNhomQuyen: 'VFX_MAKER (Nhập giao dịch mua bán ngoại tệ)',
    dieuKien: 'Có phân công nghiệp vụ kinh doanh ngoại tệ cho khách hàng',
    luuY: 'Kiểm tra tỷ giá bán ra/mua vào theo bảng tỷ giá quy định hoặc deal tỷ giá Trụ sở chính.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-vfx-2',
    maChuongTrinh: 'VFX',
    tenChuongTrinh: 'VFX (Vision Foreign Exchange)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'VFX_CHECKER',
    tenNhomQuyen: 'VFX_CHECKER (Kiểm soát giao dịch ngoại tệ)',
    dieuKien: 'Lãnh đạo phòng kế toán hoặc KSV ngoại hối được ủy quyền',
    luuY: 'Kiểm tra trạng thái ngoại tệ và hạn mức trạng thái của chi nhánh.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 6. CRLOS (Corporate Retail Loan Origination System)
  {
    id: 'rule-crlos-1',
    maChuongTrinh: 'CRLOS',
    tenChuongTrinh: 'CRLOS (Corporate Retail Loan Origination System)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'CRLOS_MAKER',
    tenNhomQuyen: 'CRLOS_MAKER (Khởi tạo hồ sơ tín dụng KHDN)',
    dieuKien: 'Cán bộ quan hệ khách hàng doanh nghiệp',
    luuY: 'Nhập đầy đủ thông tin pháp lý, tài chính và tờ trình thẩm định tín dụng.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-crlos-2',
    maChuongTrinh: 'CRLOS',
    tenChuongTrinh: 'CRLOS (Corporate Retail Loan Origination System)',
    maPhongBan: 'P002',
    tenPhongBan: 'Phòng Bán lẻ & Khách hàng Cá nhân',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'CRLOS_MAKER',
    tenNhomQuyen: 'CRLOS_MAKER (Khởi tạo hồ sơ tín dụng Bán lẻ)',
    dieuKien: 'Cán bộ quản lý khách hàng bán lẻ',
    luuY: 'Đính kèm đầy đủ hồ sơ nguồn thu, phương án vay và tài sản bảo đảm.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-crlos-3',
    maChuongTrinh: 'CRLOS',
    tenChuongTrinh: 'CRLOS (Corporate Retail Loan Origination System)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'CRLOS_CHECKER',
    tenNhomQuyen: 'CRLOS_CHECKER (Kiểm soát tờ trình tín dụng KHDN)',
    dieuKien: 'Lãnh đạo phòng KHDN',
    luuY: 'Kiểm soát tính chính xác, thẩm định rủi ro trước khi chuyển Ban Giám đốc.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 7. CLIMS (Collateral & Limits Management System)
  {
    id: 'rule-clims-1',
    maChuongTrinh: 'CLIMS',
    tenChuongTrinh: 'CLIMS (Collateral & Limits Management System)',
    maPhongBan: 'P001',
    tenPhongBan: 'Phòng Khách hàng Doanh nghiệp',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'CLIMS_INPUT',
    tenNhomQuyen: 'CLIMS_INPUT (Nhập giới hạn tín dụng & TSBD)',
    dieuKien: 'Cán bộ quản lý khách hàng doanh nghiệp',
    luuY: 'Chỉ nhập dữ liệu tài sản bảo đảm đã qua công chứng/đăng ký giao dịch bảo đảm.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-clims-2',
    maChuongTrinh: 'CLIMS',
    tenChuongTrinh: 'CLIMS (Collateral & Limits Management System)',
    maPhongBan: 'P004',
    tenPhongBan: 'Phòng Quản lý nợ & KSNB',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'CLIMS_CHECK',
    tenNhomQuyen: 'CLIMS_CHECK (Kiểm soát giới hạn & hồ sơ TSBD)',
    dieuKien: 'Cán bộ phòng Quản lý nợ & KSNB phụ trách quản trị rủi ro',
    luuY: 'Đối chiếu thông tin hồ sơ tài sản bản gốc trước khi kích hoạt hạn mức sang Core SUNSHINE.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 8. AML
  {
    id: 'rule-aml-1',
    maChuongTrinh: 'AML',
    tenChuongTrinh: 'AML (Hệ thống Phòng chống rửa tiền, tài trợ khủng bố (PCRT&TTKB))',
    maPhongBan: 'P004',
    tenPhongBan: 'Phòng Quản lý nợ & KSNB',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'AML_OFFICER',
    tenNhomQuyen: 'AML_OFFICER (Rà soát khách hàng & giao dịch cảnh báo)',
    dieuKien: 'Cán bộ đầu mối phòng chống rửa tiền chi nhánh',
    luuY: 'Rà soát danh sách đen/cấm vận, báo cáo định kỳ theo quy định NHNN.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-aml-2',
    maChuongTrinh: 'AML',
    tenChuongTrinh: 'AML (Hệ thống Phòng chống rửa tiền, tài trợ khủng bố (PCRT&TTKB))',
    maPhongBan: 'P004',
    tenPhongBan: 'Phòng Quản lý nợ & KSNB',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'AML_SUPERVISOR',
    tenNhomQuyen: 'AML_SUPERVISOR (Kiểm soát và duyệt báo cáo PCRT)',
    dieuKien: 'Lãnh đạo phụ trách công tác KSNB và tuân thủ',
    luuY: 'Ký duyệt các trường hợp nghi ngờ để báo cáo Ban Giám đốc và Khối Tuân thủ TSC.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 9. SO_DIEN_TU
  {
    id: 'rule-sodt-1',
    maChuongTrinh: 'SO_DIEN_TU',
    tenChuongTrinh: 'Sổ điện tử',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'THU_QUY',
    tenNhomQuyen: 'THU_QUY (Thủ quỹ ghi sổ điện tử)',
    dieuKien: 'Có quyết định phân công làm thủ quỹ kiêm nhiệm hoặc thủ quỹ chuyên trách',
    luuY: 'Chỉ ghi nhận thu chi thực tế đối khớp với tồn quỹ tiền mặt.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-sodt-2',
    maChuongTrinh: 'SO_DIEN_TU',
    tenChuongTrinh: 'Sổ điện tử',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'KIEM_SOAT_QUY',
    tenNhomQuyen: 'KIEM_SOAT_QUY (Kiểm soát & chốt sổ quỹ điện tử)',
    dieuKien: 'Trưởng/Phó phòng Kế toán hoặc KSV phụ trách kho quỹ',
    luuY: 'Chốt số dư tồn quỹ cuối ngày và ký biên bản kiểm kê quỹ.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 10. SDB (Smart Digital Branch)
  {
    id: 'rule-sdb-1',
    maChuongTrinh: 'SDB',
    tenChuongTrinh: 'SDB (Smart digital branch)',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'SDB_GDV',
    tenNhomQuyen: 'SDB_GDV (Giao dịch viên tiếp nhận khách hàng SDB)',
    dieuKien: 'Cán bộ giao dịch viên quầy chi nhánh thông minh',
    luuY: 'Tiếp nhận thông tin phân luồng và gọi số từ hệ thống SDB vào quầy.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-sdb-2',
    maChuongTrinh: 'SDB',
    tenChuongTrinh: 'SDB (Smart digital branch)',
    maPhongBan: 'P002',
    tenPhongBan: 'Phòng Bán lẻ & Khách hàng Cá nhân',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'SDB_DIEU_PHOI',
    tenNhomQuyen: 'SDB_DIEU_PHOI (Điều phối & phân luồng khách hàng kiosk/tablet)',
    dieuKien: 'Cán bộ lễ tân, hướng dẫn viên chi nhánh số hoặc cán bộ bán lẻ trực sảnh',
    luuY: 'Hỗ trợ khách hàng lấy số, nhận diện sinh trắc học và nhập trước thông tin giao dịch.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 11. GS_TON_QUY_ATM
  {
    id: 'rule-atm-1',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    tenChuongTrinh: 'Chương trình giám sát tồn quỹ ATM',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Cán bộ',
    chucVu: 'Cán bộ',
    maNhomQuyen: 'TIEP_QUY_ATM',
    tenNhomQuyen: 'TIEP_QUY_ATM (Cán bộ tiếp quỹ & theo dõi tồn quỹ ATM)',
    dieuKien: 'Cán bộ quản lý quỹ, tổ tiếp quỹ ATM chi nhánh',
    luuY: 'Theo dõi mức tồn quỹ thực tế trên hệ thống, lên phương án tiếp quỹ kịp thời.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'rule-atm-2',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    tenChuongTrinh: 'Chương trình giám sát tồn quỹ ATM',
    maPhongBan: 'P003',
    tenPhongBan: 'Phòng Kế toán & Dịch vụ Khách hàng',
    doiTuong: 'Lãnh đạo phòng',
    chucVu: 'Lãnh đạo phòng',
    maNhomQuyen: 'GIAM_SAT_ATM',
    tenNhomQuyen: 'GIAM_SAT_ATM (Giám sát định mức tồn quỹ ATM)',
    dieuKien: 'Trưởng/Phó phòng Kế toán & DVKH',
    luuY: 'Kiểm soát tuân thủ định mức tồn quỹ ATM, hạn chế tồn quỹ vượt mức quy định.',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  }
];

// 2. Sheet: APP_PERMISSION_GROUPS
export const initialPermissionGroups: AppPermissionGroup[] = [
  // 1. TPTL/TPSS
  {
    id: 'grp-tptl-tpss-1',
    maChuongTrinh: 'TPTL/TPSS',
    maNhomQuyen: 'TPSS_GDV',
    tenNhomQuyen: 'TPSS_GDV (Giao dịch viên quầy Core Sunshine)',
    moTa: 'Quyền hạch toán thu chi tiền mặt, chuyển khoản, mở tài khoản và xử lý giao dịch quầy trên Core Sunshine',
    doiTuongApDung: 'Giao dịch viên quầy, Cán bộ hỗ trợ tín dụng',
    phongBanApDung: 'P001, P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-tptl-tpss-2',
    maChuongTrinh: 'TPTL/TPSS',
    maNhomQuyen: 'TPSS_KSV',
    tenNhomQuyen: 'TPSS_KSV (Kiểm soát viên Core Sunshine)',
    moTa: 'Quyền kiểm soát và duyệt các bút toán vượt hạn mức của Giao dịch viên trên Core Sunshine',
    doiTuongApDung: 'Kiểm soát viên, Lãnh đạo phòng Kế toán & DVKH',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-tptl-tpss-3',
    maChuongTrinh: 'TPTL/TPSS',
    maNhomQuyen: 'TPTL_MAKER',
    tenNhomQuyen: 'TPTL_MAKER (Cài đặt & chạy lịch thu phí)',
    moTa: 'Quyền thiết lập danh mục biểu phí và chạy lịch thu phí tự động định kỳ TPTL',
    doiTuongApDung: 'Cán bộ kế toán nghiệp vụ',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-tptl-tpss-4',
    maChuongTrinh: 'TPTL/TPSS',
    maNhomQuyen: 'TPTL_CHECKER',
    tenNhomQuyen: 'TPTL_CHECKER (Kiểm soát thu phí)',
    moTa: 'Quyền phê duyệt biểu phí và đối soát trích nợ tự động TPTL',
    doiTuongApDung: 'Lãnh đạo phòng Kế toán & DVKH',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 2. IB (Internet Banking)
  {
    id: 'grp-ib-1',
    maChuongTrinh: 'IB',
    maNhomQuyen: 'eFAST_Admin',
    tenNhomQuyen: 'eFAST_Admin (Quản trị & hỗ trợ eFAST KHDN)',
    moTa: 'Quản trị hồ sơ khách hàng doanh nghiệp dùng eFAST, tạo mã truy cập, reset mật khẩu, hỗ trợ kỹ thuật',
    doiTuongApDung: 'Cán bộ quản lý khách hàng doanh nghiệp',
    phongBanApDung: 'P001',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-ib-2',
    maChuongTrinh: 'IB',
    maNhomQuyen: 'BankFast_Retail',
    tenNhomQuyen: 'BankFast_Retail (Hỗ trợ eBanking KHCN)',
    moTa: 'Hỗ trợ khách hàng cá nhân đăng ký, kích hoạt, mở khóa gói dịch vụ iPay/BankFast',
    doiTuongApDung: 'Cán bộ bán lẻ',
    phongBanApDung: 'P002',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-ib-3',
    maChuongTrinh: 'IB',
    maNhomQuyen: 'Registeradmin',
    tenNhomQuyen: 'Registeradmin (Đăng ký người dùng IB)',
    moTa: 'Đăng ký người dùng mới, kích hoạt tài khoản Internet Banking tại quầy',
    doiTuongApDung: 'Giao dịch viên quầy',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 3. TF (Trade Finance)
  {
    id: 'grp-tf-1',
    maChuongTrinh: 'TF',
    maNhomQuyen: 'TF_EE_MAKER',
    tenNhomQuyen: 'TF_EE_MAKER (Nhập liệu tài trợ thương mại EE)',
    moTa: 'Nhập liệu mở, sửa đổi L/C, phát hành bảo lãnh và thanh toán bộ chứng từ hàng nhập/xuất',
    doiTuongApDung: 'Cán bộ tài trợ thương mại / thanh toán quốc tế',
    phongBanApDung: 'P001',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-tf-2',
    maChuongTrinh: 'TF',
    maNhomQuyen: 'TF_EE_CHECKER',
    tenNhomQuyen: 'TF_EE_CHECKER (Kiểm soát tài trợ thương mại EE)',
    moTa: 'Kiểm soát và phê duyệt giao dịch phát hành L/C, bảo lãnh, giải phóng thanh toán quốc tế',
    doiTuongApDung: 'Lãnh đạo phòng KHDN có ủy quyền TF',
    phongBanApDung: 'P001',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 4. OGL (Oracle General Ledger)
  {
    id: 'grp-ogl-1',
    maChuongTrinh: 'OGL',
    maNhomQuyen: 'OGL_ENTRY',
    tenNhomQuyen: 'OGL_ENTRY (Nhập bút toán sổ cái OGL)',
    moTa: 'Nhập các bút toán kế toán nội bộ, điều chỉnh số dư sổ cái tổng hợp OGL',
    doiTuongApDung: 'Cán bộ kế toán tổng hợp',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-ogl-2',
    maChuongTrinh: 'OGL',
    maNhomQuyen: 'OGL_REVIEWER',
    tenNhomQuyen: 'OGL_REVIEWER (Kiểm soát và duyệt sổ cái OGL)',
    moTa: 'Kiểm tra cân đối số dư, duyệt bút toán sổ cái tổng hợp và chốt kỳ kế toán',
    doiTuongApDung: 'Lãnh đạo phòng Kế toán & DVKH, Kế toán trưởng',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 5. VFX (Vision Foreign Exchange)
  {
    id: 'grp-vfx-1',
    maChuongTrinh: 'VFX',
    maNhomQuyen: 'VFX_MAKER',
    tenNhomQuyen: 'VFX_MAKER (Nhập giao dịch mua bán ngoại tệ)',
    moTa: 'Khởi tạo các giao dịch mua bán ngoại tệ giao ngay (Spot), kỳ hạn (Forward) cho khách hàng',
    doiTuongApDung: 'Cán bộ KHDN, Cán bộ kinh doanh vốn',
    phongBanApDung: 'P001',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-vfx-2',
    maChuongTrinh: 'VFX',
    maNhomQuyen: 'VFX_CHECKER',
    tenNhomQuyen: 'VFX_CHECKER (Kiểm soát giao dịch ngoại tệ)',
    moTa: 'Kiểm soát tỷ giá, hạn mức giao dịch ngoại tệ và chốt deal',
    doiTuongApDung: 'Kiểm soát viên ngoại hối, Lãnh đạo phòng Kế toán',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 6. CRLOS
  {
    id: 'grp-crlos-1',
    maChuongTrinh: 'CRLOS',
    maNhomQuyen: 'CRLOS_MAKER',
    tenNhomQuyen: 'CRLOS_MAKER (Khởi tạo hồ sơ tín dụng KHDN & Bán lẻ)',
    moTa: 'Khởi tạo hồ sơ vay, nhập tờ trình thẩm định, thông tin BCTC và tài sản bảo đảm trên CRLOS',
    doiTuongApDung: 'Cán bộ quan hệ khách hàng KHDN & Bán lẻ',
    phongBanApDung: 'P001, P002',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-crlos-2',
    maChuongTrinh: 'CRLOS',
    maNhomQuyen: 'CRLOS_CHECKER',
    tenNhomQuyen: 'CRLOS_CHECKER (Kiểm soát hồ sơ tín dụng CRLOS)',
    moTa: 'Kiểm soát tính chính xác, thẩm định rủi ro và ký duyệt chuyển tiếp tờ trình tín dụng',
    doiTuongApDung: 'Lãnh đạo phòng KHDN & Bán lẻ',
    phongBanApDung: 'P001, P002',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 7. CLIMS
  {
    id: 'grp-clims-1',
    maChuongTrinh: 'CLIMS',
    maNhomQuyen: 'CLIMS_INPUT',
    tenNhomQuyen: 'CLIMS_INPUT (Nhập giới hạn tín dụng & TSBD)',
    moTa: 'Khởi tạo và cập nhật hồ sơ hạn mức tín dụng và tài sản bảo đảm khách hàng',
    doiTuongApDung: 'Cán bộ KHDN, Cán bộ bán lẻ',
    phongBanApDung: 'P001, P002',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-clims-2',
    maChuongTrinh: 'CLIMS',
    maNhomQuyen: 'CLIMS_CHECK',
    tenNhomQuyen: 'CLIMS_CHECK (Kiểm soát giới hạn & hồ sơ TSBD)',
    moTa: 'Kiểm tra việc tuân thủ quy định hạn mức rủi ro, hồ sơ tài sản và kích hoạt sang Core',
    doiTuongApDung: 'Cán bộ phòng Quản lý nợ & KSNB',
    phongBanApDung: 'P004',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 8. AML
  {
    id: 'grp-aml-1',
    maChuongTrinh: 'AML',
    maNhomQuyen: 'AML_OFFICER',
    tenNhomQuyen: 'AML_OFFICER (Rà soát khách hàng & giao dịch cảnh báo)',
    moTa: 'Rà soát danh sách đen, cảnh báo giao dịch đáng ngờ, cập nhật trạng thái PCRT&TTKB',
    doiTuongApDung: 'Cán bộ đầu mối phòng chống rửa tiền',
    phongBanApDung: 'P004',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-aml-2',
    maChuongTrinh: 'AML',
    maNhomQuyen: 'AML_SUPERVISOR',
    tenNhomQuyen: 'AML_SUPERVISOR (Kiểm soát và duyệt báo cáo PCRT)',
    moTa: 'Phê duyệt các báo cáo giao dịch đáng ngờ và hồ sơ tuân thủ PCRT',
    doiTuongApDung: 'Lãnh đạo phụ trách công tác KSNB & Tuân thủ',
    phongBanApDung: 'P004',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 9. SO_DIEN_TU
  {
    id: 'grp-sodt-1',
    maChuongTrinh: 'SO_DIEN_TU',
    maNhomQuyen: 'THU_QUY',
    tenNhomQuyen: 'THU_QUY (Thủ quỹ ghi sổ điện tử)',
    moTa: 'Ghi chép biến động thu chi tiền mặt thực tế tại quỹ nghiệp vụ',
    doiTuongApDung: 'Thủ quỹ chi nhánh / phòng giao dịch',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-sodt-2',
    maChuongTrinh: 'SO_DIEN_TU',
    maNhomQuyen: 'KIEM_SOAT_QUY',
    tenNhomQuyen: 'KIEM_SOAT_QUY (Kiểm soát & chốt sổ quỹ điện tử)',
    moTa: 'Kiểm soát khớp đúng giữa sổ quỹ điện tử và sổ cái tổng hợp, ký chốt biên bản kiểm kê',
    doiTuongApDung: 'Kiểm soát viên, Lãnh đạo phòng Kế toán & DVKH',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 10. SDB (Smart Digital Branch)
  {
    id: 'grp-sdb-1',
    maChuongTrinh: 'SDB',
    maNhomQuyen: 'SDB_GDV',
    tenNhomQuyen: 'SDB_GDV (Giao dịch viên tiếp nhận khách hàng SDB)',
    moTa: 'Tiếp nhận thông tin khách hàng lấy số từ Kiosk, gọi số vào quầy giao dịch',
    doiTuongApDung: 'Giao dịch viên quầy',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-sdb-2',
    maChuongTrinh: 'SDB',
    maNhomQuyen: 'SDB_DIEU_PHOI',
    tenNhomQuyen: 'SDB_DIEU_PHOI (Điều phối & phân luồng khách hàng kiosk/tablet)',
    moTa: 'Hỗ trợ khách hàng lấy số, nhận diện khuôn mặt và phân luồng dịch vụ tại sảnh',
    doiTuongApDung: 'Cán bộ lễ tân, cán bộ bán lẻ trực sảnh',
    phongBanApDung: 'P002',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 11. GS_TON_QUY_ATM
  {
    id: 'grp-atm-1',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    maNhomQuyen: 'TIEP_QUY_ATM',
    tenNhomQuyen: 'TIEP_QUY_ATM (Cán bộ tiếp quỹ & theo dõi tồn quỹ ATM)',
    moTa: 'Theo dõi mức tồn quỹ thực tế trên các cây ATM/CRM, cập nhật lịch tiếp quỹ',
    doiTuongApDung: 'Cán bộ quản lý quỹ, tổ tiếp quỹ ATM',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'grp-atm-2',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    maNhomQuyen: 'GIAM_SAT_ATM',
    tenNhomQuyen: 'GIAM_SAT_ATM (Giám sát định mức tồn quỹ ATM)',
    moTa: 'Giám sát chỉ số an toàn tồn quỹ, cảnh báo vượt định mức quy định toàn chi nhánh',
    doiTuongApDung: 'Lãnh đạo phòng Kế toán & DVKH',
    phongBanApDung: 'P003',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  }
];

// 3. Sheet: APP_REGULATIONS
export const initialRegulations: AppRegulation[] = [
  // 1. TPTL/TPSS
  {
    id: 'reg-tptl-tpss-1',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    maVanBan: 'VB-SUNSHINE-2024-01',
    tenVanBan: 'Quy định Quản lý và Cấp quyền Người dùng Hệ thống Core Sunshine (TPTL/TPSS)',
    soVanBan: '235/QĐ-TGĐ-NHCT',
    ngayBanHanh: '15/03/2024',
    ngayHieuLuc: '01/04/2024',
    donViBanHanh: 'Tổng Giám đốc VietinBank (Trụ sở chính)',
    noiDung: 'Quy định chi tiết điều kiện cấp mã Teller ID, phân tách vai trò Giao dịch viên - Kiểm soát viên, nguyên tắc bất kiêm nhiệm và bảo mật dữ liệu khách hàng.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành áp dụng toàn hệ thống VietinBank',
    linkVanBan: 'https://noi-bo.vietinbank.vn/van-ban/235-qd-tgd',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'reg-tptl-tpss-2',
    maChuongTrinh: 'TPTL/TPSS',
    tenChuongTrinh: 'TPTL/TPSS (Hệ thống ngân hàng lõi core Sunshine)',
    maVanBan: 'VB-TPTL-2024-02',
    tenVanBan: 'Hướng dẫn Phân quyền Chi tiết Cài đặt Biểu phí và Thu phí Tự động TPTL',
    soVanBan: '118/HD-NHCT.NB',
    ngayBanHanh: '10/05/2024',
    ngayHieuLuc: '15/05/2024',
    donViBanHanh: 'VietinBank – Chi nhánh Ninh Bình',
    noiDung: 'Phân định hạn mức duyệt lệnh giao dịch quầy, quy trình chạy lịch thu phí định kỳ và báo cáo thu nợ tự động.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Áp dụng nội bộ tại CN Ninh Bình',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 2. IB
  {
    id: 'reg-ib-1',
    maChuongTrinh: 'IB',
    tenChuongTrinh: 'IB (Internet Banking)',
    maVanBan: 'VB-IB-2024-01',
    tenVanBan: 'Quy định Quản trị và Cung cấp Dịch vụ Ngân hàng Điện tử eFAST & iPay',
    soVanBan: '380/QĐ-TGĐ-NHCT',
    ngayBanHanh: '20/02/2024',
    ngayHieuLuc: '01/03/2024',
    donViBanHanh: 'Trung tâm Ngân hàng Số Trụ sở chính',
    noiDung: 'Quy chuẩn cấp user quản trị eFAST KHDN, phân quyền tạo user khách hàng và xử lý chứng thư số bảo mật.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 3. TF
  {
    id: 'reg-tf-1',
    maChuongTrinh: 'TF',
    tenChuongTrinh: 'TF (Trade Finance)',
    maVanBan: 'VB-TF-2023-01',
    tenVanBan: 'Quy chế Tài trợ Thương mại & Thanh toán Quốc tế trên Hệ thống TF',
    soVanBan: '512/QC-HĐQT-NHCT',
    ngayBanHanh: '15/11/2023',
    ngayHieuLuc: '01/12/2023',
    donViBanHanh: 'Khối KHDN & Thanh toán Quốc tế Trụ sở chính',
    noiDung: 'Quy định điều kiện kiểm soát hồ sơ L/C, bảo lãnh ngân hàng và thẩm quyền phát hành cam kết tài trợ thương mại.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 4. OGL
  {
    id: 'reg-ogl-1',
    maChuongTrinh: 'OGL',
    tenChuongTrinh: 'OGL (Oracle General Ledger)',
    maVanBan: 'VB-OGL-2023-01',
    tenVanBan: 'Quy định Quản lý và Vận hành Sổ cái Tổng hợp Oracle General Ledger',
    soVanBan: '412/QĐ-NHCT-TCKT',
    ngayBanHanh: '20/09/2023',
    ngayHieuLuc: '01/10/2023',
    donViBanHanh: 'Khối Tài chính Kế toán Trụ sở chính',
    noiDung: 'Quy định thẩm quyền nhập, duyệt bút toán điều chỉnh sổ cái, chốt kỳ kế toán và kết xuất báo cáo tài chính.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 5. VFX
  {
    id: 'reg-vfx-1',
    maChuongTrinh: 'VFX',
    tenChuongTrinh: 'VFX (Vision Foreign Exchange)',
    maVanBan: 'VB-VFX-2024-01',
    tenVanBan: 'Quy định Giao dịch Ngoại hối và Phân quyền Hệ thống VFX',
    soVanBan: '168/QĐ-TGĐ-KDTT',
    ngayBanHanh: '08/01/2024',
    ngayHieuLuc: '15/01/2024',
    donViBanHanh: 'Khối Kinh doanh Vốn và Thị trường Trụ sở chính',
    noiDung: 'Quy chuẩn nhập liệu lệnh mua bán ngoại tệ, kiểm soát trạng thái ngoại tệ chi nhánh và đối chiếu deal với Hội sở.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 6. CRLOS
  {
    id: 'reg-crlos-1',
    maChuongTrinh: 'CRLOS',
    tenChuongTrinh: 'CRLOS (Corporate Retail Loan Origination System)',
    maVanBan: 'VB-CRLOS-2024-01',
    tenVanBan: 'Quy định Vận hành Phân hệ Khởi tạo Tín dụng CRLOS KHDN & Bán lẻ',
    soVanBan: '520/QĐ-TGĐ-QLRR',
    ngayBanHanh: '18/04/2024',
    ngayHieuLuc: '01/05/2024',
    donViBanHanh: 'Khối Quản lý Rủi ro Trụ sở chính',
    noiDung: 'Bắt buộc khởi tạo và luân chuyển tờ trình thẩm định, hồ sơ pháp lý và đề xuất cấp tín dụng trên CRLOS.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 7. CLIMS
  {
    id: 'reg-clims-1',
    maChuongTrinh: 'CLIMS',
    tenChuongTrinh: 'CLIMS (Collateral & Limits Management System)',
    maVanBan: 'VB-CLIMS-2024-01',
    tenVanBan: 'Quy chế Quản lý Hạn mức và Tài sản Bảo đảm trên CLIMS',
    soVanBan: '190/QC-HĐQT-NHCT',
    ngayBanHanh: '05/02/2024',
    ngayHieuLuc: '01/03/2024',
    donViBanHanh: 'Hội đồng Quản trị VietinBank',
    noiDung: 'Quy định thẩm quyền nhập, kiểm tra và duyệt hạn mức tín dụng, quản lý định giá tài sản thế chấp trên hệ thống CLIMS.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 8. AML
  {
    id: 'reg-aml-1',
    maChuongTrinh: 'AML',
    tenChuongTrinh: 'AML (Hệ thống Phòng chống rửa tiền, tài trợ khủng bố (PCRT&TTKB))',
    maVanBan: 'VB-AML-2024-01',
    tenVanBan: 'Quy định Phòng chống Rửa tiền và Rà soát Danh sách Đen trên Hệ thống AML',
    soVanBan: '602/QĐ-TGĐ-TTKS',
    ngayBanHanh: '12/03/2024',
    ngayHieuLuc: '01/04/2024',
    donViBanHanh: 'Khối Tuân thủ & KSNB Trụ sở chính',
    noiDung: 'Quy định trách nhiệm rà soát cảnh báo giao dịch đáng ngờ, cập nhật danh sách PEP, cấm vận và quy trình báo cáo Cục PCRT NHNN.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Tuân thủ Luật PCRT số 14/2022/QH15',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 9. SO_DIEN_TU
  {
    id: 'reg-sodt-1',
    maChuongTrinh: 'SO_DIEN_TU',
    tenChuongTrinh: 'Sổ điện tử',
    maVanBan: 'VB-SDT-2023-01',
    tenVanBan: 'Quy trình Quản lý Kho quỹ và Ghi chép Sổ quỹ Điện tử Chi nhánh',
    soVanBan: '298/QĐ-NHCT-KQ',
    ngayBanHanh: '14/07/2023',
    ngayHieuLuc: '01/08/2023',
    donViBanHanh: 'Khối Vận hành Trụ sở chính',
    noiDung: 'Quy định việc cập nhật tồn quỹ thực tế từng quầy/kho, kiểm kê quỹ hàng ngày và ký số biên bản chốt quỹ điện tử.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 10. SDB
  {
    id: 'reg-sdb-1',
    maChuongTrinh: 'SDB',
    tenChuongTrinh: 'SDB (Smart digital branch)',
    maVanBan: 'VB-SDB-2024-01',
    tenVanBan: 'Hướng dẫn Vận hành và Phân luồng Khách hàng Chi nhánh Thông minh SDB',
    soVanBan: '445/HD-TGĐ-DVKH',
    ngayBanHanh: '25/05/2024',
    ngayHieuLuc: '01/06/2024',
    donViBanHanh: 'Trung tâm Phát triển Kênh số Trụ sở chính',
    noiDung: 'Hướng dẫn cán bộ lễ tân, giao dịch viên sử dụng thiết bị Tablet/Kiosk, điều phối luồng giao dịch và tiếp nhận khách hàng nhận diện sinh trắc học.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 11. GS_TON_QUY_ATM
  {
    id: 'reg-atm-1',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    tenChuongTrinh: 'Chương trình giám sát tồn quỹ ATM',
    maVanBan: 'VB-ATM-2023-01',
    tenVanBan: 'Quy chế Giám sát Định mức Tồn quỹ và Tiếp quỹ Máy giao dịch Tự động ATM/CRM',
    soVanBan: '333/QC-TGĐ-KQ',
    ngayBanHanh: '10/09/2023',
    ngayHieuLuc: '01/10/2023',
    donViBanHanh: 'Khối Quản lý Tiền mặt Trụ sở chính',
    noiDung: 'Quy định định mức tồn quỹ tối đa, tối thiểu của từng trạm máy ATM, quy trình theo dõi số dư từ xa và phê duyệt kế hoạch tiếp quỹ.',
    trangThai: 'Còn hiệu lực',
    ghiChu: 'Văn bản hiện hành',
    linkVanBan: '',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  }
];

// 4. Sheet: APP_NOTES
export const initialNotes: AppNote[] = [
  // 1. TPTL/TPSS
  {
    id: 'note-tptl-tpss-1',
    maChuongTrinh: 'TPTL/TPSS',
    loaiLuuY: 'Lưu ý quan trọng',
    noiDung: 'Kiểm tra kỹ quyết định phân công công việc và bổ nhiệm của cán bộ trước khi cấp Teller ID Core Sunshine. Tuyệt đối không cấp quyền giao dịch viên nếu chưa có chứng chỉ nghiệp vụ quầy.',
    dieuKienApDung: 'Tất cả các đề nghị cấp mới quyền TPSS_GDV/TPSS_KSV',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'note-tptl-tpss-2',
    maChuongTrinh: 'TPTL/TPSS',
    loaiLuuY: 'Cảnh báo',
    noiDung: 'Nghiêm cấm cấp đồng thời quyền TPSS_GDV (Maker) và TPSS_KSV (Checker) cho cùng một cán bộ trên hệ thống Core Sunshine (nguyên tắc bất kiêm nhiệm 4 mắt).',
    dieuKienApDung: 'Toàn bộ các phòng ban nghiệp vụ',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },
  {
    id: 'note-tptl-tpss-3',
    maChuongTrinh: 'TPTL/TPSS',
    loaiLuuY: 'Trường hợp đặc biệt',
    noiDung: 'Quyền sửa đổi danh mục biểu phí TPTL chỉ được cấp cho cán bộ được chỉ định bằng văn bản và có phê duyệt của Ban Giám đốc chi nhánh.',
    dieuKienApDung: 'Nhóm quyền TPTL_MAKER/TPTL_CHECKER',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 2. IB
  {
    id: 'note-ib-1',
    maChuongTrinh: 'IB',
    loaiLuuY: 'Lưu ý quan trọng',
    noiDung: 'Cán bộ quản trị eFAST chỉ được thực hiện hỗ trợ cấp lại mã kích hoạt khi đã đối chiếu hồ sơ chữ ký mẫu và người đại diện theo pháp luật của KHDN.',
    dieuKienApDung: 'Nhóm quyền eFAST_Admin',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 3. TF
  {
    id: 'note-tf-1',
    maChuongTrinh: 'TF',
    loaiLuuY: 'Cảnh báo',
    noiDung: 'Hồ sơ mở L/C hoặc phát hành bảo lãnh phải có đầy đủ phê duyệt tín dụng hợp lệ trước khi cán bộ duyệt phát hành lệnh trên hệ thống TF.',
    dieuKienApDung: 'Nhóm quyền TF_EE_CHECKER',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 4. OGL
  {
    id: 'note-ogl-1',
    maChuongTrinh: 'OGL',
    loaiLuuY: 'Lưu ý quan trọng',
    noiDung: 'Mọi bút toán điều chỉnh sổ cái OGL phát sinh ngoài hệ thống giao dịch tự động phải kèm phiếu kế toán có chữ ký phê duyệt của Kế toán trưởng chi nhánh.',
    dieuKienApDung: 'Cán bộ nhập liệu bút toán OGL',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 5. VFX
  {
    id: 'note-vfx-1',
    maChuongTrinh: 'VFX',
    loaiLuuY: 'Lưu ý',
    noiDung: 'Giao dịch ngoại tệ kỳ hạn (Forward/Swap) phải tuân thủ nghiêm ngặt quy định về trần tỷ giá và ký quỹ bảo đảm của VietinBank.',
    dieuKienApDung: 'Cán bộ kinh doanh ngoại hối',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 6. CRLOS
  {
    id: 'note-crlos-1',
    maChuongTrinh: 'CRLOS',
    loaiLuuY: 'Cảnh báo',
    noiDung: 'Không cấp quyền khởi tạo hồ sơ vay CRLOS cho cán bộ kiểm soát rủi ro hoặc thẩm định độc lập (đảm bảo tính khách quan giữa kinh doanh và thẩm định rủi ro).',
    dieuKienApDung: 'Phòng Quản lý nợ & KSNB',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 7. CLIMS
  {
    id: 'note-clims-1',
    maChuongTrinh: 'CLIMS',
    loaiLuuY: 'Lưu ý quan trọng',
    noiDung: 'Hạn mức tín dụng và thông tin tài sản bảo đảm chỉ được kích hoạt sang Core Sunshine sau khi cán bộ KSNB/Quản lý nợ đã kiểm tra đầy đủ hồ sơ pháp lý gốc.',
    dieuKienApDung: 'Nhóm quyền CLIMS_CHECK',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 8. AML
  {
    id: 'note-aml-1',
    maChuongTrinh: 'AML',
    loaiLuuY: 'Cảnh báo',
    noiDung: 'Cảnh báo giao dịch đáng ngờ phải được xử lý và phân loại trong vòng 24 giờ kể từ khi hệ thống AML đưa ra cảnh báo.',
    dieuKienApDung: 'Cán bộ phụ trách AML',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 9. SO_DIEN_TU
  {
    id: 'note-sodt-1',
    maChuongTrinh: 'SO_DIEN_TU',
    loaiLuuY: 'Lưu ý quan trọng',
    noiDung: 'Thủ quỹ phải đối chiếu số dư tiền mặt thực tế với số liệu trên sổ điện tử trước 17h00 hàng ngày và tiến hành ký chốt sổ.',
    dieuKienApDung: 'Thủ quỹ và KSV kho quỹ',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 10. SDB
  {
    id: 'note-sdb-1',
    maChuongTrinh: 'SDB',
    loaiLuuY: 'Lưu ý',
    noiDung: 'Thiết bị Tablet/Kiosk tại sảnh giao dịch phải luôn được đăng nhập bằng tài khoản định danh của cán bộ trực sảnh ca trực.',
    dieuKienApDung: 'Cán bộ phân luồng SDB',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  },

  // 11. GS_TON_QUY_ATM
  {
    id: 'note-atm-1',
    maChuongTrinh: 'GS_TON_QUY_ATM',
    loaiLuuY: 'Cảnh báo',
    noiDung: 'Khi tồn quỹ tại cây ATM/CRM xuống dưới 15% hạn mức hoặc vượt quá 90% hạn mức, cán bộ phụ trách phải lập tức kích hoạt quy trình tiếp quỹ hoặc rút bớt tồn quỹ.',
    dieuKienApDung: 'Tổ tiếp quỹ và giám sát ATM',
    trangThai: 'Hoạt động',
    ngayCapNhat: '15/08/2026 08:00',
    nguoiCapNhat: 'admin_nb'
  }
];
